import Link from "next/link";
import { notFound } from "next/navigation";
import { getPassport, getPet } from "@/lib/data";
import { CATEGORY_META, PET_STATUS_META, speciesEmoji } from "@/lib/ui";

export const dynamic = "force-dynamic";

function Meter({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex-1">
      <p className="mb-1 text-[10px] font-extrabold uppercase tracking-wide text-ink-500">
        {label}
      </p>
      <div className="flex gap-1">
        {Array.from({ length: 5 }).map((_, i) => (
          <span
            key={i}
            className={`h-1.5 flex-1 rounded-full ${
              i < value ? "bg-coral-500" : "bg-stone-200"
            }`}
          />
        ))}
      </div>
    </div>
  );
}

export default async function PetDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const pet = await getPet(Number(id));
  if (!pet) notFound();

  const passport = await getPassport(pet.id);
  const status = PET_STATUS_META[pet.adoptionStatus] ?? PET_STATUS_META.disponible;
  const facts = [
    { icon: "🕐", label: pet.ageLabel, tint: "bg-mint-100 text-mint-600" },
    {
      icon: pet.sex === "Hembra" ? "♀" : "♂",
      label: pet.sex,
      tint: "bg-coral-100 text-coral-700",
    },
    { icon: "🐾", label: pet.temperament, tint: "bg-sun-100 text-amber-700" },
    { icon: "⚖️", label: `${pet.weightKg} kg`, tint: "bg-stone-100 text-ink-700" },
  ];

  return (
    <div className="flex min-h-full flex-col">
      <header className="relative overflow-hidden rounded-b-[34px] bg-gradient-to-br from-mint-400 to-mint-300 px-5 pb-16 pt-6 text-white">
        <div className="pointer-events-none absolute -left-8 -bottom-6 h-28 w-28 rounded-full bg-white/15" />
        <div className="relative flex items-center justify-between">
          <Link
            href="/"
            aria-label="Volver"
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/25 text-lg backdrop-blur transition hover:bg-white/40"
          >
            ←
          </Link>
          <h1 className="text-2xl font-extrabold tracking-tight">Detalle</h1>
          <span className="flex h-10 w-10 items-center justify-center rounded-full bg-white text-lg text-coral-500 shadow-md">
            ♥
          </span>
        </div>
      </header>

      <div className="-mt-12 flex-1 space-y-4 px-4 pb-6">
        <div className="animate-pop relative overflow-hidden rounded-[30px] bg-white p-3 shadow-[0_18px_40px_-22px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <div className="relative aspect-[4/3.2] overflow-hidden rounded-[22px] bg-stone-100">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={pet.photoUrl}
              alt={pet.name}
              className="h-full w-full object-cover"
            />
            <span
              className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-extrabold ${status.chip} shadow`}
            >
              {status.label}
            </span>
            <span className="absolute bottom-3 right-3 flex h-11 w-11 items-center justify-center rounded-full bg-white text-xl text-coral-500 shadow-lg">
              ♥
            </span>
          </div>

          <div className="px-2 pb-1 pt-4 text-center">
            <h2 className="text-3xl font-extrabold tracking-tight">
              {pet.name} {speciesEmoji(pet.species)}
            </h2>
            <p className="text-xs font-bold text-ink-500">
              {pet.breed} · {pet.city}
            </p>
          </div>

          <div className="mt-3 grid grid-cols-4 gap-2 px-1">
            {facts.map((f) => (
              <div
                key={f.label}
                className={`rounded-2xl px-1.5 py-2.5 text-center ${f.tint}`}
              >
                <p className="text-base leading-none">{f.icon}</p>
                <p className="mt-1 text-[10px] font-extrabold leading-tight">
                  {f.label}
                </p>
              </div>
            ))}
          </div>

          <div className="mt-4 flex gap-4 rounded-2xl bg-cream px-3 py-3">
            <Meter label="Energía" value={pet.energy} />
            <Meter label="Sociable" value={pet.sociability} />
          </div>
        </div>

        <section className="rounded-3xl bg-white p-4 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <h3 className="text-sm font-extrabold">Sobre {pet.name}</h3>
          <p className="mt-1.5 text-sm leading-relaxed text-ink-700">
            {pet.description}
          </p>
          <p className="mt-2 text-xs leading-relaxed text-ink-500">
            {pet.story}
          </p>
          <div className="mt-3 flex items-center gap-2 rounded-2xl bg-mint-50 px-3 py-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-mint-200 text-base">
              🏡
            </span>
            <div className="min-w-0">
              <p className="truncate text-xs font-extrabold">{pet.shelter}</p>
              <p className="truncate text-[11px] font-semibold text-ink-500">
                {pet.city} · Responsable del rescate
              </p>
            </div>
          </div>
        </section>

        <section className="rounded-3xl bg-white p-4 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold">Salud al día</h3>
            <Link
              href={`/pasaporte/${pet.id}`}
              className="rounded-full bg-mint-100 px-3 py-1 text-[11px] font-extrabold text-mint-600"
            >
              Ver pasaporte →
            </Link>
          </div>
          <div className="mt-3 space-y-2">
            {passport.slice(0, 3).map((rec) => {
              const meta = CATEGORY_META[rec.category] ?? CATEGORY_META.revision;
              return (
                <div key={rec.id} className="flex items-center gap-2.5">
                  <span className="text-sm">{meta.icon}</span>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-extrabold">{rec.label}</p>
                      <span
                        className={`text-xs font-extrabold ${rec.done ? "text-mint-500" : "text-sun-500"}`}
                      >
                        {rec.done ? "✓" : "•"}
                      </span>
                    </div>
                    <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-stone-200">
                      <div
                        className={`h-full rounded-full ${meta.bar}`}
                        style={{ width: `${rec.completion}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <div className="sticky bottom-20 flex gap-2.5">
          <Link
            href={`/pasaporte/${pet.id}`}
            className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white text-xl shadow-lg ring-1 ring-black/5"
            aria-label="Pasaporte"
          >
            🪪
          </Link>
          {pet.adoptionStatus === "adoptado" ? (
            <span className="flex h-14 flex-1 items-center justify-center rounded-2xl bg-stone-300 text-base font-extrabold text-white">
              Ya fue adoptado 💛
            </span>
          ) : (
            <Link
              href={`/mascotas/${pet.id}/adoptar`}
              className="flex h-14 flex-1 items-center justify-center rounded-2xl bg-coral-500 text-base font-extrabold text-white shadow-xl shadow-coral-300/60 transition active:scale-95"
            >
              Adoptar a {pet.name}
            </Link>
          )}
        </div>
      </div>
    </div>
  );
}
