import { toggleFollowUp } from "@/db/queries";

export const dynamic = "force-dynamic";

export async function PATCH(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await context.params;
    const followUpId = Number(id);
    if (!Number.isInteger(followUpId)) {
      return Response.json(
        { ok: false, error: "Hito no válido" },
        { status: 400 },
      );
    }

    const updated = await toggleFollowUp(followUpId);
    if (!updated) {
      return Response.json(
        { ok: false, error: "El hito no existe" },
        { status: 404 },
      );
    }

    return Response.json({ ok: true, followUp: updated });
  } catch (error) {
    console.error("[follow-ups] PATCH", error);
    return Response.json(
      { ok: false, error: "No pudimos actualizar el seguimiento" },
      { status: 500 },
    );
  }
}
