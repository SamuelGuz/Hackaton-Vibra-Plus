import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowUpRight,
  Building2,
  CalendarDays,
  Check,
  Clock,
  IdCard,
  Microchip,
  Route,
  ShieldCheck,
  Stethoscope,
  Syringe,
  Weight,
} from "lucide-react";
import { PassportActions } from "@/components/passport-actions";
import { PetQr } from "@/components/pet-qr";
import { getPassportBundle } from "@/db/queries";
import {
  ageLabel,
  formatDate,
  speciesLabel,
  shortDate,
} from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ petId: string }>;
}) {
  const { petId } = await params;
  const bundle = await getPassportBundle(Number(petId));
  return {
    title: bundle
      ? `Pasaporte de ${bundle.pet.name} — Huellitas`
      : "Pasaporte — Huellitas",
  };
}

const progressRows = [
  { key: "vaccinesProgress", label: "Vacunas", icon: Syringe, tone: "bg-coral-400" },
  { key: "dewormedProgress", label: "Desparasitado", icon: ShieldCheck, tone: "bg-mint-400" },
  { key: "microchipProgress", label: "Microchip", icon: Microchip, tone: "bg-sun-400" },
] as const;

export default async function PasaporteDetallePage({
  params,
}: {
  params: Promise<{ petId: string }>;
}) {
  const { petId } = await params;
  const id = Number(petId);
  if (!Number.isInteger(id)) notFound();

  const bundle = await getPassportBundle(id);
  if (!bundle) notFound();

  const { pet, passport, vaccines } = bundle;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          href="/pasaporte"
          className="inline-flex items-center gap-2 rounded-full border border-white bg-white/80 px-3.5 py-2 text-xs font-extrabold text-ink shadow-soft transition hover:bg-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Todos los pasaportes
        </Link>
        <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-muted">
          Módulo Pasaporte
          <span className="h-1 w-1 rounded-full bg-mint-400" />
          {passport ? passport.code : "Sin emitir"}
        </p>
      </div>

      {!passport ? (
        <div className="card flex flex-col items-center gap-3 px-6 py-16 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-full bg-mint-100 text-mint-700">
            <IdCard className="h-7 w-7" />
          </span>
          <h1 className="font-display text-2xl font-bold">
            El pasaporte de {pet.name} aún no está emitido
          </h1>
          <p className="max-w-md text-sm font-medium text-muted">
            Se genera automáticamente cuando el refugio aprueba una solicitud de
            adopción. Mientras tanto puedes consultar su ficha y el plan de
            seguimiento.
          </p>
          <div className="mt-2 flex gap-2">
            <Link href={`/mascotas/${pet.id}`} className="btn-primary">
              Ver ficha
            </Link>
            <Link href="/solicitudes" className="btn-outline">
              Solicitudes
            </Link>
          </div>
        </div>
      ) : (
        <div className="grid gap-5 lg:grid-cols-[0.86fr_1.14fr]">
          {/* Pasaporte */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <div className="relative mx-auto max-w-sm">
              <div className="absolute inset-y-8 -left-2 w-5 rounded-full bg-mint-300" />
              <div className="absolute inset-y-8 -right-2 w-5 rounded-full bg-mint-300" />
              <div className="print-card relative overflow-hidden rounded-[30px] border-4 border-white bg-white p-5 shadow-soft">
                <div className="paw-pattern absolute inset-x-0 top-0 h-24 opacity-40" />

                <div className="relative flex items-center justify-between">
                  <p className="text-[9px] font-extrabold uppercase tracking-[0.22em] text-mint-600">
                    Huellitas · Pasaporte
                  </p>
                  <IdCard className="h-4 w-4 text-mint-500" />
                </div>

                <div className="relative mt-3 flex flex-col items-center">
                  <div className="relative h-28 w-28 rounded-full bg-sun-200 p-1.5">
                    <div className="h-full w-full overflow-hidden rounded-full ring-4 ring-white">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={pet.photoUrl}
                        alt={`${pet.name}, ${pet.breed}`}
                        className="h-full w-full object-cover"
                      />
                    </div>
                    <span className="absolute -bottom-1 right-0 grid h-8 w-8 place-items-center rounded-full bg-mint-500 text-white ring-4 ring-white">
                      <Check className="h-4 w-4" strokeWidth={3.5} />
                    </span>
                  </div>
                  <h1 className="mt-3 font-display text-3xl font-bold leading-none">
                    {pet.name}
                  </h1>
                  <p className="mt-1 text-[11px] font-extrabold uppercase tracking-[0.14em] text-muted">
                    {speciesLabel(pet.species)} · {pet.breed}
                  </p>
                  <p className="mt-1 rounded-full bg-cream px-3 py-1 text-[10px] font-extrabold tracking-[0.18em] text-ink/60 ring-1 ring-line">
                    Nº {passport.code}
                  </p>
                </div>

                <div className="my-4 flex items-center gap-2">
                  <span className="h-px flex-1 bg-line" />
                  <span className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-muted">
                    Salud
                  </span>
                  <span className="h-px flex-1 bg-line" />
                </div>

                <div className="space-y-3">
                  {progressRows.map((row) => {
                    const Icon = row.icon;
                    const value = passport[row.key];
                    return (
                      <div key={row.key}>
                        <div className="flex items-center gap-2">
                          <span className="grid h-6 w-6 place-items-center rounded-lg bg-cream text-ink/60">
                            <Icon className="h-3.5 w-3.5" />
                          </span>
                          <span className="text-xs font-extrabold text-ink">
                            {row.label}
                          </span>
                          <span className="ml-auto flex items-center gap-1 text-[10px] font-extrabold text-ink/60">
                            {value}%
                            {value >= 100 ? (
                              <Check
                                className="h-3.5 w-3.5 text-mint-600"
                                strokeWidth={3.5}
                              />
                            ) : (
                              <Clock className="h-3 w-3 text-amber-500" />
                            )}
                          </span>
                        </div>
                        <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-cream">
                          <div
                            className={`h-full rounded-full ${row.tone}`}
                            style={{ width: `${Math.min(Math.max(value, 4), 100)}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-5 flex items-end justify-between gap-3 rounded-2xl bg-cream/70 p-3">
                  <div className="text-[10px] font-bold leading-relaxed text-muted">
                    <p className="font-extrabold uppercase tracking-[0.14em] text-ink/50">
                      Titular
                    </p>
                    {pet.name} · {ageLabel(pet.ageMonths)}
                    <br />
                    {pet.city}
                    <br />
                    <span className="text-ink/70">{passport.microchipId}</span>
                  </div>
                  <div className="shrink-0 rounded-xl bg-white p-1.5 ring-1 ring-line">
                    <PetQr value={passport.code} className="h-16 w-16" />
                  </div>
                </div>

                <p className="mt-3 text-center text-[9px] font-bold uppercase tracking-[0.16em] text-muted">
                  Documento sanitario digital · No válido sin microchip
                </p>
              </div>
            </div>

            <div className="mt-4 flex justify-center">
              <PassportActions code={passport.code} />
            </div>
          </div>

          {/* Datos clínicos */}
          <div className="space-y-4">
            <section className="card overflow-hidden">
              <div className="flex items-center justify-between gap-2 bg-mint-100 px-5 py-3">
                <p className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.14em] text-mint-700">
                  <Syringe className="h-4 w-4" />
                  Vacunas y tratamientos
                </p>
                <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-extrabold text-mint-700">
                  {vaccines.filter((vaccine) => vaccine.status === "completa").length}/
                  {vaccines.length} completas
                </span>
              </div>
              <ul className="divide-y divide-line/70">
                {vaccines.length === 0 ? (
                  <li className="px-5 py-6 text-sm font-medium text-muted">
                    La clínica aún no ha registrado dosis para {pet.name}.
                  </li>
                ) : (
                  vaccines.map((vaccine) => (
                    <li
                      key={vaccine.id}
                      className="flex flex-wrap items-center gap-3 px-5 py-3"
                    >
                      <span
                        className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${
                          vaccine.status === "completa"
                            ? "bg-mint-100 text-mint-700"
                            : "bg-sun-100 text-amber-700"
                        }`}
                      >
                        {vaccine.status === "completa" ? (
                          <Check className="h-4 w-4" strokeWidth={3} />
                        ) : (
                          <Clock className="h-4 w-4" />
                        )}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-extrabold leading-tight">
                          {vaccine.name}
                        </p>
                        <p className="text-[11px] font-bold text-muted">
                          {vaccine.dose} · Aplicada {shortDate(vaccine.appliedOn)}
                          {vaccine.nextDueOn
                            ? ` · Próxima ${shortDate(vaccine.nextDueOn)}`
                            : ""}
                        </p>
                      </div>
                      <span
                        className={`pill ${
                          vaccine.status === "completa"
                            ? "bg-mint-100 text-mint-700 ring-mint-200"
                            : "bg-sun-100 text-amber-800 ring-amber-200"
                        }`}
                      >
                        {vaccine.status === "completa" ? "Completa" : "Pendiente"}
                      </span>
                    </li>
                  ))
                )}
              </ul>
            </section>

            <section className="grid gap-3 sm:grid-cols-2">
              {[
                {
                  icon: Stethoscope,
                  label: "Veterinario",
                  value: passport.vetName,
                  detail: passport.clinic,
                  tone: "bg-coral-50 text-coral-600",
                },
                {
                  icon: CalendarDays,
                  label: "Última revisión",
                  value: formatDate(passport.lastCheckup),
                  detail: `Emitido ${formatDate(passport.issuedAt)}`,
                  tone: "bg-mint-100 text-mint-700",
                },
                {
                  icon: Weight,
                  label: "Peso registrado",
                  value: `${passport.weightKg} kg`,
                  detail: `${speciesLabel(pet.species)} · ${pet.size}`,
                  tone: "bg-sun-100 text-amber-700",
                },
                {
                  icon: Microchip,
                  label: "Microchip",
                  value: passport.microchipId,
                  detail: "Identificación oficial",
                  tone: "bg-sky-100 text-sky-700",
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div key={item.label} className="card p-4">
                    <span
                      className={`grid h-9 w-9 place-items-center rounded-xl ${item.tone}`}
                    >
                      <Icon className="h-4 w-4" />
                    </span>
                    <p className="mt-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-muted">
                      {item.label}
                    </p>
                    <p className="text-sm font-extrabold leading-tight text-ink">
                      {item.value}
                    </p>
                    <p className="mt-0.5 text-[11px] font-semibold text-muted">
                      {item.detail}
                    </p>
                  </div>
                );
              })}
            </section>

            <section className="card p-5">
              <p className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-ink/60">
                <Building2 className="h-4 w-4" />
                Notas del refugio
              </p>
              <p className="mt-2 text-sm font-medium leading-relaxed text-ink/75">
                {passport.notes || "Sin observaciones adicionales."}
              </p>
              <p className="mt-3 flex items-center gap-1.5 text-[11px] font-bold text-muted">
                <Building2 className="h-3.5 w-3.5 text-coral-400" />
                {pet.shelter} · {pet.city}
              </p>
            </section>

            <div className="flex flex-wrap gap-2">
              <Link href={`/mascotas/${pet.id}`} className="btn-outline flex-1 text-xs">
                Ver detalle de {pet.name}
                <ArrowUpRight className="h-4 w-4" />
              </Link>
              <Link href={`/seguimiento/${pet.id}`} className="btn-primary flex-1 text-xs">
                <Route className="h-4 w-4" />
                Seguimiento
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
