import { sql } from "drizzle-orm";
import { db } from "./index";
import { applications, followUps, passportRecords, pets } from "./schema";

const petSeed = [
  {
    name: "Bella",
    species: "perro",
    breed: "Golden Retriever",
    ageLabel: "2 meses",
    sex: "Hembra",
    size: "Mediana",
    weightKg: "4.2",
    temperament: "Juguetona",
    energy: 5,
    sociability: 5,
    description:
      "Bella es pura alegría: adora los juegos de buscar la pelota y las siestas largas sobre los pies de su humano favorito.",
    story:
      "Llegó al refugio con apenas tres semanas junto a su camada. Fue criada por una familia de acogida y hoy busca un hogar definitivo con jardín o paseos diarios.",
    photoUrl:
      "https://images.pexels.com/photos/8031870/pexels-photo-8031870.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    shelter: "Refugio Huellitas",
    city: "Ciudad de México",
    microchip: "900 115 000 482 117",
    sterilized: false,
    adoptionStatus: "disponible",
  },
  {
    name: "Luna",
    species: "perro",
    breed: "Mestiza criolla",
    ageLabel: "1 año",
    sex: "Hembra",
    size: "Mediana",
    weightKg: "14.0",
    temperament: "Cariñosa",
    energy: 4,
    sociability: 5,
    description:
      "Luna es dulce y muy sociable. Se lleva bien con niños y con otros perros del refugio.",
    story:
      "Fue rescatada de la calle con desnutrición leve. Después de tres meses de cuidados recuperó su peso ideal y su enorme sonrisa.",
    photoUrl:
      "https://images.pexels.com/photos/34658892/pexels-photo-34658892.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    shelter: "Refugio Huellitas",
    city: "Guadalajara",
    microchip: "900 115 000 482 092",
    sterilized: true,
    adoptionStatus: "en_proceso",
  },
  {
    name: "Oliver",
    species: "gato",
    breed: "Europeo atigrado",
    ageLabel: "3 años",
    sex: "Macho",
    size: "Mediano",
    weightKg: "5.1",
    temperament: "Tranquilo",
    energy: 2,
    sociability: 4,
    description:
      "Oliver es un gato sereno que ama las ventanas soleadas y las caricias detrás de la oreja.",
    story:
      "Su familia emigró y no pudo llevarlo. Lleva ocho meses en adopción esperando un hogar tranquilo sin perros.",
    photoUrl:
      "https://images.pexels.com/photos/9371980/pexels-photo-9371980.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    shelter: "Casa Gatuna",
    city: "Monterrey",
    microchip: "900 115 000 391 774",
    sterilized: true,
    adoptionStatus: "disponible",
  },
  {
    name: "Milo",
    species: "gato",
    breed: "Naranja doméstico",
    ageLabel: "8 meses",
    sex: "Macho",
    size: "Pequeño",
    weightKg: "3.4",
    temperament: "Curioso",
    energy: 5,
    sociability: 3,
    description:
      "Milo explora cada rincón, persigue tapitas y duerme en cualquier caja que encuentre.",
    story:
      "Apareció maullando en el motor de un auto. Hoy está sano, vacunado y listo para su hogar definitivo.",
    photoUrl:
      "https://images.pexels.com/photos/12573570/pexels-photo-12573570.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    shelter: "Casa Gatuna",
    city: "Ciudad de México",
    microchip: "900 115 000 512 330",
    sterilized: true,
    adoptionStatus: "disponible",
  },
  {
    name: "Rocco",
    species: "perro",
    breed: "Labrador",
    ageLabel: "2 años",
    sex: "Macho",
    size: "Grande",
    weightKg: "27.5",
    temperament: "Leal",
    energy: 4,
    sociability: 5,
    description:
      "Rocco entiende sentado, quieto y patita. Es ideal para familias activas que salgan a correr.",
    story:
      "Entregado por su familia tras una mudanza. Es un perro equilibrado con entrenamiento básico completo.",
    photoUrl:
      "https://images.pexels.com/photos/28683176/pexels-photo-28683176.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    shelter: "Patitas al Rescate",
    city: "Puebla",
    microchip: "900 115 000 220 018",
    sterilized: true,
    adoptionStatus: "adoptado",
  },
  {
    name: "Nina",
    species: "gato",
    breed: "Calico",
    ageLabel: "1 año",
    sex: "Hembra",
    size: "Pequeña",
    weightKg: "3.9",
    temperament: "Mimosa",
    energy: 3,
    sociability: 4,
    description:
      "Nina ronronea apenas la miras. Perfecta para departamentos y para quien busca compañía constante.",
    story:
      "Rescatada de una colonia felina urbana, se adaptó rapidísimo a la vida en casa de acogida.",
    photoUrl:
      "https://images.pexels.com/photos/19834943/pexels-photo-19834943.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
    shelter: "Casa Gatuna",
    city: "Querétaro",
    microchip: "900 115 000 777 451",
    sterilized: true,
    adoptionStatus: "disponible",
  },
];

export async function ensureSeed() {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(pets);

  if ((row?.count ?? 0) > 0) return;

  const inserted = await db.insert(pets).values(petSeed).returning();
  const byName = new Map(inserted.map((p) => [p.name, p.id]));
  const id = (name: string) => byName.get(name) as number;

  await db.insert(passportRecords).values([
    // Bella
    { petId: id("Bella"), category: "vacuna", label: "Polivalente (1ª dosis)", detail: "Parvovirus, moquillo, hepatitis", appliedOn: "2026-01-12", nextDueOn: "2026-02-09", completion: 40, done: true },
    { petId: id("Bella"), category: "desparasitacion", label: "Desparasitación interna", detail: "Pamoato de pirantel", appliedOn: "2026-01-12", nextDueOn: "2026-03-12", completion: 70, done: true },
    { petId: id("Bella"), category: "microchip", label: "Microchip ISO 11784", detail: "Registro nacional activo", appliedOn: "2026-01-15", nextDueOn: "", completion: 100, done: true },
    { petId: id("Bella"), category: "revision", label: "Revisión veterinaria", detail: "Peso y desarrollo óptimos", appliedOn: "2026-02-01", nextDueOn: "2026-03-01", completion: 100, done: true },
    // Oliver
    { petId: id("Oliver"), category: "vacuna", label: "Triple felina", detail: "Esquema completo", appliedOn: "2025-11-03", nextDueOn: "2026-11-03", completion: 100, done: true },
    { petId: id("Oliver"), category: "vacuna", label: "Antirrábica", detail: "Lote FR-2291", appliedOn: "2025-11-03", nextDueOn: "2026-11-03", completion: 100, done: true },
    { petId: id("Oliver"), category: "desparasitacion", label: "Desparasitación externa", detail: "Pipeta mensual", appliedOn: "2026-02-01", nextDueOn: "2026-03-01", completion: 80, done: true },
    { petId: id("Oliver"), category: "microchip", label: "Microchip ISO 11784", detail: "Registro nacional activo", appliedOn: "2024-08-22", nextDueOn: "", completion: 100, done: true },
    // Luna
    { petId: id("Luna"), category: "vacuna", label: "Polivalente (refuerzo)", detail: "Esquema completo", appliedOn: "2025-12-18", nextDueOn: "2026-12-18", completion: 100, done: true },
    { petId: id("Luna"), category: "desparasitacion", label: "Desparasitación interna", detail: "Trimestral", appliedOn: "2026-01-20", nextDueOn: "2026-04-20", completion: 60, done: true },
    { petId: id("Luna"), category: "microchip", label: "Microchip ISO 11784", detail: "Registro nacional activo", appliedOn: "2025-12-18", nextDueOn: "", completion: 100, done: true },
    // Milo
    { petId: id("Milo"), category: "vacuna", label: "Triple felina", detail: "2ª dosis aplicada", appliedOn: "2026-01-28", nextDueOn: "2027-01-28", completion: 100, done: true },
    { petId: id("Milo"), category: "desparasitacion", label: "Desparasitación interna", detail: "Pendiente refuerzo", appliedOn: "2026-01-05", nextDueOn: "2026-03-05", completion: 50, done: false },
    { petId: id("Milo"), category: "microchip", label: "Microchip ISO 11784", detail: "Registro nacional activo", appliedOn: "2026-01-28", nextDueOn: "", completion: 100, done: true },
    // Rocco
    { petId: id("Rocco"), category: "vacuna", label: "Antirrábica", detail: "Lote DG-8891", appliedOn: "2025-09-10", nextDueOn: "2026-09-10", completion: 100, done: true },
    { petId: id("Rocco"), category: "desparasitacion", label: "Desparasitación integral", detail: "Interna y externa", appliedOn: "2026-02-02", nextDueOn: "2026-05-02", completion: 90, done: true },
    { petId: id("Rocco"), category: "microchip", label: "Microchip ISO 11784", detail: "Registro nacional activo", appliedOn: "2025-09-10", nextDueOn: "", completion: 100, done: true },
    // Nina
    { petId: id("Nina"), category: "vacuna", label: "Triple felina", detail: "1ª dosis", appliedOn: "2026-02-04", nextDueOn: "2026-03-04", completion: 50, done: true },
    { petId: id("Nina"), category: "desparasitacion", label: "Desparasitación interna", detail: "Mensual", appliedOn: "2026-02-04", nextDueOn: "2026-03-04", completion: 70, done: true },
    { petId: id("Nina"), category: "microchip", label: "Microchip ISO 11784", detail: "Registro nacional activo", appliedOn: "2026-02-04", nextDueOn: "", completion: 100, done: true },
  ]);

  const apps = await db
    .insert(applications)
    .values([
      {
        petId: id("Luna"),
        applicantName: "Mariana Ortiz",
        email: "mariana.ortiz@correo.com",
        phone: "+52 55 2841 1190",
        city: "Guadalajara",
        housing: "Casa con patio",
        hasOtherPets: false,
        motivation:
          "Quiero darle a Luna el hogar tranquilo que merece. Trabajo desde casa y puedo acompañarla todo el día.",
        status: "en_proceso",
        progress: 60,
      },
      {
        petId: id("Milo"),
        applicantName: "Diego Ramírez",
        email: "diego.ramirez@correo.com",
        phone: "+52 81 3320 7741",
        city: "Monterrey",
        housing: "Departamento con balcón protegido",
        hasOtherPets: true,
        motivation:
          "Tengo una gata adulta muy sociable y creo que Milo sería un gran compañero de juegos para ella.",
        status: "aprobado",
        progress: 100,
      },
      {
        petId: id("Bella"),
        applicantName: "Fernanda Solís",
        email: "fer.solis@correo.com",
        phone: "+52 55 7712 0045",
        city: "Ciudad de México",
        housing: "Casa con jardín",
        hasOtherPets: false,
        motivation:
          "Siempre quisimos un cachorro para la familia. Mis hijos tienen 8 y 11 años y están emocionadísimos.",
        status: "pendiente",
        progress: 20,
      },
      {
        petId: id("Rocco"),
        applicantName: "Andrés Navarro",
        email: "andres.navarro@correo.com",
        phone: "+52 222 118 3390",
        city: "Puebla",
        housing: "Casa con jardín amplio",
        hasOtherPets: false,
        motivation:
          "Corro 10 km diarios y Rocco sería el compañero perfecto de entrenamiento.",
        status: "aprobado",
        progress: 100,
      },
      {
        petId: id("Oliver"),
        applicantName: "Paola Guzmán",
        email: "paola.guzman@correo.com",
        phone: "+52 442 550 9981",
        city: "Querétaro",
        housing: "Departamento",
        hasOtherPets: true,
        motivation:
          "Busco un gato tranquilo. Mi horario es flexible y vivo sola con otra gata senior.",
        status: "rechazado",
        progress: 100,
      },
    ])
    .returning();

  const appId = (name: string) =>
    apps.find((a) => a.applicantName === name)!.id;

  await db.insert(followUps).values([
    // Diego (Milo) - aprobado
    { applicationId: appId("Diego Ramírez"), title: "Visita domiciliaria 1", kind: "visita", scheduledFor: "2026-02-08", note: "Espacio revisado, ventanas con malla.", done: true, position: 1 },
    { applicationId: appId("Diego Ramírez"), title: "Entrega de Milo", kind: "visita", scheduledFor: "2026-02-14", note: "Firma de carta responsiva.", done: true, position: 2 },
    { applicationId: appId("Diego Ramírez"), title: "Foto de actualización", kind: "foto", scheduledFor: "2026-02-28", note: "Milo ya duerme en su cama nueva.", done: true, position: 3 },
    { applicationId: appId("Diego Ramírez"), title: "Vacuna de refuerzo", kind: "vacuna", scheduledFor: "2026-03-14", note: "Triple felina anual.", done: false, position: 4 },
    { applicationId: appId("Diego Ramírez"), title: "Visita de seguimiento 2", kind: "visita", scheduledFor: "2026-04-10", note: "Revisión de adaptación a 2 meses.", done: false, position: 5 },
    // Andrés (Rocco) - aprobado
    { applicationId: appId("Andrés Navarro"), title: "Visita domiciliaria 1", kind: "visita", scheduledFor: "2026-01-18", note: "Jardín seguro y bardeado.", done: true, position: 1 },
    { applicationId: appId("Andrés Navarro"), title: "Entrega de Rocco", kind: "visita", scheduledFor: "2026-01-25", done: true, note: "Adaptación inmediata.", position: 2 },
    { applicationId: appId("Andrés Navarro"), title: "Llamada de seguimiento", kind: "llamada", scheduledFor: "2026-02-08", note: "Todo en orden, ya corren juntos.", done: true, position: 3 },
    { applicationId: appId("Andrés Navarro"), title: "Foto de actualización", kind: "foto", scheduledFor: "2026-03-01", note: "", done: false, position: 4 },
    // Mariana (Luna) - en proceso
    { applicationId: appId("Mariana Ortiz"), title: "Entrevista telefónica", kind: "llamada", scheduledFor: "2026-02-05", note: "Perfil compatible con Luna.", done: true, position: 1 },
    { applicationId: appId("Mariana Ortiz"), title: "Visita domiciliaria 1", kind: "visita", scheduledFor: "2026-02-20", note: "Agendada con el refugio.", done: false, position: 2 },
    { applicationId: appId("Mariana Ortiz"), title: "Entrega de Luna", kind: "visita", scheduledFor: "2026-03-02", note: "", done: false, position: 3 },
    // Fernanda (Bella) - pendiente
    { applicationId: appId("Fernanda Solís"), title: "Revisión de solicitud", kind: "llamada", scheduledFor: "2026-02-18", note: "En cola de revisión del refugio.", done: false, position: 1 },
  ]);
}
