import {
  ClipboardList,
  House,
  IdCard,
  Route,
  type LucideIcon,
} from "lucide-react";

export type NavItem = {
  href: string;
  label: string;
  shortLabel: string;
  description: string;
  icon: LucideIcon;
};

export const navItems: NavItem[] = [
  {
    href: "/",
    label: "Inicio",
    shortLabel: "Inicio",
    description: "Mascotas que buscan hogar",
    icon: House,
  },
  {
    href: "/solicitudes",
    label: "Solicitudes",
    shortLabel: "Solicitudes",
    description: "Gestiona las adopciones",
    icon: ClipboardList,
  },
  {
    href: "/pasaporte",
    label: "Pasaporte",
    shortLabel: "Pasaporte",
    description: "Salud y vacunas al día",
    icon: IdCard,
  },
  {
    href: "/seguimiento",
    label: "Seguimiento",
    shortLabel: "Seguir",
    description: "Acompañamiento post adopción",
    icon: Route,
  },
];
