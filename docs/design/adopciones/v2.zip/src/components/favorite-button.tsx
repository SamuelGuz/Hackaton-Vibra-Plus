"use client";

import { useEffect, useState } from "react";
import { Heart } from "lucide-react";

const STORAGE_KEY = "huellitas:favoritos";

function readFavorites(): number[] {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const parsed = raw ? (JSON.parse(raw) as unknown) : [];
    return Array.isArray(parsed)
      ? parsed.filter((id): id is number => typeof id === "number")
      : [];
  } catch {
    return [];
  }
}

export function FavoriteButton({
  petId,
  petName,
  className = "",
}: {
  petId: number;
  petName: string;
  className?: string;
}) {
  const [active, setActive] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setActive(readFavorites().includes(petId));
    setMounted(true);
  }, [petId]);

  function toggle() {
    const current = readFavorites();
    const next = current.includes(petId)
      ? current.filter((id) => id !== petId)
      : [...current, petId];
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    setActive(next.includes(petId));
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={active}
      aria-label={
        active
          ? `Quitar a ${petName} de favoritos`
          : `Guardar a ${petName} en favoritos`
      }
      className={`grid h-10 w-10 place-items-center rounded-full backdrop-blur transition active:scale-90 ${
        active
          ? "bg-coral-500 text-white shadow-pop"
          : "bg-white/85 text-coral-500 hover:bg-white"
      } ${className}`}
    >
      <Heart
        className={`h-[18px] w-[18px] transition ${mounted && active ? "scale-110 fill-white" : ""}`}
        strokeWidth={2.4}
      />
    </button>
  );
}
