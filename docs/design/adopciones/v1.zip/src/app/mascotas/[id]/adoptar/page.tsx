import { notFound } from "next/navigation";
import { Screen, ScreenBody, ScreenHeader } from "@/components/Screen";
import { getPet } from "@/lib/data";
import AdoptForm from "./AdoptForm";

export const dynamic = "force-dynamic";

export default async function AdoptPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const pet = await getPet(Number(id));
  if (!pet) notFound();

  return (
    <Screen>
      <ScreenHeader
        title="Solicitud"
        subtitle={`Adopción de ${pet.name}`}
        backHref={`/mascotas/${pet.id}`}
        tone="coral"
      />
      <ScreenBody>
        <div className="flex items-center gap-3 rounded-3xl bg-white p-3 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={pet.photoUrl}
            alt={pet.name}
            className="h-16 w-16 rounded-2xl object-cover"
          />
          <div className="min-w-0">
            <p className="text-base font-extrabold">{pet.name}</p>
            <p className="truncate text-[11px] font-semibold text-ink-500">
              {pet.breed} · {pet.ageLabel} · {pet.shelter}
            </p>
          </div>
        </div>

        <AdoptForm petId={pet.id} petName={pet.name} />

        <p className="px-2 text-center text-[11px] font-semibold leading-relaxed text-ink-500">
          Al enviar aceptas la visita domiciliaria y el seguimiento
          post-adopción durante 3 meses 💛
        </p>
      </ScreenBody>
    </Screen>
  );
}
