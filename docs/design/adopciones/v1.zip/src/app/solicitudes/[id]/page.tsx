import Link from "next/link";
import { notFound } from "next/navigation";
import { Screen, ScreenBody, ScreenHeader } from "@/components/Screen";
import { getApplication, getFollowUps } from "@/lib/data";
import { KIND_META, STATUS_META, formatDate, initials } from "@/lib/ui";
import StatusControl from "./StatusControl";

export const dynamic = "force-dynamic";

export default async function ApplicationDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const app = await getApplication(Number(id));
  if (!app) notFound();

  const steps = await getFollowUps(app.id);
  const done = steps.filter((s) => s.done).length;
  const meta = STATUS_META[app.status] ?? STATUS_META.pendiente;

  const rows = [
    { label: "Correo", value: app.email, icon: "✉️" },
    { label: "Teléfono", value: app.phone, icon: "📞" },
    { label: "Ciudad", value: app.city, icon: "📍" },
    { label: "Vivienda", value: app.housing, icon: "🏠" },
    {
      label: "Otras mascotas",
      value: app.hasOtherPets ? "Sí" : "No",
      icon: "🐾",
    },
  ];

  return (
    <Screen>
      <ScreenHeader
        title={`Solicitud #${app.id}`}
        subtitle={app.applicantName}
        backHref="/solicitudes"
        tone="coral"
        action={
          <span
            className={`shrink-0 rounded-full px-3 py-1.5 text-[10px] font-extrabold ${meta.chip}`}
          >
            {meta.label}
          </span>
        }
      />
      <ScreenBody>
        <div className="animate-pop rounded-[28px] bg-white p-3 shadow-[0_14px_32px_-22px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <div className="flex gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={app.pet.photoUrl}
              alt={app.pet.name}
              className="h-20 w-20 rounded-2xl object-cover"
            />
            <div className="min-w-0 flex-1">
              <p className="text-lg font-extrabold leading-tight">
                {app.pet.name}
              </p>
              <p className="truncate text-[11px] font-semibold text-ink-500">
                {app.pet.breed} · {app.pet.ageLabel} · {app.pet.sex}
              </p>
              <div className="mt-2 flex gap-2">
                <Link
                  href={`/mascotas/${app.pet.id}`}
                  className="rounded-full bg-cream px-3 py-1 text-[10px] font-extrabold text-ink-700 ring-1 ring-stone-200"
                >
                  Ver detalle
                </Link>
                <Link
                  href={`/pasaporte/${app.pet.id}`}
                  className="rounded-full bg-mint-100 px-3 py-1 text-[10px] font-extrabold text-mint-600"
                >
                  Pasaporte
                </Link>
              </div>
            </div>
          </div>

          <div className="mt-3 rounded-2xl bg-cream px-3 py-3">
            <div className="flex items-center justify-between text-[11px] font-extrabold">
              <span>Avance del proceso</span>
              <span className="text-ink-500">{app.progress}%</span>
            </div>
            <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-stone-200">
              <div
                className={`h-full rounded-full ${meta.bar}`}
                style={{ width: `${app.progress}%` }}
              />
            </div>
            <p className="mt-2 text-[10px] font-semibold text-ink-500">
              {done} de {steps.length} pasos de seguimiento completados
            </p>
          </div>
        </div>

        <section className="rounded-3xl bg-white p-4 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <div className="flex items-center gap-2.5">
            <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-coral-100 text-sm font-extrabold text-coral-700">
              {initials(app.applicantName)}
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-extrabold">
                {app.applicantName}
              </p>
              <p className="text-[11px] font-semibold text-ink-500">
                Solicitó el{" "}
                {formatDate(new Date(app.createdAt).toISOString().slice(0, 10))}
              </p>
            </div>
          </div>

          <dl className="mt-3 divide-y divide-stone-100">
            {rows.map((r) => (
              <div
                key={r.label}
                className="flex items-center justify-between gap-3 py-2"
              >
                <dt className="flex items-center gap-2 text-[11px] font-bold text-ink-500">
                  <span>{r.icon}</span>
                  {r.label}
                </dt>
                <dd className="truncate text-[11px] font-extrabold">
                  {r.value}
                </dd>
              </div>
            ))}
          </dl>

          <div className="mt-2 rounded-2xl bg-sun-100 px-3 py-3">
            <p className="text-[10px] font-extrabold uppercase tracking-wide text-amber-700">
              Motivación
            </p>
            <p className="mt-1 text-xs leading-relaxed text-ink-700">
              {app.motivation || "Sin comentarios adicionales."}
            </p>
          </div>
        </section>

        <StatusControl applicationId={app.id} current={app.status} />

        <section className="rounded-3xl bg-white p-4 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold">Próximos pasos</h3>
            <Link
              href={`/seguimiento/${app.id}`}
              className="rounded-full bg-coral-100 px-3 py-1 text-[11px] font-extrabold text-coral-700"
            >
              Abrir seguimiento →
            </Link>
          </div>
          <div className="mt-3 space-y-2">
            {steps.slice(0, 3).map((s) => {
              const km = KIND_META[s.kind] ?? KIND_META.visita;
              return (
                <div key={s.id} className="flex items-center gap-2.5">
                  <span
                    className={`flex h-8 w-8 items-center justify-center rounded-xl text-sm ${km.tint}`}
                  >
                    {km.icon}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[11px] font-extrabold">
                      {s.title}
                    </p>
                    <p className="text-[10px] font-semibold text-ink-500">
                      {formatDate(s.scheduledFor)}
                    </p>
                  </div>
                  <span
                    className={`text-sm ${s.done ? "text-mint-500" : "text-stone-300"}`}
                  >
                    ✓
                  </span>
                </div>
              );
            })}
          </div>
        </section>
      </ScreenBody>
    </Screen>
  );
}
