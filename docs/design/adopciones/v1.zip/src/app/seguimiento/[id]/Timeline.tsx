"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { FollowUp } from "@/db/schema";
import { KIND_META, formatDate } from "@/lib/ui";

export default function Timeline({ steps }: { steps: FollowUp[] }) {
  const router = useRouter();
  const [items, setItems] = useState(steps);
  const [busy, setBusy] = useState<number | null>(null);

  async function toggle(step: FollowUp) {
    setBusy(step.id);
    setItems((prev) =>
      prev.map((s) => (s.id === step.id ? { ...s, done: !s.done } : s)),
    );
    const res = await fetch(`/api/follow-ups/${step.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ done: !step.done }),
    });
    if (!res.ok) {
      setItems((prev) =>
        prev.map((s) => (s.id === step.id ? { ...s, done: step.done } : s)),
      );
    } else {
      router.refresh();
    }
    setBusy(null);
  }

  const done = items.filter((s) => s.done).length;
  const pct = Math.round((done / Math.max(items.length, 1)) * 100);

  return (
    <div className="rounded-[28px] bg-white p-4 shadow-[0_14px_32px_-22px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-extrabold">Línea de tiempo</h3>
        <span className="rounded-full bg-mint-100 px-2.5 py-1 text-[10px] font-extrabold text-mint-600">
          {pct}% completado
        </span>
      </div>

      <div className="relative mt-4 pl-1">
        <span className="absolute bottom-3 left-[22px] top-3 w-[3px] rounded-full bg-gradient-to-b from-coral-200 via-sun-200 to-mint-200" />
        <ul className="space-y-3">
          {items.map((step, i) => {
            const km = KIND_META[step.kind] ?? KIND_META.visita;
            return (
              <li
                key={step.id}
                className="animate-rise relative flex gap-3"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                <button
                  onClick={() => toggle(step)}
                  disabled={busy === step.id}
                  aria-label={step.done ? "Marcar pendiente" : "Marcar hecho"}
                  className={`relative z-10 mt-1 flex h-[34px] w-[34px] shrink-0 items-center justify-center rounded-full border-[3px] border-white text-sm font-extrabold shadow-md transition active:scale-90 ${
                    step.done
                      ? "bg-mint-400 text-white"
                      : "bg-white text-stone-300 ring-1 ring-stone-200"
                  }`}
                >
                  {step.done ? "✓" : "○"}
                </button>

                <div
                  className={`flex-1 rounded-2xl px-3.5 py-3 transition ${
                    step.done ? "bg-cream" : "bg-white ring-1 ring-stone-200"
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p
                      className={`text-[13px] font-extrabold leading-tight ${
                        step.done ? "text-ink-700" : "text-ink-900"
                      }`}
                    >
                      {step.title}
                    </p>
                    <span
                      className={`shrink-0 rounded-full px-2 py-0.5 text-[10px] font-extrabold ${km.tint}`}
                    >
                      {km.icon} {step.kind}
                    </span>
                  </div>
                  <p className="mt-0.5 text-[10px] font-bold text-ink-500">
                    📅 {formatDate(step.scheduledFor)}
                  </p>
                  {step.note ? (
                    <p className="mt-1 text-[11px] leading-snug text-ink-700">
                      {step.note}
                    </p>
                  ) : null}
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      <p className="mt-3 text-center text-[10px] font-semibold text-ink-500">
        Toca el círculo para marcar un paso como completado.
      </p>
    </div>
  );
}
