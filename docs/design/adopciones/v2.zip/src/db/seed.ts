import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  applications,
  followUps,
  passports,
  pets,
  vaccines,
} from "@/db/schema";
import { applicationSeeds, petSeeds } from "@/db/seed-data";
import { dateOffset, isoOffset } from "@/lib/dates";

let seedPromise: Promise<void> | null = null;

export async function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedOnce().catch((error) => {
      seedPromise = null;
      console.error("[seed] No se pudo sembrar la base de datos", error);
    });
  }
  return seedPromise;
}

async function seedOnce(): Promise<void> {
  await db.transaction(async (tx) => {
    // Evita duplicados si dos procesos arrancan a la vez.
    await tx.execute(sql`select pg_advisory_xact_lock(918273645)`);

    const existing = await tx
      .select({ count: sql<number>`count(*)::int` })
      .from(pets);
    if ((existing[0]?.count ?? 0) > 0) return;

    const insertedPets = await tx
      .insert(pets)
      .values(
        petSeeds.map((pet, index) => ({
          name: pet.name,
          species: pet.species,
          breed: pet.breed,
          sex: pet.sex,
          ageMonths: pet.ageMonths,
          size: pet.size,
          city: pet.city,
          shelter: pet.shelter,
          tagline: pet.tagline,
          story: pet.story,
          personality: pet.personality,
          photoUrl: pet.photoUrl,
          status: pet.status,
          featured: pet.featured,
          createdAt: dateOffset(-30 - index),
        })),
      )
      .returning({ id: pets.id, name: pets.name });

    const idByKey = new Map<string, number>();
    petSeeds.forEach((pet) => {
      const match = insertedPets.find((row) => row.name === pet.name);
      if (match) idByKey.set(pet.key, match.id);
    });

    const passportRows = petSeeds
      .filter((pet) => pet.passport)
      .map((pet) => ({
        petId: idByKey.get(pet.key)!,
        code: pet.passport!.code,
        vetName: pet.passport!.vetName,
        clinic: pet.passport!.clinic,
        lastCheckup: isoOffset(pet.passport!.lastCheckupOffset),
        weightKg: pet.passport!.weightKg,
        microchipId: pet.passport!.microchipId,
        vaccinesProgress: pet.passport!.progress.vaccines,
        dewormedProgress: pet.passport!.progress.dewormed,
        microchipProgress: pet.passport!.progress.microchip,
        notes: pet.passport!.notes,
        issuedAt: dateOffset(pet.passport!.lastCheckupOffset),
      }));

    if (passportRows.length > 0) {
      await tx.insert(passports).values(passportRows);
    }

    const vaccineRows = petSeeds.flatMap((pet) =>
      (pet.passport?.vaccines ?? []).map((vaccine, index) => ({
        petId: idByKey.get(pet.key)!,
        name: vaccine.name,
        dose: vaccine.dose,
        appliedOn: isoOffset(vaccine.appliedOffset),
        nextDueOn: vaccine.nextDueOffset > 0 ? isoOffset(vaccine.nextDueOffset) : "",
        status: vaccine.status,
        sortOrder: index,
      })),
    );

    if (vaccineRows.length > 0) {
      await tx.insert(vaccines).values(vaccineRows);
    }

    const followUpRows = petSeeds.flatMap((pet) =>
      (pet.plan ?? []).map((event, index) => ({
        petId: idByKey.get(pet.key)!,
        title: event.title,
        description: event.description,
        type: event.type,
        dueOn: isoOffset(event.dueOffset),
        completedAt:
          event.completedOffset !== undefined
            ? dateOffset(event.completedOffset)
            : null,
        sortOrder: index,
      })),
    );

    if (followUpRows.length > 0) {
      await tx.insert(followUps).values(followUpRows);
    }

    const applicationRows = applicationSeeds.map((application) => ({
      petId: idByKey.get(application.petKey)!,
      applicantName: application.applicantName,
      email: application.email,
      phone: application.phone,
      city: application.city,
      housing: application.housing,
      household: application.household,
      experience: application.experience,
      message: application.message,
      status: application.status,
      createdAt: dateOffset(application.createdOffset),
      updatedAt: dateOffset(application.createdOffset),
    }));

    await tx.insert(applications).values(applicationRows);
  });
}
