import Link from "next/link";
import { Screen, ScreenBody, ScreenHeader } from "@/components/Screen";
import { getPets } from "@/lib/data";
import { speciesEmoji } from "@/lib/ui";

export const dynamic = "force-dynamic";

export default async function PasaporteIndexPage() {
  const list = await getPets();

  return (
    <Screen>
      <ScreenHeader
        title="Pasaportes"
        subtitle="Cartilla sanitaria digital de cada peludito"
        backHref="/"
        tone="mint"
        emoji="🪪"
      />
      <ScreenBody>
        <div className="rounded-3xl bg-white p-4 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <p className="text-xs font-semibold leading-relaxed text-ink-700">
            Cada pasaporte incluye microchip, esquema de vacunación,
            desparasitación y un código QR verificable por cualquier
            veterinario.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-3">
          {list.map((pet, i) => (
            <Link
              key={pet.id}
              href={`/pasaporte/${pet.id}`}
              className="animate-rise flex items-center gap-3 rounded-[26px] bg-white p-3 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5 transition active:scale-[0.98]"
              style={{ animationDelay: `${i * 50}ms` }}
            >
              <div className="relative">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={pet.photoUrl}
                  alt={pet.name}
                  className="h-16 w-16 rounded-full object-cover ring-4 ring-sun-200"
                />
                <span className="absolute -bottom-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-white text-xs shadow">
                  {speciesEmoji(pet.species)}
                </span>
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-base font-extrabold">{pet.name}</p>
                <p className="truncate text-[11px] font-semibold text-ink-500">
                  Chip {pet.microchip}
                </p>
                <div className="mt-1.5 flex gap-1.5">
                  <span className="rounded-full bg-mint-100 px-2 py-0.5 text-[10px] font-extrabold text-mint-600">
                    {pet.sterilized ? "Esterilizado" : "Pendiente esteriliz."}
                  </span>
                  <span className="rounded-full bg-cream px-2 py-0.5 text-[10px] font-extrabold text-ink-500">
                    {pet.ageLabel}
                  </span>
                </div>
              </div>
              <span className="text-lg text-ink-500">›</span>
            </Link>
          ))}
        </div>
      </ScreenBody>
    </Screen>
  );
}
