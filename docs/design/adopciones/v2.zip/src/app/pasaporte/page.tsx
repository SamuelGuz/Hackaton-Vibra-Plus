import Link from "next/link";
import {
  ArrowUpRight,
  Check,
  IdCard,
  Microchip,
  ShieldCheck,
  Sparkles,
  Syringe,
} from "lucide-react";
import { ModuleHeader } from "@/components/module-header";
import { PetQr } from "@/components/pet-qr";
import { listPassports } from "@/db/queries";
import { ageLabel, formatDate, speciesLabel } from "@/lib/format";

export const dynamic = "force-dynamic";

function Progress({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-[10px] font-extrabold uppercase tracking-wide text-ink/60">
        <span>{label}</span>
        <span className="flex items-center gap-1">
          {value}%
          {value >= 100 ? (
            <Check className="h-3 w-3 text-mint-600" strokeWidth={3.5} />
          ) : null}
        </span>
      </div>
      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-cream">
        <div
          className={`h-full rounded-full ${tone}`}
          style={{ width: `${Math.min(Math.max(value, 4), 100)}%` }}
        />
      </div>
    </div>
  );
}

export default async function PasaportePage() {
  const rows = await listPassports();

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={IdCard}
        eyebrow="Módulo · Pasaporte"
        title="Pasaporte"
        description="El historial veterinario de cada mascota: vacunas, desparasitación, microchip y notas de su clínica."
        tone="mint"
      >
        <div className="rounded-2xl bg-white/15 px-5 py-4 text-center ring-1 ring-white/25 backdrop-blur-sm">
          <p className="font-display text-3xl font-bold leading-none">
            {rows.length}
          </p>
          <p className="mt-1 text-[10px] font-extrabold uppercase tracking-[0.16em] text-white/80">
            pasaportes
          </p>
        </div>
      </ModuleHeader>

      <div className="grid gap-3 sm:grid-cols-3">
        {[
          {
            icon: Syringe,
            title: "Vacunas registradas",
            text: "Cada dosis con fecha y próxima revisión.",
          },
          {
            icon: ShieldCheck,
            title: "Desparasitación",
            text: "Interna y externa controlada por el refugio.",
          },
          {
            icon: Microchip,
            title: "Microchip",
            text: "Identificación obligatoria desde el primer día.",
          },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.title} className="surface flex items-start gap-3 p-4">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-mint-100 text-mint-700">
                <Icon className="h-4 w-4" />
              </span>
              <div>
                <p className="text-xs font-extrabold">{item.title}</p>
                <p className="mt-0.5 text-[11px] font-medium leading-snug text-muted">
                  {item.text}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {rows.length === 0 ? (
        <div className="card flex flex-col items-center gap-3 px-6 py-14 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-full bg-mint-100 text-mint-700">
            <IdCard className="h-7 w-7" />
          </span>
          <h2 className="font-display text-xl font-bold">
            Todavía no hay pasaportes
          </h2>
          <p className="max-w-sm text-sm font-medium text-muted">
            El pasaporte se genera automáticamente cuando se aprueba una
            solicitud de adopción.
          </p>
          <Link href="/solicitudes" className="btn-mint mt-2">
            Ir a solicitudes
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {rows.map(({ pet, passport }) => (
            <article
              key={passport.id}
              className="card group relative overflow-hidden p-0 transition hover:-translate-y-1"
            >
              <div className="absolute inset-y-0 left-0 w-2.5 bg-mint-300" />
              <div className="absolute inset-y-0 right-0 w-2.5 bg-mint-300" />
              <div className="flex flex-col gap-4 p-5 pl-6 sm:flex-row">
                <div className="flex flex-col items-center gap-2">
                  <div className="relative h-24 w-24 overflow-hidden rounded-full ring-4 ring-sun-300">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={pet.photoUrl}
                      alt={pet.name}
                      className="h-full w-full object-cover"
                      loading="lazy"
                    />
                    <span className="absolute bottom-0 right-0 grid h-7 w-7 place-items-center rounded-full bg-mint-500 text-white ring-2 ring-white">
                      <Check className="h-3.5 w-3.5" strokeWidth={3.5} />
                    </span>
                  </div>
                  <PetQr value={passport.code} className="h-14 w-14" />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-[10px] font-extrabold uppercase tracking-[0.16em] text-mint-600">
                        {speciesLabel(pet.species)} · {ageLabel(pet.ageMonths)}
                      </p>
                      <h2 className="font-display text-2xl font-bold leading-none">
                        {pet.name}
                      </h2>
                    </div>
                    <span className="rounded-full bg-cream px-2 py-1 text-[10px] font-extrabold tracking-wide text-ink/60 ring-1 ring-line">
                      {passport.code}
                    </span>
                  </div>

                  <div className="mt-3 space-y-2">
                    <Progress
                      label="Vacunas"
                      value={passport.vaccinesProgress}
                      tone="bg-coral-400"
                    />
                    <Progress
                      label="Desparasitado"
                      value={passport.dewormedProgress}
                      tone="bg-mint-400"
                    />
                    <Progress
                      label="Microchip"
                      value={passport.microchipProgress}
                      tone="bg-sun-400"
                    />
                  </div>

                  <div className="mt-3 flex items-end justify-between gap-2 border-t border-line/70 pt-3">
                    <p className="text-[10px] font-bold leading-tight text-muted">
                      Última revisión
                      <span className="mt-0.5 block font-extrabold text-ink/70">
                        {formatDate(passport.lastCheckup)}
                      </span>
                    </p>
                    <Link
                      href={`/pasaporte/${pet.id}`}
                      className="inline-flex items-center gap-1.5 rounded-full bg-mint-500 px-3.5 py-2 text-xs font-extrabold text-white shadow-[0_10px_20px_-10px_rgba(76,185,171,0.9)] transition hover:bg-mint-600"
                    >
                      Abrir
                      <ArrowUpRight className="h-3.5 w-3.5" strokeWidth={2.8} />
                    </Link>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      <div className="surface flex items-start gap-3 p-4">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-mint-100 text-mint-700">
          <Sparkles className="h-4 w-4" />
        </span>
        <p className="text-xs font-medium leading-relaxed text-muted">
          <span className="font-extrabold text-ink">¿Pasaporte incompleto?</span>{" "}
          Cada dosis pendiente aparece marcada en ámbar. El refugio actualiza el
          calendario tras cada visita veterinaria, y tú puedes seguir el detalle
          desde el módulo de seguimiento.
        </p>
      </div>
    </div>
  );
}
