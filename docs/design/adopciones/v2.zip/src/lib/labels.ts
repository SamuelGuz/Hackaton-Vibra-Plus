export const appStatusMetaMap = {
  en_proceso: {
    label: "En proceso",
    pill: "bg-sun-100 text-amber-800 ring-amber-200/80",
    dot: "bg-amber-400",
    soft: "bg-sun-100",
    text: "text-amber-800",
  },
  aprobada: {
    label: "Aprobada",
    pill: "bg-mint-100 text-mint-700 ring-mint-200",
    dot: "bg-mint-500",
    soft: "bg-mint-100",
    text: "text-mint-700",
  },
  rechazada: {
    label: "Rechazada",
    pill: "bg-rose-100 text-rose-700 ring-rose-200/80",
    dot: "bg-rose-400",
    soft: "bg-rose-100",
    text: "text-rose-700",
  },
} as const;

export type AppStatus = keyof typeof appStatusMetaMap;

export function appStatusMeta(status: string) {
  return (
    appStatusMetaMap[status as AppStatus] ?? {
      ...appStatusMetaMap.en_proceso,
      label: status,
    }
  );
}

export const petStatusMetaMap = {
  disponible: {
    label: "Disponible",
    pill: "bg-mint-100 text-mint-700 ring-mint-200",
    hero: "bg-mint-500",
  },
  en_proceso: {
    label: "En proceso",
    pill: "bg-sun-100 text-amber-800 ring-amber-200/80",
    hero: "bg-sun-400",
  },
  adoptado: {
    label: "Adoptado",
    pill: "bg-coral-100 text-coral-700 ring-coral-200",
    hero: "bg-coral-500",
  },
} as const;

export type PetStatus = keyof typeof petStatusMetaMap;

export function petStatusMeta(status: string) {
  return (
    petStatusMetaMap[status as PetStatus] ?? {
      ...petStatusMetaMap.disponible,
      label: status,
    }
  );
}
