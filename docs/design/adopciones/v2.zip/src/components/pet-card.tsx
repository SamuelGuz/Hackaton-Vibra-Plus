import Link from "next/link";
import { ArrowUpRight, MapPin, Mars, Venus } from "lucide-react";
import type { Pet } from "@/db/schema";
import { ageLabel } from "@/lib/format";
import { FavoriteButton } from "@/components/favorite-button";
import { PetStatusPill } from "@/components/status-pill";

export function PetCard({ pet }: { pet: Pet }) {
  return (
    <article className="card group overflow-hidden transition duration-300 hover:-translate-y-1 hover:shadow-[0_28px_50px_-24px_rgba(92,58,40,0.5)]">
      <div className="relative aspect-[4/5] overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={pet.photoUrl}
          alt={`${pet.name}, ${pet.breed} en adopción`}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.06]"
          loading="lazy"
        />
        <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-2 bg-gradient-to-b from-black/30 to-transparent p-3 pb-8">
          <PetStatusPill status={pet.status} />
          <FavoriteButton petId={pet.id} petName={pet.name} />
        </div>
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/65 via-black/20 to-transparent p-3 pt-10">
          <p className="flex items-center gap-1 text-[11px] font-extrabold uppercase tracking-wide text-white/90">
            <MapPin className="h-3 w-3" />
            {pet.city}
            <span className="mx-1 opacity-50">·</span>
            {pet.shelter}
          </p>
        </div>
      </div>

      <div className="space-y-3 p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <h3 className="font-display text-xl font-bold leading-tight text-ink">
              {pet.name}
            </h3>
            <p className="text-xs font-bold text-muted">{pet.breed}</p>
          </div>
          <span
            className={`flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-extrabold ring-1 ${
              pet.sex === "hembra"
                ? "bg-coral-50 text-coral-600 ring-coral-100"
                : "bg-sky-50 text-sky-700 ring-sky-100"
            }`}
          >
            {pet.sex === "hembra" ? (
              <Venus className="h-3 w-3" />
            ) : (
              <Mars className="h-3 w-3" />
            )}
            {pet.sex === "hembra" ? "Hembra" : "Macho"}
          </span>
        </div>

        <p className="line-clamp-2 min-h-10 text-[13px] font-medium leading-snug text-muted">
          {pet.tagline}
        </p>

        <div className="flex items-center justify-between gap-2 border-t border-line/70 pt-3">
          <div className="flex flex-wrap gap-1.5 text-[11px]">
            <span className="chip px-2.5 py-1">{ageLabel(pet.ageMonths)}</span>
            <span className="chip px-2.5 py-1">{pet.size}</span>
          </div>
          <Link
            href={`/mascotas/${pet.id}`}
            className="inline-flex items-center gap-1.5 rounded-full bg-coral-500 px-3.5 py-2 text-xs font-extrabold text-white shadow-pop transition hover:bg-coral-600 active:scale-95"
          >
            Ver
            <ArrowUpRight className="h-3.5 w-3.5" strokeWidth={2.8} />
          </Link>
        </div>
      </div>
    </article>
  );
}
