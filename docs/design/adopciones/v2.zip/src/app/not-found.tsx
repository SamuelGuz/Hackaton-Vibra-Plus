import Link from "next/link";
import { ArrowLeft, PawPrint, Search } from "lucide-react";

export default function NotFound() {
  return (
    <div className="card mx-auto flex max-w-xl flex-col items-center gap-4 px-6 py-16 text-center">
      <span className="relative grid h-20 w-20 place-items-center rounded-full bg-coral-50 text-coral-500">
        <PawPrint className="h-10 w-10" />
        <span className="absolute -right-1 -top-1 grid h-8 w-8 place-items-center rounded-full bg-white text-coral-500 shadow-soft">
          <Search className="h-4 w-4" />
        </span>
      </span>
      <p className="text-[11px] font-extrabold uppercase tracking-[0.2em] text-coral-500">
        Error 404
      </p>
      <h1 className="font-display text-3xl font-bold leading-tight">
        Esta huella no lleva a ninguna parte
      </h1>
      <p className="max-w-sm text-sm font-medium leading-relaxed text-muted">
        No encontramos la mascota o la página que buscas. Puede que ya haya
        encontrado familia o que el enlace esté mal.
      </p>
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        <Link href="/#mascotas" className="btn-primary">
          <PawPrint className="h-4 w-4" />
          Ver mascotas
        </Link>
        <Link href="/" className="btn-outline">
          <ArrowLeft className="h-4 w-4" />
          Volver al inicio
        </Link>
      </div>
    </div>
  );
}
