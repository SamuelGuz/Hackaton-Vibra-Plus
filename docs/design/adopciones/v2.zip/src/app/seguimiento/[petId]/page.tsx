import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  ArrowUpRight,
  CalendarDays,
  Camera,
  Check,
  Clock,
  IdCard,
  Mail,
  MapPin,
  PawPrint,
  Phone,
  Route,
  Stethoscope,
  UserRound,
} from "lucide-react";
import { FollowUpForm } from "@/components/follow-up-form";
import { FollowUpToggle } from "@/components/follow-up-toggle";
import { ApplicationStatusPill, PetStatusPill } from "@/components/status-pill";
import { getFollowUpBundle } from "@/db/queries";
import { daysUntil } from "@/lib/dates";
import { ageLabel, formatDate, followUpTypeMeta, shortDate } from "@/lib/format";

export const dynamic = "force-dynamic";

const typeIcons = {
  visita: PawPrint,
  vacuna: Stethoscope,
  foto: Camera,
  llamada: Phone,
} as const;

export async function generateMetadata({
  params,
}: {
  params: Promise<{ petId: string }>;
}) {
  const { petId } = await params;
  const bundle = await getFollowUpBundle(Number(petId));
  return {
    title: bundle
      ? `Seguimiento de ${bundle.pet.name} — Huellitas`
      : "Seguimiento — Huellitas",
  };
}

export default async function SeguimientoDetallePage({
  params,
}: {
  params: Promise<{ petId: string }>;
}) {
  const { petId } = await params;
  const id = Number(petId);
  if (!Number.isInteger(id)) notFound();

  const bundle = await getFollowUpBundle(id);
  if (!bundle) notFound();

  const { pet, application, events, passport } = bundle;
  const completed = events.filter((event) => event.completedAt).length;
  const progress = events.length > 0 ? Math.round((completed / events.length) * 100) : 0;
  const nextEvent = events.find((event) => !event.completedAt) ?? null;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          href="/seguimiento"
          className="inline-flex items-center gap-2 rounded-full border border-white bg-white/80 px-3.5 py-2 text-xs font-extrabold text-ink shadow-soft transition hover:bg-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Todos los seguimientos
        </Link>
        <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-muted">
          Módulo Seguimiento
          <span className="h-1 w-1 rounded-full bg-coral-300" />
          {completed}/{events.length} hitos
        </p>
      </div>

      {/* Resumen */}
      <section className="card relative overflow-hidden p-5 sm:p-6">
        <div aria-hidden className="absolute -right-10 -top-12 h-40 w-40 rounded-full bg-coral-50" />
        <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center">
          <div className="relative mx-auto h-24 w-24 shrink-0 sm:mx-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={pet.photoUrl}
              alt={`${pet.name}, ${pet.breed}`}
              className="h-full w-full rounded-full object-cover ring-4 ring-sun-200"
            />
            <span className="absolute -bottom-1 -right-1 grid h-8 w-8 place-items-center rounded-full bg-mint-500 text-white ring-4 ring-white">
              <Check className="h-4 w-4" strokeWidth={3.5} />
            </span>
          </div>

          <div className="min-w-0 flex-1 text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
              <PetStatusPill status={pet.status} />
              {application ? <ApplicationStatusPill status={application.status} /> : null}
            </div>
            <h1 className="mt-2 font-display text-3xl font-bold leading-none sm:text-4xl">
              {pet.name}
            </h1>
            <p className="mt-1 text-xs font-bold text-muted">
              {pet.breed} · {ageLabel(pet.ageMonths)} · {pet.city}
            </p>

            <div className="mt-3 flex flex-col items-center gap-1.5 sm:items-start">
              <div className="flex w-full max-w-sm items-center justify-between text-[10px] font-extrabold uppercase tracking-wide text-ink/60">
                <span>Progreso del plan</span>
                <span>{progress}%</span>
              </div>
              <div className="h-2 w-full max-w-sm overflow-hidden rounded-full bg-cream">
                <div
                  className="h-full rounded-full bg-mint-400 transition-all"
                  style={{ width: `${Math.min(Math.max(progress, 2), 100)}%` }}
                />
              </div>
            </div>
          </div>

          <div className="shrink-0 rounded-2xl bg-sun-100 px-4 py-3 text-center ring-1 ring-sun-200">
            <p className="flex items-center justify-center gap-1 text-[9px] font-extrabold uppercase tracking-[0.14em] text-amber-900/70">
              <CalendarDays className="h-3 w-3" />
              {nextEvent ? "Próximo hito" : "Estado"}
            </p>
            <p className="mt-1 font-display text-lg font-bold leading-tight text-amber-900">
              {nextEvent ? nextEvent.title : "Plan completado"}
            </p>
            <p className="text-[10px] font-extrabold text-amber-900/70">
              {nextEvent ? shortDate(nextEvent.dueOn) : `${events.length} hitos`}
            </p>
          </div>
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-[1.22fr_0.78fr]">
        {/* Línea de tiempo */}
        <section className="card p-5 sm:p-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <p className="eyebrow">
                <Route className="h-3.5 w-3.5" />
                Línea de tiempo
              </p>
              <h2 className="section-title mt-2">Acompañamiento post-adopción</h2>
            </div>
            <span className="rounded-full bg-cream px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wide text-ink/60 ring-1 ring-line">
              {completed} de {events.length} completados
            </span>
          </div>

          {events.length === 0 ? (
            <p className="mt-6 rounded-2xl bg-cream/70 px-4 py-6 text-center text-sm font-medium text-muted">
              Todavía no hay hitos. Añade el primero desde el panel de la derecha.
            </p>
          ) : (
            <ol className="relative mt-6 before:absolute before:bottom-4 before:left-[17px] before:top-2 before:w-0.5 before:rounded-full before:bg-line lg:before:left-1/2">
              {events.map((event, index) => {
                const done = Boolean(event.completedAt);
                const meta = followUpTypeMeta[event.type as keyof typeof followUpTypeMeta] ?? followUpTypeMeta.visita;
                const Icon = typeIcons[event.type as keyof typeof typeIcons] ?? PawPrint;
                const left = index % 2 === 0;
                const overdue = !done && (daysUntil(event.dueOn) ?? 0) < 0;

                return (
                  <li
                    key={event.id}
                    className="relative pb-5 last:pb-0 lg:grid lg:grid-cols-[1fr_64px_1fr] lg:items-center lg:gap-3"
                  >
                    <div
                      className={`ml-11 lg:ml-0 ${
                        left ? "lg:col-start-1 lg:pr-2" : "lg:col-start-3 lg:row-start-1 lg:pl-2"
                      }`}
                    >
                      <div
                        className={`rounded-2xl border p-4 transition ${
                          done
                            ? "border-mint-100 bg-white"
                            : overdue
                              ? "border-rose-100 bg-rose-50/40"
                              : "border-sun-200 bg-sun-100/30"
                        }`}
                      >
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-extrabold ${
                              done ? "bg-mint-100 text-mint-700" : meta.color
                            }`}
                          >
                            <Icon className="h-3 w-3" />
                            {meta.label}
                          </span>
                          <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-wide text-muted">
                            <CalendarDays className="h-3 w-3" />
                            {shortDate(event.dueOn)}
                          </span>
                          {overdue ? (
                            <span className="rounded-full bg-rose-100 px-2 py-0.5 text-[10px] font-extrabold text-rose-700">
                              Vencido
                            </span>
                          ) : null}
                        </div>

                        <p className="mt-1.5 font-display text-lg font-bold leading-tight text-ink">
                          {event.title}
                        </p>
                        {event.description ? (
                          <p className="mt-1 text-xs font-medium leading-snug text-muted">
                            {event.description}
                          </p>
                        ) : null}

                        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
                          <span className={`inline-flex items-center gap-1 text-[10px] font-extrabold ${done ? "text-mint-700" : "text-muted"}`}>
                            {done ? (
                              <>
                                <Check className="h-3 w-3" strokeWidth={3.5} />
                                {formatDate(event.completedAt)}
                              </>
                            ) : (
                              <>
                                <Clock className="h-3 w-3" />
                                Pendiente
                              </>
                            )}
                          </span>
                          <FollowUpToggle followUpId={event.id} completed={done} />
                        </div>
                      </div>
                    </div>

                    <div className="absolute left-0 top-3 lg:static lg:col-start-2 lg:row-start-1 lg:justify-self-center">
                      <span
                        className={`grid h-9 w-9 place-items-center rounded-full ring-4 ring-white ${
                          done
                            ? "bg-mint-500 text-white"
                            : overdue
                              ? "bg-rose-400 text-white"
                              : "bg-sun-300 text-amber-900"
                        }`}
                      >
                        {done ? (
                          <Check className="h-4 w-4" strokeWidth={3.5} />
                        ) : (
                          <Clock className="h-4 w-4" />
                        )}
                      </span>
                    </div>
                  </li>
                );
              })}
            </ol>
          )}
        </section>

        {/* Panel lateral */}
        <aside className="space-y-4">
          <FollowUpForm petId={pet.id} petName={pet.name} />

          <section className="card p-5">
            <p className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-ink/60">
              <UserRound className="h-4 w-4" />
              Familia adoptante
            </p>
            {application ? (
              <div className="mt-2 space-y-1.5">
                <p className="font-display text-lg font-bold leading-tight">
                  {application.applicantName}
                </p>
                <p className="flex items-center gap-1.5 text-xs font-semibold text-muted">
                  <Mail className="h-3.5 w-3.5 text-coral-400" />
                  {application.email}
                </p>
                <p className="flex items-center gap-1.5 text-xs font-semibold text-muted">
                  <Phone className="h-3.5 w-3.5 text-coral-400" />
                  {application.phone}
                </p>
                <p className="flex items-center gap-1.5 text-xs font-semibold text-muted">
                  <MapPin className="h-3.5 w-3.5 text-coral-400" />
                  {application.city} · {application.housing}
                </p>
                <p className="rounded-xl bg-cream/80 px-3 py-2 text-[11px] font-medium italic leading-snug text-ink/70">
                  “{application.message}”
                </p>
              </div>
            ) : (
              <p className="mt-2 text-xs font-medium text-muted">
                Aún no hay una solicitud asociada a {pet.name}.
              </p>
            )}
          </section>

          <section className="card p-5">
            <p className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-ink/60">
              <IdCard className="h-4 w-4" />
              Salud
            </p>
            {passport ? (
              <div className="mt-2 space-y-2 text-xs font-semibold text-muted">
                <p>
                  Pasaporte{" "}
                  <span className="font-extrabold text-ink">{passport.code}</span>
                </p>
                <p>{passport.clinic} · {passport.vetName}</p>
                <p>Última revisión: {formatDate(passport.lastCheckup)}</p>
                <Link
                  href={`/pasaporte/${pet.id}`}
                  className="inline-flex items-center gap-1.5 rounded-full bg-mint-50 px-3 py-2 text-[11px] font-extrabold text-mint-700 ring-1 ring-mint-100 transition hover:bg-mint-100"
                >
                  Abrir pasaporte
                  <ArrowUpRight className="h-3 w-3" />
                </Link>
              </div>
            ) : (
              <p className="mt-2 text-xs font-medium text-muted">
                Sin pasaporte emitido todavía. Se genera al aprobar la adopción.
              </p>
            )}
          </section>

          <section className="surface flex flex-col gap-2 p-4">
            <Link href={`/mascotas/${pet.id}`} className="btn-outline w-full text-xs">
              <PawPrint className="h-4 w-4" />
              Ver ficha de {pet.name}
            </Link>
            <Link href="/solicitudes" className="btn-ghost w-full text-xs">
              Gestionar solicitudes
            </Link>
          </section>
        </aside>
      </div>
    </div>
  );
}
