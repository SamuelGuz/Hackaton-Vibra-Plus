import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * Mascotas disponibles para adopción.
 */
export const pets = pgTable("pets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  species: text("species").notNull(), // perro | gato
  breed: text("breed").notNull(),
  sex: text("sex").notNull(), // macho | hembra
  ageMonths: integer("age_months").notNull(),
  size: text("size").notNull(), // pequeño | mediano | grande
  city: text("city").notNull(),
  shelter: text("shelter").notNull(),
  tagline: text("tagline").notNull(),
  story: text("story").notNull(),
  personality: text("personality").array().notNull(),
  photoUrl: text("photo_url").notNull(),
  status: text("status").notNull().default("disponible"), // disponible | en_proceso | adoptado
  featured: boolean("featured").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/**
 * Solicitudes de adopción.
 */
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id")
    .notNull()
    .references(() => pets.id, { onDelete: "cascade" }),
  applicantName: text("applicant_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  city: text("city").notNull(),
  housing: text("housing").notNull(),
  household: text("household").notNull(),
  experience: text("experience").notNull().default(""),
  message: text("message").notNull().default(""),
  status: text("status").notNull().default("en_proceso"), // en_proceso | aprobada | rechazada
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

/**
 * Pasaporte veterinario de cada mascota.
 */
export const passports = pgTable("passports", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id")
    .notNull()
    .unique()
    .references(() => pets.id, { onDelete: "cascade" }),
  code: text("code").notNull(),
  vetName: text("vet_name").notNull(),
  clinic: text("clinic").notNull(),
  lastCheckup: text("last_checkup").notNull(),
  weightKg: text("weight_kg").notNull(),
  microchipId: text("microchip_id").notNull(),
  vaccinesProgress: integer("vaccines_progress").notNull().default(100),
  dewormedProgress: integer("dewormed_progress").notNull().default(100),
  microchipProgress: integer("microchip_progress").notNull().default(100),
  notes: text("notes").notNull().default(""),
  issuedAt: timestamp("issued_at", { withTimezone: true }).defaultNow().notNull(),
});

/**
 * Vacunas incluidas en el pasaporte.
 */
export const vaccines = pgTable("vaccines", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id")
    .notNull()
    .references(() => pets.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  dose: text("dose").notNull(),
  appliedOn: text("applied_on").notNull(),
  nextDueOn: text("next_due_on").notNull().default(""),
  status: text("status").notNull().default("completa"), // completa | pendiente
  sortOrder: integer("sort_order").notNull().default(0),
});

/**
 * Hitos del seguimiento post-adopción.
 */
export const followUps = pgTable("follow_ups", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id")
    .notNull()
    .references(() => pets.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  type: text("type").notNull().default("visita"), // visita | vacuna | foto | llamada
  dueOn: text("due_on").notNull(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Pet = typeof pets.$inferSelect;
export type NewPet = typeof pets.$inferInsert;
export type Application = typeof applications.$inferSelect;
export type NewApplication = typeof applications.$inferInsert;
export type Passport = typeof passports.$inferSelect;
export type Vaccine = typeof vaccines.$inferSelect;
export type FollowUp = typeof followUps.$inferSelect;
