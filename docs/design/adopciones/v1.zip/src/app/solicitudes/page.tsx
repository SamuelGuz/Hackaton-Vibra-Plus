import Link from "next/link";
import { Screen, ScreenBody, ScreenHeader } from "@/components/Screen";
import { getApplications } from "@/lib/data";
import { STATUS_META, formatDate, initials } from "@/lib/ui";

export const dynamic = "force-dynamic";

const TABS = [
  { key: "todas", label: "Todas" },
  { key: "pendiente", label: "Pendientes" },
  { key: "en_proceso", label: "En proceso" },
  { key: "aprobado", label: "Aprobadas" },
];

export default async function SolicitudesPage({
  searchParams,
}: {
  searchParams: Promise<{ estado?: string }>;
}) {
  const { estado = "todas" } = await searchParams;
  const all = await getApplications();
  const list = estado === "todas" ? all : all.filter((a) => a.status === estado);

  return (
    <Screen>
      <ScreenHeader
        title="Solicitudes"
        subtitle={`${all.length} postulaciones registradas`}
        backHref="/"
        tone="coral"
        emoji="📋"
      />
      <ScreenBody>
        <div className="no-scrollbar -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
          {TABS.map((t) => {
            const active = t.key === estado;
            const count =
              t.key === "todas"
                ? all.length
                : all.filter((a) => a.status === t.key).length;
            return (
              <Link
                key={t.key}
                href={`/solicitudes?estado=${t.key}`}
                className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-extrabold transition ${
                  active
                    ? "bg-ink-900 text-white shadow-md"
                    : "bg-white text-ink-700 ring-1 ring-black/5"
                }`}
              >
                {t.label}
                <span
                  className={`rounded-full px-1.5 text-[10px] ${
                    active ? "bg-white/20" : "bg-cream text-ink-500"
                  }`}
                >
                  {count}
                </span>
              </Link>
            );
          })}
        </div>

        {list.length === 0 ? (
          <div className="rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-black/5">
            <p className="text-4xl">📭</p>
            <p className="mt-2 text-sm font-bold">Sin solicitudes aquí</p>
            <Link
              href="/"
              className="mt-3 inline-block rounded-full bg-coral-500 px-4 py-2 text-xs font-extrabold text-white"
            >
              Explorar peluditos
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {list.map((app, i) => {
              const meta = STATUS_META[app.status] ?? STATUS_META.pendiente;
              return (
                <div
                  key={app.id}
                  className="animate-rise rounded-[26px] bg-white p-3 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5"
                  style={{ animationDelay: `${i * 55}ms` }}
                >
                  <div className="flex gap-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={app.pet.photoUrl}
                      alt={app.pet.name}
                      className="h-[72px] w-[72px] shrink-0 rounded-2xl object-cover"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <p className="truncate text-base font-extrabold leading-tight">
                            {app.pet.name}
                          </p>
                          <p className="truncate text-[11px] font-semibold text-ink-500">
                            {app.pet.breed} · {app.pet.city}
                          </p>
                        </div>
                        <span
                          className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-extrabold ${meta.chip}`}
                        >
                          {meta.label}
                        </span>
                      </div>

                      <div className="mt-2 flex items-center gap-1.5">
                        <span className="flex h-5 w-5 items-center justify-center rounded-full bg-mint-200 text-[9px] font-extrabold text-mint-600">
                          {initials(app.applicantName)}
                        </span>
                        <span className="truncate text-[11px] font-bold text-ink-700">
                          {app.applicantName}
                        </span>
                        <span className="ml-auto shrink-0 text-[10px] font-semibold text-ink-500">
                          {formatDate(
                            new Date(app.createdAt).toISOString().slice(0, 10),
                          )}
                        </span>
                      </div>

                      <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-stone-200">
                        <div
                          className={`h-full rounded-full ${meta.bar} transition-all`}
                          style={{ width: `${app.progress}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 flex gap-2">
                    <Link
                      href={`/solicitudes/${app.id}`}
                      className="flex-1 rounded-2xl bg-coral-500 py-2.5 text-center text-xs font-extrabold text-white shadow-md shadow-coral-200 transition active:scale-95"
                    >
                      Ver solicitud
                    </Link>
                    <Link
                      href={`/seguimiento/${app.id}`}
                      className="rounded-2xl bg-cream px-3.5 py-2.5 text-center text-xs font-extrabold text-ink-700 ring-1 ring-stone-200"
                    >
                      Seguimiento
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScreenBody>
    </Screen>
  );
}
