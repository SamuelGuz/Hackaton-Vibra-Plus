"use client";

import { useState } from "react";
import { Check, Printer, Share2 } from "lucide-react";

export function PassportActions({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);

  async function share() {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({
          title: `Pasaporte ${code}`,
          text: "Pasaporte veterinario de Huellitas",
          url,
        });
        return;
      }
      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setCopied(false);
    }
  }

  return (
    <div className="flex flex-wrap gap-2 no-print">
      <button type="button" onClick={() => window.print()} className="btn-primary px-4 py-2.5 text-xs">
        <Printer className="h-4 w-4" />
        Descargar pasaporte
      </button>
      <button type="button" onClick={share} className="btn-outline px-4 py-2.5 text-xs">
        {copied ? (
          <>
            <Check className="h-4 w-4 text-mint-600" />
            Enlace copiado
          </>
        ) : (
          <>
            <Share2 className="h-4 w-4" />
            Compartir
          </>
        )}
      </button>
    </div>
  );
}
