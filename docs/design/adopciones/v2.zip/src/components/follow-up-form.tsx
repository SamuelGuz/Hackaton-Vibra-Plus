"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { CalendarPlus, Loader2, Plus, Send, X } from "lucide-react";

type Errors = Record<string, string>;

const types = [
  { value: "visita", label: "Visita al hogar" },
  { value: "vacuna", label: "Vacuna / refuerzo" },
  { value: "foto", label: "Foto de actualización" },
  { value: "llamada", label: "Llamada de seguimiento" },
];

export function FollowUpForm({ petId, petName }: { petId: number; petName: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [sending, setSending] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [globalError, setGlobalError] = useState<string | null>(null);

  const [form, setForm] = useState({
    title: "",
    type: "visita",
    dueOn: new Date().toISOString().slice(0, 10),
    description: "",
  });

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSending(true);
    setErrors({});
    setGlobalError(null);
    try {
      const response = await fetch("/api/follow-ups", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, petId }),
      });
      const data = (await response.json().catch(() => null)) as {
        ok?: boolean;
        errors?: Errors;
        error?: string;
      } | null;

      if (!response.ok || !data?.ok) {
        setErrors(data?.errors ?? {});
        setGlobalError(data?.error ?? "Revisa los datos del hito.");
        return;
      }

      setForm({
        title: "",
        type: "visita",
        dueOn: new Date().toISOString().slice(0, 10),
        description: "",
      });
      setOpen(false);
      startTransition(() => router.refresh());
    } catch {
      setGlobalError("No pudimos guardar el hito. Inténtalo de nuevo.");
    } finally {
      setSending(false);
    }
  }

  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="btn-mint w-full text-xs">
        <Plus className="h-4 w-4" />
        Añadir hito al seguimiento de {petName}
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="card animate-pop space-y-3 p-5">
      <div className="flex items-center justify-between">
        <p className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.14em] text-mint-700">
          <CalendarPlus className="h-4 w-4" />
          Nuevo hito
        </p>
        <button
          type="button"
          onClick={() => setOpen(false)}
          className="grid h-7 w-7 place-items-center rounded-full bg-cream text-ink/60 hover:bg-shell"
          aria-label="Cerrar formulario"
        >
          <X className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block sm:col-span-2">
          <span className="label">Título</span>
          <input
            className="input"
            value={form.title}
            onChange={(event) =>
              setForm((current) => ({ ...current, title: event.target.value }))
            }
            placeholder="Visita 3 · revisión de peso"
            required
          />
          {errors.title ? (
            <span className="mt-1 block text-[11px] font-bold text-rose-600">
              {errors.title}
            </span>
          ) : null}
        </label>

        <label className="block">
          <span className="label">Tipo</span>
          <select
            className="input"
            value={form.type}
            onChange={(event) =>
              setForm((current) => ({ ...current, type: event.target.value }))
            }
          >
            {types.map((type) => (
              <option key={type.value} value={type.value}>
                {type.label}
              </option>
            ))}
          </select>
        </label>

        <label className="block">
          <span className="label">Fecha</span>
          <input
            type="date"
            className="input"
            value={form.dueOn}
            onChange={(event) =>
              setForm((current) => ({ ...current, dueOn: event.target.value }))
            }
            required
          />
          {errors.dueOn ? (
            <span className="mt-1 block text-[11px] font-bold text-rose-600">
              {errors.dueOn}
            </span>
          ) : null}
        </label>
      </div>

      <label className="block">
        <span className="label">Descripción (opcional)</span>
        <textarea
          className="input min-h-20 resize-y"
          value={form.description}
          onChange={(event) =>
            setForm((current) => ({ ...current, description: event.target.value }))
          }
          placeholder="Detalles de la visita, objetivos o material necesario"
        />
      </label>

      {globalError ? (
        <p className="rounded-xl bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700">
          {globalError}
        </p>
      ) : null}

      <button type="submit" disabled={sending || isPending} className="btn-primary w-full">
        {sending || isPending ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <Send className="h-4 w-4" />
        )}
        Guardar hito
      </button>
    </form>
  );
}
