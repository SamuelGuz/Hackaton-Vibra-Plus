export function ageLabel(months: number): string {
  if (months < 12) return `${months} ${months === 1 ? "mes" : "meses"}`;
  const years = Math.floor(months / 12);
  const rest = months % 12;
  if (rest === 0) return `${years} ${years === 1 ? "año" : "años"}`;
  return `${years} a ${years + 1} años`;
}

export function speciesLabel(species: string): string {
  return species === "gato" ? "Gato" : "Perro";
}

export function speciesEmoji(species: string): string {
  return species === "gato" ? "🐱" : "🐶";
}

export function formatDate(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(`${value}T12:00:00`) : value;
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat("es-ES", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function shortDate(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(`${value}T12:00:00`) : value;
  if (Number.isNaN(date.getTime())) return String(value);
  return new Intl.DateTimeFormat("es-ES", {
    day: "2-digit",
    month: "short",
  }).format(date);
}

export const followUpTypeMeta = {
  visita: { label: "Visita", emoji: "🏡", color: "bg-mint-100 text-mint-700" },
  vacuna: { label: "Vacuna", emoji: "💉", color: "bg-amber-100 text-amber-800" },
  foto: { label: "Foto", emoji: "📸", color: "bg-sky-100 text-sky-800" },
  llamada: { label: "Llamada", emoji: "📞", color: "bg-coral-100 text-coral-700" },
} as const;

export type FollowUpType = keyof typeof followUpTypeMeta;
