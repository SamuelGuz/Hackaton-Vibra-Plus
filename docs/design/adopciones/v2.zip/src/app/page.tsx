import Link from "next/link";
import {
  ArrowRight,
  ArrowUpRight,
  Camera,
  Check,
  ClipboardList,
  HandHeart,
  IdCard,
  MapPin,
  PawPrint,
  Route,
  ShieldCheck,
  Sparkles,
  Syringe,
} from "lucide-react";
import { PetCard } from "@/components/pet-card";
import { getApplicationCounts, getStats, listFollowUpSummaries, listPassports, listPets } from "@/db/queries";
import { shortDate } from "@/lib/format";

export const dynamic = "force-dynamic";

const filters = [
  { key: undefined, label: "Todos", emoji: "🐾" },
  { key: "perro", label: "Perros", emoji: "🐶" },
  { key: "gato", label: "Gatos", emoji: "🐱" },
] as const;

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ especie?: string }>;
}) {
  const { especie } = await searchParams;
  const activeSpecies =
    especie === "perro" || especie === "gato" ? especie : undefined;

  const [petList, stats, counts, passportList, followUpList] = await Promise.all([
    listPets(activeSpecies),
    getStats(),
    getApplicationCounts(),
    listPassports(),
    listFollowUpSummaries(),
  ]);

  const featured = petList[0];
  const pendingFollowUp = followUpList.find(
    (item) => item.nextTitle && item.completed < item.total,
  );

  const modules = [
    {
      href: "/solicitudes",
      label: "Solicitudes",
      text: "Revisa, aprueba y acompaña cada petición de adopción.",
      icon: ClipboardList,
      accent: "bg-coral-50 text-coral-600",
      badge: `${counts.todas} recibidas`,
    },
    {
      href: featured ? `/mascotas/${featured.id}` : "/#mascotas",
      label: "Detalle",
      text: "Conoce su historia, carácter y todo lo que necesita.",
      icon: PawPrint,
      accent: "bg-sun-100 text-amber-700",
      badge: featured ? `${featured.name} te espera` : "Conócelos",
    },
    {
      href: "/pasaporte",
      label: "Pasaporte",
      text: "Vacunas, desparasitación y microchip siempre al día.",
      icon: IdCard,
      accent: "bg-mint-100 text-mint-700",
      badge: `${passportList.length} pasaportes`,
    },
    {
      href: "/seguimiento",
      label: "Seguimiento",
      text: "Visitas y refuerzos tras la adopción, paso a paso.",
      icon: Route,
      accent: "bg-sky-50 text-sky-700",
      badge: `${followUpList.length} en curso`,
    },
  ];

  return (
    <div className="space-y-12 sm:space-y-14">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-[32px] bg-coral-500 text-white shadow-soft sm:rounded-[38px]">
        <div className="paw-pattern absolute inset-0 opacity-30" />
        <div
          aria-hidden
          className="absolute -left-20 -top-24 h-64 w-64 rounded-full bg-white/15 blur-2xl"
        />
        <div
          aria-hidden
          className="absolute -bottom-24 right-1/3 h-56 w-56 rounded-full bg-sun-300/40 blur-2xl"
        />
        <div className="relative grid items-center gap-8 p-6 sm:p-10 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10 lg:p-12">
          <div className="animate-rise">
            <p className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3.5 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] ring-1 ring-white/25">
              <Sparkles className="h-3.5 w-3.5" />
              Adopciones responsables
            </p>
            <h1 className="mt-4 font-display text-[2.1rem] font-bold leading-[1.05] text-balance sm:text-5xl">
              Una huella nueva,
              <br />
              <span className="text-sun-200">un hogar para siempre.</span>
            </h1>
            <p className="mt-4 max-w-md text-sm font-semibold leading-relaxed text-white/85 sm:text-base">
              Encuentra a tu perro o gato, envía tu solicitud y acompáñalo en
              todo el proceso: detalle, pasaporte veterinario y seguimiento
              post-adopción.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href="#mascotas"
                className="btn bg-white px-6 py-3.5 text-coral-600 shadow-lg shadow-coral-700/20 hover:bg-cream"
              >
                <PawPrint className="h-4 w-4" strokeWidth={2.6} />
                Ver mascotas
              </Link>
              <Link
                href="/solicitudes"
                className="btn border-2 border-white/50 px-6 py-3.5 text-white hover:bg-white/10"
              >
                <ClipboardList className="h-4 w-4" />
                Mis solicitudes
              </Link>
            </div>

            <dl className="mt-8 grid max-w-md grid-cols-3 gap-2">
              {[
                { value: stats.available, label: "en adopción" },
                { value: stats.adopted, label: "adoptados" },
                { value: stats.shelters, label: "refugios" },
              ].map((item) => (
                <div
                  key={item.label}
                  className="rounded-2xl bg-white/12 px-3 py-3 text-center ring-1 ring-white/20 backdrop-blur-sm"
                >
                  <dt className="font-display text-2xl font-bold leading-none">
                    {item.value}
                  </dt>
                  <dd className="mt-1 text-[10px] font-extrabold uppercase tracking-wider text-white/75">
                    {item.label}
                  </dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative animate-rise [animation-delay:120ms]">
            <div className="relative mx-auto max-w-md overflow-hidden rounded-[30px] bg-cream shadow-[0_30px_60px_-25px_rgba(120,40,25,0.6)] ring-4 ring-white/40">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/hero-pets.png"
                alt="Ilustración de un perro y un gato esperando ser adoptados"
                className="h-full w-full object-cover"
              />
            </div>
            <div className="animate-floaty absolute -left-2 top-4 flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-ink shadow-soft sm:-left-4">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-mint-100 text-mint-700">
                <ShieldCheck className="h-4 w-4" />
              </span>
              <span className="text-[11px] font-extrabold leading-tight">
                Pasaporte
                <span className="block text-[10px] font-bold text-muted">
                  veterinario incluido
                </span>
              </span>
            </div>
            <div className="animate-floaty absolute -bottom-3 right-0 flex items-center gap-2 rounded-2xl bg-white px-3 py-2 text-ink shadow-soft [animation-delay:1.5s] sm:-right-2">
              <span className="grid h-8 w-8 place-items-center rounded-full bg-coral-100 text-coral-600">
                <HandHeart className="h-4 w-4" />
              </span>
              <span className="text-[11px] font-extrabold leading-tight">
                +{stats.adopted} finales felices
                <span className="block text-[10px] font-bold text-muted">
                  este año en Huellitas
                </span>
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Módulos */}
      <section aria-labelledby="modulos-title">
        <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="eyebrow">
              <PawPrint className="h-3.5 w-3.5" />
              Todo el proceso
            </p>
            <h2 id="modulos-title" className="section-title mt-2">
              Cuatro módulos, una sola adopción
            </h2>
          </div>
          <p className="max-w-sm text-sm font-semibold text-muted">
            Desde la primera solicitud hasta la última visita de seguimiento.
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {modules.map((module) => {
            const Icon = module.icon;
            return (
              <Link
                key={module.label}
                href={module.href}
                className="card group flex flex-col gap-3 p-5 transition hover:-translate-y-1 hover:ring-2 hover:ring-coral-100"
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`grid h-11 w-11 place-items-center rounded-2xl ${module.accent}`}
                  >
                    <Icon className="h-5 w-5" strokeWidth={2.4} />
                  </span>
                  <ArrowUpRight className="h-4 w-4 text-muted transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-coral-500" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-ink">
                    {module.label}
                  </h3>
                  <p className="mt-1 text-[13px] font-medium leading-snug text-muted">
                    {module.text}
                  </p>
                </div>
                <span className="mt-auto inline-flex w-fit items-center gap-1.5 rounded-full bg-cream px-2.5 py-1 text-[11px] font-extrabold text-ink/70">
                  {module.badge}
                </span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Mascotas */}
      <section id="mascotas" aria-labelledby="mascotas-title" className="scroll-mt-24">
        <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="eyebrow">
              <HandHeart className="h-3.5 w-3.5" />
              Buscan familia
            </p>
            <h2 id="mascotas-title" className="section-title mt-2">
              Mascotas en adopción
            </h2>
            <p className="mt-1 text-sm font-semibold text-muted">
              {stats.dogs} perros y {stats.cats} gatos esperando su oportunidad.
            </p>
          </div>

          <div className="flex items-center gap-1 rounded-full border border-white bg-white p-1.5 shadow-soft">
            {filters.map((filter) => {
              const active = activeSpecies === filter.key;
              const href = filter.key ? `/?especie=${filter.key}#mascotas` : "/#mascotas";
              return (
                <Link
                  key={filter.label}
                  href={href}
                  scroll
                  className={`rounded-full px-4 py-2 text-xs font-extrabold transition ${
                    active
                      ? "bg-coral-500 text-white shadow-pop"
                      : "text-ink/60 hover:bg-coral-50 hover:text-coral-600"
                  }`}
                >
                  <span className="mr-1">{filter.emoji}</span>
                  {filter.label}
                </Link>
              );
            })}
          </div>
        </div>

        {petList.length === 0 ? (
          <div className="card flex flex-col items-center gap-3 px-6 py-14 text-center">
            <span className="grid h-14 w-14 place-items-center rounded-full bg-coral-50 text-coral-500">
              <PawPrint className="h-7 w-7" />
            </span>
            <h3 className="font-display text-xl font-bold">
              Aún no hay mascotas de este tipo
            </h3>
            <p className="max-w-sm text-sm font-medium text-muted">
              Estamos preparando nuevas llegadas. Mientras tanto, descubre a los
              perros y gatos que ya buscan familia.
            </p>
            <Link href="/#mascotas" className="btn-primary mt-2">
              Ver todas las mascotas
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {petList.map((pet) => (
              <PetCard key={pet.id} pet={pet} />
            ))}
          </div>
        )}

        <div className="mt-4 flex items-center justify-between gap-3 rounded-2xl bg-mint-50 px-4 py-3 text-xs font-bold text-mint-700 ring-1 ring-mint-100">
          <span className="flex items-center gap-2">
            <ShieldCheck className="h-4 w-4" />
            Todas nuestras mascotas se entregan vacunadas, desparasitadas y con
            microchip.
          </span>
          <Link href="/pasaporte" className="hidden shrink-0 items-center gap-1 underline sm:flex">
            Ver pasaportes
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </section>

      {/* Seguimiento + cómo funciona */}
      <section className="grid gap-4 lg:grid-cols-[0.95fr_1.05fr]">
        <div className="card relative overflow-hidden p-6">
          <div
            aria-hidden
            className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-mint-100"
          />
          <div className="relative">
            <p className="eyebrow">
              <Route className="h-3.5 w-3.5" />
              Seguimiento
            </p>
            <h2 className="section-title mt-2">
              No desaparecemos después de la adopción
            </h2>
            {pendingFollowUp ? (
              <Link
                href={`/seguimiento/${pendingFollowUp.pet.id}`}
                className="mt-4 flex items-center gap-3 rounded-2xl border border-line bg-cream/70 p-3 transition hover:border-mint-200 hover:bg-mint-50"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={pendingFollowUp.pet.photoUrl}
                  alt={pendingFollowUp.pet.name}
                  className="h-14 w-14 rounded-full object-cover ring-2 ring-white"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-display text-base font-bold leading-tight">
                    {pendingFollowUp.pet.name}
                  </p>
                  <p className="truncate text-xs font-bold text-muted">
                    Próximo: {pendingFollowUp.nextTitle} ·{" "}
                    {shortDate(pendingFollowUp.nextDueOn)}
                  </p>
                  <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-mint-100">
                    <div
                      className="h-full rounded-full bg-mint-400"
                      style={{
                        width: `${Math.round(
                          (pendingFollowUp.completed / Math.max(pendingFollowUp.total, 1)) * 100,
                        )}%`,
                      }}
                    />
                  </div>
                </div>
                <span className="text-xs font-extrabold text-mint-700">
                  {pendingFollowUp.completed}/{pendingFollowUp.total}
                </span>
              </Link>
            ) : (
              <p className="mt-4 text-sm font-medium text-muted">
                Todos los seguimientos están al día. ¡Gracias por cuidar tan
                bien de ellos!
              </p>
            )}
            <Link href="/seguimiento" className="btn-mint mt-4 w-full sm:w-auto">
              Abrir seguimiento
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        <div className="surface p-6">
          <p className="eyebrow">
            <Check className="h-3.5 w-3.5" />
            Cómo funciona
          </p>
          <h2 className="section-title mt-2">Adoptar en cuatro pasos</h2>
          <ol className="mt-4 grid gap-3 sm:grid-cols-2">
            {[
              {
                title: "Explora y elige",
                text: "Filtra por perro o gato y revisa cada detalle.",
                icon: PawPrint,
              },
              {
                title: "Envía tu solicitud",
                text: "Cuéntanos cómo sería tu vida juntos.",
                icon: ClipboardList,
              },
              {
                title: "Revisa el pasaporte",
                text: "Vacunas y microchip listos para la entrega.",
                icon: IdCard,
              },
              {
                title: "Seguimiento",
                text: "Visitas y refuerzos durante los primeros meses.",
                icon: Route,
              },
            ].map((step, index) => {
              const Icon = step.icon;
              return (
                <li
                  key={step.title}
                  className="rounded-2xl border border-line/80 bg-cream/60 p-3.5"
                >
                  <div className="flex items-center gap-2">
                    <span className="grid h-7 w-7 place-items-center rounded-full bg-coral-500 text-[11px] font-extrabold text-white">
                      {index + 1}
                    </span>
                    <Icon className="h-4 w-4 text-coral-500" />
                    <p className="text-sm font-extrabold">{step.title}</p>
                  </div>
                  <p className="mt-1.5 text-xs font-medium leading-snug text-muted">
                    {step.text}
                  </p>
                </li>
              );
            })}
          </ol>
          <div className="mt-4 flex flex-wrap items-center gap-3 rounded-2xl bg-coral-50 p-3 text-xs font-bold text-coral-700">
            <span className="flex items-center gap-1.5">
              <Syringe className="h-4 w-4" /> Vacunación al día
            </span>
            <span className="flex items-center gap-1.5">
              <Camera className="h-4 w-4" /> Fotos de evolución
            </span>
            <span className="flex items-center gap-1.5">
              <MapPin className="h-4 w-4" /> {stats.shelters} refugios aliados
            </span>
          </div>
        </div>
      </section>
    </div>
  );
}
