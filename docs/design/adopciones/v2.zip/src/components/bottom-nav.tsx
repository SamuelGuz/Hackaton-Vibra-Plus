"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Heart } from "lucide-react";
import { navItems } from "@/components/nav-items";

export function BottomNav() {
  const pathname = usePathname();
  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 px-3 pb-3 no-print md:hidden">
      <nav className="relative mx-auto flex max-w-md items-end justify-between rounded-[26px] border border-white bg-white/95 px-2 pb-2 pt-2 shadow-[0_-10px_40px_-18px_rgba(92,58,40,0.45)] backdrop-blur-xl">
        {navItems.slice(0, 2).map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-1 flex-col items-center gap-1 rounded-2xl py-1.5 text-[10px] font-extrabold ${
                active ? "text-coral-600" : "text-muted"
              }`}
            >
              <Icon
                className={`h-5 w-5 ${active ? "stroke-[2.6]" : "stroke-2"}`}
              />
              {item.shortLabel}
            </Link>
          );
        })}

        <Link
          href="/#mascotas"
          aria-label="Ver mascotas en adopción"
          className="relative -mt-7 grid h-14 w-14 shrink-0 place-items-center rounded-full bg-coral-500 text-white shadow-pop ring-4 ring-cream transition active:scale-95"
        >
          <Heart className="h-6 w-6 fill-white" />
          <span className="absolute -right-1 -top-1 h-3 w-3 rounded-full bg-mint-400 ring-2 ring-white" />
        </Link>

        {navItems.slice(2).map((item) => {
          const Icon = item.icon;
          const active = isActive(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex flex-1 flex-col items-center gap-1 rounded-2xl py-1.5 text-[10px] font-extrabold ${
                active ? "text-coral-600" : "text-muted"
              }`}
            >
              <Icon
                className={`h-5 w-5 ${active ? "stroke-[2.6]" : "stroke-2"}`}
              />
              {item.shortLabel}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
