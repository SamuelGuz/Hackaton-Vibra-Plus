import { and, asc, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  applications,
  followUps,
  passportRecords,
  pets,
  type Application,
  type FollowUp,
  type PassportRecord,
  type Pet,
} from "@/db/schema";
import { ensureSeed } from "@/db/seed";

export type ApplicationWithPet = Application & { pet: Pet };

let seeded: Promise<void> | null = null;
export function bootstrap() {
  if (!seeded) seeded = ensureSeed();
  return seeded;
}

export async function getPets(species?: string, q?: string): Promise<Pet[]> {
  await bootstrap();
  const filters = [];
  if (species && species !== "todos") filters.push(eq(pets.species, species));
  if (q && q.trim()) {
    const like = `%${q.trim().toLowerCase()}%`;
    filters.push(
      sql`(lower(${pets.name}) like ${like} or lower(${pets.breed}) like ${like} or lower(${pets.city}) like ${like})`,
    );
  }
  const base = db.select().from(pets);
  const rows = filters.length
    ? await base.where(and(...filters)).orderBy(asc(pets.id))
    : await base.orderBy(asc(pets.id));
  return rows;
}

export async function getPet(id: number): Promise<Pet | null> {
  await bootstrap();
  const [row] = await db.select().from(pets).where(eq(pets.id, id)).limit(1);
  return row ?? null;
}

export async function getPassport(petId: number): Promise<PassportRecord[]> {
  await bootstrap();
  return db
    .select()
    .from(passportRecords)
    .where(eq(passportRecords.petId, petId))
    .orderBy(asc(passportRecords.id));
}

export async function getApplications(
  status?: string,
): Promise<ApplicationWithPet[]> {
  await bootstrap();
  const rows = await db
    .select({ application: applications, pet: pets })
    .from(applications)
    .innerJoin(pets, eq(applications.petId, pets.id))
    .orderBy(desc(applications.createdAt), desc(applications.id));

  return rows
    .map((r) => ({ ...r.application, pet: r.pet }))
    .filter((r) => !status || status === "todas" || r.status === status);
}

export async function getApplication(
  id: number,
): Promise<ApplicationWithPet | null> {
  await bootstrap();
  const [row] = await db
    .select({ application: applications, pet: pets })
    .from(applications)
    .innerJoin(pets, eq(applications.petId, pets.id))
    .where(eq(applications.id, id))
    .limit(1);
  return row ? { ...row.application, pet: row.pet } : null;
}

export async function getFollowUps(applicationId: number): Promise<FollowUp[]> {
  await bootstrap();
  return db
    .select()
    .from(followUps)
    .where(eq(followUps.applicationId, applicationId))
    .orderBy(asc(followUps.position), asc(followUps.id));
}

export async function getTrackedApplications(): Promise<
  (ApplicationWithPet & { steps: FollowUp[] })[]
> {
  const apps = await getApplications();
  const tracked = apps.filter((a) => a.status !== "rechazado");
  const result = [];
  for (const app of tracked) {
    result.push({ ...app, steps: await getFollowUps(app.id) });
  }
  return result;
}

export async function getStats() {
  await bootstrap();
  const [petCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(pets);
  const [appCount] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(applications);
  const [approved] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(applications)
    .where(eq(applications.status, "aprobado"));
  return {
    pets: petCount?.count ?? 0,
    applications: appCount?.count ?? 0,
    approved: approved?.count ?? 0,
  };
}
