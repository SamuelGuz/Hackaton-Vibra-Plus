"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Check, ChevronRight, Loader2, X } from "lucide-react";

export function ApplicationActions({
  applicationId,
  petId,
  status,
}: {
  applicationId: number;
  petId: number;
  status: string;
}) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [busy, setBusy] = useState<"aprobada" | "rechazada" | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function decide(next: "aprobada" | "rechazada") {
    setBusy(next);
    setError(null);
    try {
      const response = await fetch(`/api/applications/${applicationId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: next }),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => null)) as {
          error?: string;
        } | null;
        throw new Error(data?.error ?? "No pudimos actualizar la solicitud");
      }
      startTransition(() => router.refresh());
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Error inesperado");
    } finally {
      setBusy(null);
    }
  }

  if (status === "aprobada") {
    return (
      <div className="flex flex-wrap items-center gap-2">
        <Link
          href={`/pasaporte/${petId}`}
          className="inline-flex items-center gap-1.5 rounded-full bg-mint-100 px-3 py-2 text-xs font-extrabold text-mint-700 transition hover:bg-mint-200"
        >
          Ver pasaporte
          <ChevronRight className="h-3.5 w-3.5" />
        </Link>
        <Link
          href={`/seguimiento/${petId}`}
          className="inline-flex items-center gap-1.5 rounded-full bg-sky-100 px-3 py-2 text-xs font-extrabold text-sky-800 transition hover:bg-sky-200"
        >
          Seguimiento
          <ChevronRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    );
  }

  if (status === "rechazada") {
    return (
      <p className="text-xs font-bold text-muted">
        Solicitud cerrada ·{" "}
        <Link href="/#mascotas" className="text-coral-600 underline">
          ver otras mascotas
        </Link>
      </p>
    );
  }

  return (
    <div className="flex flex-col items-end gap-1">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => decide("rechazada")}
          disabled={busy !== null || isPending}
          className="inline-flex items-center gap-1.5 rounded-full border-2 border-line px-3 py-2 text-xs font-extrabold text-ink/70 transition hover:border-rose-200 hover:bg-rose-50 hover:text-rose-700 disabled:opacity-50"
        >
          {busy === "rechazada" ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <X className="h-3.5 w-3.5" />
          )}
          Rechazar
        </button>
        <button
          type="button"
          onClick={() => decide("aprobada")}
          disabled={busy !== null || isPending}
          className="inline-flex items-center gap-1.5 rounded-full bg-mint-500 px-3.5 py-2 text-xs font-extrabold text-white shadow-[0_10px_20px_-10px_rgba(76,185,171,0.9)] transition hover:bg-mint-600 disabled:opacity-50"
        >
          {busy === "aprobada" ? (
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
          ) : (
            <Check className="h-3.5 w-3.5" />
          )}
          Aprobar
        </button>
      </div>
      {error ? <p className="text-[11px] font-bold text-rose-600">{error}</p> : null}
    </div>
  );
}
