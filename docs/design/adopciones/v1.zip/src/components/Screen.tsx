import Link from "next/link";
import type { ReactNode } from "react";

type Tone = "coral" | "mint" | "sun";

const TONES: Record<Tone, string> = {
  coral: "from-coral-500 to-coral-400",
  mint: "from-mint-400 to-mint-300",
  sun: "from-sun-400 to-sun-300",
};

export function ScreenHeader({
  title,
  subtitle,
  backHref,
  tone = "coral",
  action,
  emoji,
}: {
  title: string;
  subtitle?: string;
  backHref?: string;
  tone?: Tone;
  action?: ReactNode;
  emoji?: string;
}) {
  return (
    <header
      className={`relative overflow-hidden rounded-b-[34px] bg-gradient-to-br ${TONES[tone]} px-5 pb-10 pt-6 text-white shadow-[0_14px_30px_-18px_rgba(92,83,76,0.8)]`}
    >
      <div className="pointer-events-none absolute -right-8 -top-10 h-32 w-32 rounded-full bg-white/15" />
      <div className="pointer-events-none absolute -bottom-12 left-10 h-28 w-28 rounded-full bg-white/10" />
      <div className="relative flex items-center gap-3">
        {backHref ? (
          <Link
            href={backHref}
            aria-label="Volver"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/25 text-lg backdrop-blur transition hover:bg-white/40"
          >
            ←
          </Link>
        ) : (
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white/25 text-lg backdrop-blur">
            🐾
          </span>
        )}
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-2xl font-extrabold tracking-tight drop-shadow-sm">
            {title} {emoji}
          </h1>
          {subtitle ? (
            <p className="truncate text-xs font-semibold text-white/85">
              {subtitle}
            </p>
          ) : null}
        </div>
        {action}
      </div>
    </header>
  );
}

export function Screen({ children }: { children: ReactNode }) {
  return <div className="flex min-h-full flex-col pb-2">{children}</div>;
}

export function ScreenBody({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`-mt-6 flex-1 space-y-4 px-4 pb-6 ${className}`}>
      {children}
    </div>
  );
}
