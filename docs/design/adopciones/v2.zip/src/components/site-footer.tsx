import Link from "next/link";
import { Heart, Mail, MapPin, PawPrint, Phone } from "lucide-react";
import { navItems } from "@/components/nav-items";

export function SiteFooter() {
  return (
    <footer className="mt-10 border-t border-line/70 bg-white/70 no-print">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-8 px-4 py-10 sm:px-6 md:flex-row md:items-start md:justify-between md:pb-20">
        <div className="max-w-sm">
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-2xl bg-coral-500 text-white shadow-pop">
              <PawPrint className="h-5 w-5" strokeWidth={2.4} />
            </span>
            <span className="font-display text-xl font-bold">Huellitas</span>
          </div>
          <p className="mt-3 text-sm font-medium leading-relaxed text-muted">
            Conectamos refugios y familias para que cada perro y cada gato
            encuentre un hogar responsable. Adopta, no compres.
          </p>
          <p className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-coral-50 px-3 py-1.5 text-xs font-extrabold text-coral-600">
            <Heart className="h-3.5 w-3.5 fill-coral-400 text-coral-400" />
            Hecho con cariño para ellos
          </p>
        </div>

        <div className="grid flex-1 gap-8 sm:grid-cols-3 md:max-w-xl">
          <div>
            <p className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-ink/50">
              Módulos
            </p>
            <ul className="mt-3 space-y-2 text-sm font-bold text-ink/70">
              {navItems.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="transition hover:text-coral-600"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-ink/50">
              Refugios
            </p>
            <ul className="mt-3 space-y-2 text-sm font-medium text-muted">
              <li>Patitas Felices</li>
              <li>Huellitas Madrid</li>
              <li>Gatosphera</li>
              <li>Refugio El Arca</li>
            </ul>
          </div>
          <div>
            <p className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-ink/50">
              Contacto
            </p>
            <ul className="mt-3 space-y-2 text-sm font-medium text-muted">
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-coral-400" /> hola@huellitas.app
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-coral-400" /> +34 600 123 456
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-coral-400" /> Madrid, España
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-line/70 px-4 py-4 pb-24 text-center text-xs font-semibold text-muted md:pb-4">
        © {new Date().getFullYear()} Huellitas · Adopciones responsables de
        perros y gatos
      </div>
    </footer>
  );
}
