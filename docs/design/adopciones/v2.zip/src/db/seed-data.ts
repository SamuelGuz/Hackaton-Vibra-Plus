export type PassportSeed = {
  code: string;
  vetName: string;
  clinic: string;
  weightKg: string;
  microchipId: string;
  notes: string;
  lastCheckupOffset: number;
  progress: { vaccines: number; dewormed: number; microchip: number };
  vaccines: {
    name: string;
    dose: string;
    appliedOffset: number;
    nextDueOffset: number;
    status: "completa" | "pendiente";
  }[];
};

export type PlanSeed = {
  title: string;
  description: string;
  type: "visita" | "vacuna" | "foto" | "llamada";
  dueOffset: number;
  completedOffset?: number;
};

export type PetSeed = {
  key: string;
  name: string;
  species: "perro" | "gato";
  breed: string;
  sex: "macho" | "hembra";
  ageMonths: number;
  size: "pequeño" | "mediano" | "grande";
  city: string;
  shelter: string;
  tagline: string;
  story: string;
  personality: string[];
  photoUrl: string;
  status: "disponible" | "en_proceso" | "adoptado";
  featured: boolean;
  passport?: PassportSeed;
  plan?: PlanSeed[];
};

const photo = (id: number) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=800&h=1000`;

export const petSeeds: PetSeed[] = [
  {
    key: "bella",
    name: "Bella",
    species: "perro",
    breed: "Golden Retriever",
    sex: "hembra",
    ageMonths: 26,
    size: "mediano",
    city: "Valencia",
    shelter: "Patitas Felices",
    tagline: "Una golden que reparte abrazos a todo el que conoce.",
    story:
      "Bella llegó al refugio con apenas cuatro meses y hoy es el alma de la casa. Le encanta el agua, los niños y dormir con la pata fuera de la cama. Busca una familia que disfrute de paseos largos y de un buen sofá por la tarde.",
    personality: ["Juguetona", "Sociable", "Obediente"],
    photoUrl: photo(8031870),
    status: "en_proceso",
    featured: true,
  },
  {
    key: "luna",
    name: "Luna",
    species: "perro",
    breed: "Labrador",
    sex: "hembra",
    ageMonths: 18,
    size: "grande",
    city: "Madrid",
    shelter: "Huellitas Madrid",
    tagline: "Energía pura y una mirada que lo dice todo.",
    story:
      "Propongo un adoptante comprometido conmigo. Soy una labradora joven que necesita una familia activa, con tiempo para el parque y ganas de enseñarme trucos nuevos. Me llevo genial con otros perros y con los gatos.",
    personality: ["Activa", "Cariñosa", "Tragona"],
    photoUrl: photo(28683176),
    status: "en_proceso",
    featured: true,
    passport: {
      code: "AD-2026-004",
      vetName: "Dra. Elena Ruiz",
      clinic: "Clínica Vetmigo",
      weightKg: "26,4",
      microchipId: "941 000 002 118 764",
      notes:
        "Vacunación al día. Pendiente refuerzo de rabia en la próxima visita. Excelente condición corporal.",
      lastCheckupOffset: -24,
      progress: { vaccines: 100, dewormed: 100, microchip: 100 },
      vaccines: [
        { name: "Polivalente canina", dose: "2ª dosis", appliedOffset: -190, nextDueOffset: 175, status: "completa" },
        { name: "Rabia", dose: "Dosis anual", appliedOffset: -120, nextDueOffset: 245, status: "completa" },
        { name: "Leptospirosis", dose: "Refuerzo", appliedOffset: -30, nextDueOffset: 335, status: "completa" },
      ],
    },
    plan: [
      { title: "Visita inicial", description: "Primera visita al hogar y revisión de adaptación.", type: "visita", dueOffset: -40, completedOffset: -38 },
      { title: "Vacuna de refuerzo", description: "Refuerzo de leptospirosis en clínica.", type: "vacuna", dueOffset: -30, completedOffset: -30 },
      { title: "Visita de seguimiento", description: "Paseo conjunto con el equipo del refugio.", type: "visita", dueOffset: 6 },
      { title: "Foto de actualización", description: "Envíanos una foto para el álbum de adoptados.", type: "foto", dueOffset: 18 },
    ],
  },
  {
    key: "coco",
    name: "Coco",
    species: "perro",
    breed: "Beagle",
    sex: "macho",
    ageMonths: 8,
    size: "pequeño",
    city: "Sevilla",
    shelter: "Refugio El Arca",
    tagline: "Pequeño explorador con orejas de terciopelo.",
    story:
      "Coco es pura curiosidad: olfatea cada rincón y se emociona con cualquier juguete nuevo. Es un cachorro que necesita rutinas y paciencia, a cambio promete ser tu sombra allá donde vayas.",
    personality: ["Curioso", "Travieso", "Rastreador"],
    photoUrl: photo(30432649),
    status: "disponible",
    featured: true,
    passport: {
      code: "AD-2026-007",
      vetName: "Dr. Hugo Márquez",
      clinic: "Centro Veterinario Triana",
      weightKg: "9,8",
      microchipId: "941 000 003 872 221",
      notes:
        "Cachorro sano. Calendario de vacunación iniciado, pendiente última dosis de polivalente.",
      lastCheckupOffset: -12,
      progress: { vaccines: 75, dewormed: 100, microchip: 100 },
      vaccines: [
        { name: "Polivalente canina", dose: "1ª dosis", appliedOffset: -70, nextDueOffset: -40, status: "completa" },
        { name: "Polivalente canina", dose: "2ª dosis", appliedOffset: -45, nextDueOffset: 320, status: "completa" },
        { name: "Rabia", dose: "Dosis única", appliedOffset: -20, nextDueOffset: 345, status: "completa" },
        { name: "Polivalente canina", dose: "3ª dosis", appliedOffset: -1, nextDueOffset: 20, status: "pendiente" },
      ],
    },
  },
  {
    key: "toby",
    name: "Toby",
    species: "perro",
    breed: "Mestizo",
    sex: "macho",
    ageMonths: 40,
    size: "mediano",
    city: "Bilbao",
    shelter: "Hogar Beti",
    tagline: "Tranquilo, agradecido y experto en siestas.",
    story:
      "Toby fue rescatado de la calle y durante meses aprendió a confiar de nuevo en las personas. Hoy es un perro equilibrado que pide poco: un rincón soleado, comida rica y una mano en la cabeza.",
    personality: ["Tranquilo", "Leal", "Sensible"],
    photoUrl: photo(11474678),
    status: "adoptado",
    featured: false,
    passport: {
      code: "AD-2025-112",
      vetName: "Dra. Nerea Otxoa",
      clinic: "Veterinaria Deusto",
      weightKg: "18,2",
      microchipId: "941 000 000 554 903",
      notes:
        "Adoptado en diciembre. Seguimiento post-adopción en curso con muy buena evolución.",
      lastCheckupOffset: -58,
      progress: { vaccines: 100, dewormed: 100, microchip: 100 },
      vaccines: [
        { name: "Polivalente canina", dose: "Dosis anual", appliedOffset: -300, nextDueOffset: 65, status: "completa" },
        { name: "Rabia", dose: "Dosis anual", appliedOffset: -300, nextDueOffset: 65, status: "completa" },
        { name: "Antiparasitario interno", dose: "Trimestral", appliedOffset: -58, nextDueOffset: 32, status: "completa" },
      ],
    },
    plan: [
      { title: "Visita inicial", description: "Adaptación al hogar de acogida definitivo. Todo correcto.", type: "visita", dueOffset: -52, completedOffset: -50 },
      { title: "Vacuna de refuerzo", description: "Refuerzo anual aplicado sin incidencias.", type: "vacuna", dueOffset: -34, completedOffset: -34 },
      { title: "Visita de seguimiento", description: "Revisión del peso y de la rutina diaria.", type: "visita", dueOffset: -8, completedOffset: -7 },
      { title: "Foto de actualización", description: "Foto para el mural de adopciones felices.", type: "foto", dueOffset: 5 },
      { title: "Llamada de cierre", description: "Última llamada del proceso de seguimiento.", type: "llamada", dueOffset: 26 },
    ],
  },
  {
    key: "rocco",
    name: "Rocco",
    species: "perro",
    breed: "Mestizo pug-beagle",
    sex: "macho",
    ageMonths: 52,
    size: "pequeño",
    city: "Madrid",
    shelter: "Huellitas Madrid",
    tagline: "Sociable, divertido y fan de las mantas.",
    story:
      "Rocco es el compañero perfecto para un piso: se adapta a todo y ronca como un pequeño tractor. Ya sabe pasear con arnés, se lleva bien con niños y adora a los gatos del refugio.",
    personality: ["Sociable", "Calmado", "Roncador"],
    photoUrl: photo(32216449),
    status: "en_proceso",
    featured: false,
  },
  {
    key: "canela",
    name: "Canela",
    species: "perro",
    breed: "Chihuahua",
    sex: "hembra",
    ageMonths: 7,
    size: "pequeño",
    city: "Málaga",
    shelter: "Refugio El Arca",
    tagline: "Diminuta, valiente y muy mimosa.",
    story:
      "Canela pesa menos que una bolsa de pienso pero tiene un carácter enorme. Duerme enroscada y tiembla de emoción cuando la coges en brazos. Busca un hogar tranquilo donde sea la reina.",
    personality: ["Mimosa", "Valiente", "Dormilona"],
    photoUrl: photo(33786003),
    status: "disponible",
    featured: true,
  },
  {
    key: "oliver",
    name: "Oliver",
    species: "gato",
    breed: "Europeo atigrado",
    sex: "macho",
    ageMonths: 15,
    size: "mediano",
    city: "Barcelona",
    shelter: "Gatosphera",
    tagline: "El rey del sofá y de las cajas de cartón.",
    story:
      "Oliver llegó con un ojo inflamado y hoy luce un pelaje brillante y una curiosidad sin fin. Es un gato de interior, conversador y muy limpio. Le gustan los rascadores altos y las ventanas con sol.",
    personality: ["Casero", "Conversador", "Observador"],
    photoUrl: photo(9325709),
    status: "adoptado",
    featured: true,
    passport: {
      code: "AD-2026-018",
      vetName: "Dr. Marc Solé",
      clinic: "Hospital Felino Gràcia",
      weightKg: "4,6",
      microchipId: "724 000 009 118 220",
      notes:
        "Gato sano y sociable. Vacunación completa, desparasitación interna y externa al día.",
      lastCheckupOffset: -33,
      progress: { vaccines: 100, dewormed: 100, microchip: 100 },
      vaccines: [
        { name: "Trivalente felina", dose: "Dosis anual", appliedOffset: -210, nextDueOffset: 155, status: "completa" },
        { name: "Rabia felina", dose: "Dosis única", appliedOffset: -210, nextDueOffset: 155, status: "completa" },
        { name: "Leucemia felina", dose: "Refuerzo", appliedOffset: -60, nextDueOffset: 305, status: "completa" },
      ],
    },
    plan: [
      { title: "Visita 1", description: "Revisión de adaptación y entrega de material informativo.", type: "visita", dueOffset: -46, completedOffset: -45 },
      { title: "Vacuna de refuerzo", description: "Trivalente aplicada en su clínica de referencia.", type: "vacuna", dueOffset: -21, completedOffset: -21 },
      { title: "Visita 2", description: "El equipo valoró el enriquecimiento ambiental del hogar.", type: "visita", dueOffset: -6, completedOffset: -6 },
      { title: "Foto de actualización", description: "Oliver en su rascador nuevo. ¡Queremos verlo!", type: "foto", dueOffset: 9 },
      { title: "Revisión anual", description: "Analítica y vacunas del primer año juntos.", type: "vacuna", dueOffset: 42 },
    ],
  },
  {
    key: "milo",
    name: "Milo",
    species: "gato",
    breed: "Europeo naranja",
    sex: "macho",
    ageMonths: 5,
    size: "pequeño",
    city: "Madrid",
    shelter: "Bigotes Felices",
    tagline: "Un gatito naranja con motor de ronroneo.",
    story:
      "Milo es un torbellino de cinco meses que juega con todo lo que se mueve. Necesita adoptantes pacientes, con mallas en las ventanas y ganas de compartir juguetes de cuerda.",
    personality: ["Juguetón", "Ronroneador", "Trepador"],
    photoUrl: photo(8584729),
    status: "en_proceso",
    featured: true,
    passport: {
      code: "AD-2026-021",
      vetName: "Dra. Paula Iglesias",
      clinic: "Clínica Minino",
      weightKg: "2,3",
      microchipId: "724 000 011 443 087",
      notes:
        "Cachorro felino en calendario de vacunación. Pendiente última dosis y test de leucemia.",
      lastCheckupOffset: -9,
      progress: { vaccines: 66, dewormed: 100, microchip: 100 },
      vaccines: [
        { name: "Trivalente felina", dose: "1ª dosis", appliedOffset: -60, nextDueOffset: -30, status: "completa" },
        { name: "Trivalente felina", dose: "2ª dosis", appliedOffset: -30, nextDueOffset: 335, status: "completa" },
        { name: "Trivalente felina", dose: "3ª dosis", appliedOffset: -2, nextDueOffset: 14, status: "pendiente" },
      ],
    },
    plan: [
      { title: "Visita de bienvenida", description: "Adaptación al hogar y consejos de seguridad en ventanas.", type: "visita", dueOffset: -18, completedOffset: -18 },
      { title: "Vacuna de refuerzo", description: "Segunda dosis de trivalente felina.", type: "vacuna", dueOffset: -12, completedOffset: -12 },
      { title: "Foto de actualización", description: "Primera foto de Milo en su nuevo hogar.", type: "foto", dueOffset: 4 },
      { title: "Llamada de seguimiento", description: "Revisión del comportamiento y la alimentación.", type: "llamada", dueOffset: 21 },
    ],
  },
  {
    key: "nala",
    name: "Nala",
    species: "gato",
    breed: "Rusa azul",
    sex: "hembra",
    ageMonths: 30,
    size: "mediano",
    city: "Valencia",
    shelter: "Gatosphera",
    tagline: "Elegante, silenciosa y muy independiente.",
    story:
      "Nala es una gata tranquila que observa todo desde lo alto del mueble. Disfruta de la compañía sin invadir tu espacio y agradece una rutina estable. Busca un hogar sin perros.",
    personality: ["Independiente", "Tranquila", "Elegante"],
    photoUrl: photo(32641718),
    status: "disponible",
    featured: true,
    passport: {
      code: "AD-2026-025",
      vetName: "Dra. Marta Peiró",
      clinic: "Hospital Felino Gràcia",
      weightKg: "4,1",
      microchipId: "724 000 007 665 341",
      notes: "Revisión anual completa. Salud excelente.",
      lastCheckupOffset: -18,
      progress: { vaccines: 100, dewormed: 100, microchip: 100 },
      vaccines: [
        { name: "Trivalente felina", dose: "Dosis anual", appliedOffset: -200, nextDueOffset: 165, status: "completa" },
        { name: "Rabia felina", dose: "Dosis anual", appliedOffset: -200, nextDueOffset: 165, status: "completa" },
      ],
    },
  },
  {
    key: "kiwi",
    name: "Kiwi",
    species: "gato",
    breed: "Europeo negro",
    sex: "hembra",
    ageMonths: 11,
    size: "pequeño",
    city: "Zaragoza",
    shelter: "Bigotes Felices",
    tagline: "Una pantera minúscula con ojos de miel.",
    story:
      "Kiwi fue la última de su camada en encontrar familia y no entendemos por qué: es dulce, limpia y le encanta dormir sobre el teclado cuando trabajas.",
    personality: ["Dulce", "Noctámbula", "Dependiente"],
    photoUrl: photo(38846200),
    status: "disponible",
    featured: false,
  },
];

export type ApplicationSeed = {
  petKey: string;
  applicantName: string;
  email: string;
  phone: string;
  city: string;
  housing: string;
  household: string;
  experience: string;
  message: string;
  status: "en_proceso" | "aprobada" | "rechazada";
  createdOffset: number;
};

export const applicationSeeds: ApplicationSeed[] = [
  {
    petKey: "luna",
    applicantName: "Marta Ruiz",
    email: "marta.ruiz@example.com",
    phone: "+34 611 284 903",
    city: "Madrid",
    housing: "Piso con terraza",
    household: "Vivo con mi pareja y un gato",
    experience: "He tenido perros toda la vida",
    message:
      "Propongo un hogar estable y comprometido. Teletrabajo tres días por semana y tenemos un parque a dos calles. Luna encajaría perfecto en nuestras rutinas.",
    status: "en_proceso",
    createdOffset: -2,
  },
  {
    petKey: "bella",
    applicantName: "Lucía Gómez",
    email: "lucia.gomez@example.com",
    phone: "+34 622 551 780",
    city: "Valencia",
    housing: "Casa con jardín",
    household: "Familia con dos niños pequeños",
    experience: "Primera adopción, con curso previo",
    message:
      "Buscamos una perra sociable para completar la familia. Tenemos jardín vallado y ya hemos hablado con la educadora canina del barrio.",
    status: "en_proceso",
    createdOffset: -1,
  },
  {
    petKey: "milo",
    applicantName: "Andrés Soler",
    email: "andres.soler@example.com",
    phone: "+34 633 902 145",
    city: "Madrid",
    housing: "Piso interior",
    household: "Vivo solo, sin otros animales",
    experience: "He convivido con gatos 10 años",
    message:
      "Tengo la casa preparada con mallas y dos rascadores. Puedo dedicar las tardes al juego y comprometerme con las visitas de seguimiento.",
    status: "aprobada",
    createdOffset: -12,
  },
  {
    petKey: "oliver",
    applicantName: "Carla Mínguez",
    email: "carla.minguez@example.com",
    phone: "+34 644 119 028",
    city: "Barcelona",
    housing: "Piso exterior con terraza",
    household: "Vivo con mi hermana",
    experience: "Dos gatos adoptados anteriormente",
    message:
      "Oliver nos enamoró. Tenemos una terraza cerrada y experiencia con gatos tímidos. Queremos ser su familia definitiva.",
    status: "aprobada",
    createdOffset: -50,
  },
  {
    petKey: "toby",
    applicantName: "Familia Ferrer",
    email: "ferrer.family@example.com",
    phone: "+34 655 770 233",
    city: "Bilbao",
    housing: "Casa de dos plantas",
    household: "Pareja y un adolescente",
    experience: "Adoptantes de un perro senior",
    message:
      "Nos comprometemos a respetar sus tiempos. Buscamos un perro tranquilo para acompañarnos en el día a día.",
    status: "aprobada",
    createdOffset: -60,
  },
  {
    petKey: "nala",
    applicantName: "Pau Vidal",
    email: "pau.vidal@example.com",
    phone: "+34 666 342 991",
    city: "Valencia",
    housing: "Estudio sin ventanas exteriores",
    household: "Vivo solo",
    experience: "Sin experiencia previa",
    message:
      "Me gustaría adoptar a Nala aunque trabajo 12 horas fuera de casa.",
    status: "rechazada",
    createdOffset: -8,
  },
  {
    petKey: "rocco",
    applicantName: "Iván Torres",
    email: "ivan.torres@example.com",
    phone: "+34 677 458 100",
    city: "Madrid",
    housing: "Piso con balcón",
    household: "Vivo con mi madre",
    experience: "Tuve un perro durante 12 años",
    message:
      "Rocco parece el compañero ideal para mi madre, que está en casa todo el día. Ya conocemos su veterinario y podemos seguir el plan de visitas.",
    status: "en_proceso",
    createdOffset: -3,
  },
];
