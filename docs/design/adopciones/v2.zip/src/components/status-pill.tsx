import { appStatusMeta, petStatusMeta } from "@/lib/labels";

export function ApplicationStatusPill({
  status,
  className = "",
}: {
  status: string;
  className?: string;
}) {
  const meta = appStatusMeta(status);
  return (
    <span className={`pill ${meta.pill} ${className}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
      {meta.label}
    </span>
  );
}

export function PetStatusPill({
  status,
  className = "",
}: {
  status: string;
  className?: string;
}) {
  const meta = petStatusMeta(status);
  return <span className={`pill ${meta.pill} ${className}`}>{meta.label}</span>;
}
