import { PawPrint } from "lucide-react";

export default function Loading() {
  return (
    <div className="space-y-5">
      <div className="relative overflow-hidden rounded-[30px] bg-coral-200/60 px-6 py-10">
        <div className="paw-pattern absolute inset-0 opacity-20" />
        <div className="relative flex items-center gap-3">
          <span className="grid h-12 w-12 animate-pulse place-items-center rounded-2xl bg-white/60 text-coral-500">
            <PawPrint className="h-6 w-6" />
          </span>
          <div className="space-y-2">
            <div className="h-3 w-24 animate-pulse rounded-full bg-white/70" />
            <div className="h-6 w-48 animate-pulse rounded-full bg-white/80" />
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {[0, 1, 2, 3, 4, 5].map((item) => (
          <div key={item} className="card overflow-hidden">
            <div className="aspect-[4/3] animate-pulse bg-shell" />
            <div className="space-y-2 p-4">
              <div className="h-4 w-1/2 animate-pulse rounded-full bg-shell" />
              <div className="h-3 w-3/4 animate-pulse rounded-full bg-shell/70" />
              <div className="h-8 w-full animate-pulse rounded-full bg-shell/60" />
            </div>
          </div>
        ))}
      </div>
      <p className="text-center text-xs font-bold text-muted">
        Preparando las huellitas…
      </p>
    </div>
  );
}
