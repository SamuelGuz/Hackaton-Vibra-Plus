import Link from "next/link";
import type { Pet } from "@/db/schema";
import { PET_STATUS_META, speciesEmoji } from "@/lib/ui";

export default function PetCard({ pet }: { pet: Pet }) {
  const status = PET_STATUS_META[pet.adoptionStatus] ?? PET_STATUS_META.disponible;

  return (
    <Link
      href={`/mascotas/${pet.id}`}
      className="group relative block overflow-hidden rounded-[26px] bg-white p-2.5 shadow-[0_12px_26px_-18px_rgba(92,83,76,0.75)] ring-1 ring-black/5 transition-transform active:scale-[0.98]"
    >
      <div className="relative aspect-square w-full overflow-hidden rounded-[20px] bg-stone-100">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={pet.photoUrl}
          alt={pet.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <span
          className={`absolute left-2 top-2 rounded-full px-2.5 py-1 text-[10px] font-extrabold ${status.chip} shadow-sm`}
        >
          {status.label}
        </span>
        <span className="absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-base shadow-sm">
          {speciesEmoji(pet.species)}
        </span>
      </div>
      <div className="px-1.5 pb-1 pt-2.5">
        <div className="flex items-baseline justify-between gap-2">
          <h3 className="truncate text-base font-extrabold">{pet.name}</h3>
          <span className="shrink-0 text-[11px] font-bold text-ink-500">
            {pet.ageLabel}
          </span>
        </div>
        <p className="truncate text-xs font-semibold text-ink-500">
          {pet.breed}
        </p>
        <div className="mt-2 flex flex-wrap gap-1">
          <span className="rounded-full bg-mint-100 px-2 py-0.5 text-[10px] font-bold text-mint-600">
            {pet.sex}
          </span>
          <span className="rounded-full bg-sun-100 px-2 py-0.5 text-[10px] font-bold text-amber-700">
            {pet.temperament}
          </span>
        </div>
      </div>
    </Link>
  );
}
