import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const pets = pgTable("pets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  species: text("species").notNull(), // perro | gato
  breed: text("breed").notNull(),
  ageLabel: text("age_label").notNull(),
  sex: text("sex").notNull(), // Hembra | Macho
  size: text("size").notNull(),
  weightKg: text("weight_kg").notNull(),
  temperament: text("temperament").notNull(),
  energy: integer("energy").notNull().default(3),
  sociability: integer("sociability").notNull().default(3),
  description: text("description").notNull(),
  story: text("story").notNull(),
  photoUrl: text("photo_url").notNull(),
  shelter: text("shelter").notNull(),
  city: text("city").notNull(),
  microchip: text("microchip").notNull(),
  sterilized: boolean("sterilized").notNull().default(true),
  adoptionStatus: text("adoption_status").notNull().default("disponible"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id")
    .notNull()
    .references(() => pets.id, { onDelete: "cascade" }),
  applicantName: text("applicant_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  city: text("city").notNull(),
  housing: text("housing").notNull(),
  hasOtherPets: boolean("has_other_pets").notNull().default(false),
  motivation: text("motivation").notNull(),
  status: text("status").notNull().default("pendiente"), // pendiente | en_proceso | aprobado | rechazado
  progress: integer("progress").notNull().default(20),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const passportRecords = pgTable("passport_records", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id")
    .notNull()
    .references(() => pets.id, { onDelete: "cascade" }),
  category: text("category").notNull(), // vacuna | desparasitacion | microchip | revision
  label: text("label").notNull(),
  detail: text("detail").notNull().default(""),
  appliedOn: text("applied_on").notNull().default(""),
  nextDueOn: text("next_due_on").notNull().default(""),
  completion: integer("completion").notNull().default(100),
  done: boolean("done").notNull().default(true),
});

export const followUps = pgTable("follow_ups", {
  id: serial("id").primaryKey(),
  applicationId: integer("application_id")
    .notNull()
    .references(() => applications.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  kind: text("kind").notNull(), // visita | vacuna | foto | llamada
  scheduledFor: text("scheduled_for").notNull(),
  note: text("note").notNull().default(""),
  done: boolean("done").notNull().default(false),
  position: integer("position").notNull().default(0),
});

export type Pet = typeof pets.$inferSelect;
export type Application = typeof applications.$inferSelect;
export type PassportRecord = typeof passportRecords.$inferSelect;
export type FollowUp = typeof followUps.$inferSelect;
