"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const HOUSING = [
  "Departamento",
  "Casa con patio",
  "Casa con jardín amplio",
  "Casa compartida",
];

export default function AdoptForm({
  petId,
  petName,
}: {
  petId: number;
  petName: string;
}) {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({
    applicantName: "",
    email: "",
    phone: "",
    city: "",
    housing: HOUSING[0],
    hasOtherPets: false,
    motivation: "",
  });

  const set = (key: keyof typeof form, value: string | boolean) =>
    setForm((f) => ({ ...f, [key]: value }));

  const step1Valid =
    form.applicantName.trim().length > 2 &&
    form.email.includes("@") &&
    form.phone.trim().length >= 7;

  async function submit() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, petId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "No se pudo enviar");
      router.push(`/seguimiento/${data.application.id}?nueva=1`);
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Error inesperado");
      setLoading(false);
    }
  }

  const inputCls =
    "w-full rounded-2xl border border-stone-200 bg-cream px-3.5 py-3 text-sm font-semibold outline-none transition focus:border-coral-400 focus:bg-white";

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 px-1">
        {[1, 2].map((s) => (
          <div
            key={s}
            className={`h-1.5 flex-1 rounded-full transition-all ${
              s <= step ? "bg-coral-500" : "bg-stone-200"
            }`}
          />
        ))}
        <span className="text-[11px] font-extrabold text-ink-500">
          {step}/2
        </span>
      </div>

      <div className="rounded-3xl bg-white p-4 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
        {step === 1 ? (
          <div className="animate-rise space-y-3">
            <h3 className="text-sm font-extrabold">Tus datos</h3>
            <div>
              <label className="mb-1 block text-[11px] font-extrabold text-ink-500">
                Nombre completo
              </label>
              <input
                className={inputCls}
                value={form.applicantName}
                onChange={(e) => set("applicantName", e.target.value)}
                placeholder="Ej. Mariana Ortiz"
              />
            </div>
            <div>
              <label className="mb-1 block text-[11px] font-extrabold text-ink-500">
                Correo
              </label>
              <input
                className={inputCls}
                type="email"
                value={form.email}
                onChange={(e) => set("email", e.target.value)}
                placeholder="tucorreo@mail.com"
              />
            </div>
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="mb-1 block text-[11px] font-extrabold text-ink-500">
                  Teléfono
                </label>
                <input
                  className={inputCls}
                  value={form.phone}
                  onChange={(e) => set("phone", e.target.value)}
                  placeholder="+52 55 0000 0000"
                />
              </div>
              <div className="flex-1">
                <label className="mb-1 block text-[11px] font-extrabold text-ink-500">
                  Ciudad
                </label>
                <input
                  className={inputCls}
                  value={form.city}
                  onChange={(e) => set("city", e.target.value)}
                  placeholder="Ciudad"
                />
              </div>
            </div>
            <button
              onClick={() => setStep(2)}
              disabled={!step1Valid}
              className="mt-1 h-13 w-full rounded-2xl bg-coral-500 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-coral-300/60 transition active:scale-95 disabled:bg-stone-300 disabled:shadow-none"
            >
              Continuar
            </button>
          </div>
        ) : (
          <div className="animate-rise space-y-3">
            <h3 className="text-sm font-extrabold">Tu hogar</h3>
            <div>
              <label className="mb-1.5 block text-[11px] font-extrabold text-ink-500">
                Tipo de vivienda
              </label>
              <div className="flex flex-wrap gap-2">
                {HOUSING.map((h) => (
                  <button
                    key={h}
                    type="button"
                    onClick={() => set("housing", h)}
                    className={`rounded-full px-3 py-2 text-[11px] font-extrabold transition ${
                      form.housing === h
                        ? "bg-ink-900 text-white"
                        : "bg-cream text-ink-700 ring-1 ring-stone-200"
                    }`}
                  >
                    {h}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="button"
              onClick={() => set("hasOtherPets", !form.hasOtherPets)}
              className="flex w-full items-center justify-between rounded-2xl bg-cream px-3.5 py-3 ring-1 ring-stone-200"
            >
              <span className="text-xs font-extrabold">
                ¿Tienes otras mascotas?
              </span>
              <span
                className={`relative h-6 w-11 rounded-full transition ${
                  form.hasOtherPets ? "bg-mint-400" : "bg-stone-300"
                }`}
              >
                <span
                  className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
                    form.hasOtherPets ? "left-[22px]" : "left-0.5"
                  }`}
                />
              </span>
            </button>

            <div>
              <label className="mb-1 block text-[11px] font-extrabold text-ink-500">
                ¿Por qué quieres adoptar a {petName}?
              </label>
              <textarea
                className={`${inputCls} h-24 resize-none`}
                value={form.motivation}
                onChange={(e) => set("motivation", e.target.value)}
                placeholder="Cuéntanos sobre tu rutina y tu espacio…"
              />
            </div>

            {error ? (
              <p className="rounded-xl bg-coral-100 px-3 py-2 text-xs font-bold text-coral-700">
                {error}
              </p>
            ) : null}

            <div className="flex gap-2">
              <button
                onClick={() => setStep(1)}
                className="rounded-2xl bg-cream px-4 py-3.5 text-sm font-extrabold text-ink-700 ring-1 ring-stone-200"
              >
                Atrás
              </button>
              <button
                onClick={submit}
                disabled={loading}
                className="flex-1 rounded-2xl bg-coral-500 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-coral-300/60 transition active:scale-95 disabled:bg-stone-300"
              >
                {loading ? "Enviando…" : "Enviar solicitud 🐾"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
