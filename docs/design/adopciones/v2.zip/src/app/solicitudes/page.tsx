import Link from "next/link";
import {
  ArrowRight,
  ClipboardList,
  Clock,
  IdCard,
  Mail,
  MapPin,
  PawPrint,
  Phone,
  Route,
  Sparkles,
} from "lucide-react";
import { ApplicationActions } from "@/components/application-actions";
import { ModuleHeader } from "@/components/module-header";
import { ApplicationStatusPill, PetStatusPill } from "@/components/status-pill";
import { getApplicationCounts, listApplications } from "@/db/queries";
import { ageLabel, formatDate, speciesEmoji } from "@/lib/format";

export const dynamic = "force-dynamic";

const tabs = [
  { key: undefined, label: "Todas" },
  { key: "en_proceso", label: "En proceso" },
  { key: "aprobada", label: "Aprobadas" },
  { key: "rechazada", label: "Rechazadas" },
] as const;

export default async function SolicitudesPage({
  searchParams,
}: {
  searchParams: Promise<{ estado?: string }>;
}) {
  const { estado } = await searchParams;
  const activeStatus =
    estado === "en_proceso" || estado === "aprobada" || estado === "rechazada"
      ? estado
      : undefined;

  const [rows, counts] = await Promise.all([
    listApplications(activeStatus),
    getApplicationCounts(),
  ]);

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={ClipboardList}
        eyebrow="Módulo · Solicitudes"
        title="Solicitudes"
        description="Todas las familias que quieren adoptar, con su estado y los datos de contacto en un vistazo."
      >
        <div className="rounded-2xl bg-white/15 px-5 py-4 text-center ring-1 ring-white/25 backdrop-blur-sm">
          <p className="font-display text-3xl font-bold leading-none">
            {counts.en_proceso}
          </p>
          <p className="mt-1 text-[10px] font-extrabold uppercase tracking-[0.16em] text-white/80">
            en proceso
          </p>
        </div>
      </ModuleHeader>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Recibidas", value: counts.todas, tone: "bg-white text-ink" },
          { label: "En proceso", value: counts.en_proceso, tone: "bg-sun-100 text-amber-900" },
          { label: "Aprobadas", value: counts.aprobada, tone: "bg-mint-100 text-mint-800" },
          { label: "Rechazadas", value: counts.rechazada, tone: "bg-rose-50 text-rose-800" },
        ].map((item) => (
          <div
            key={item.label}
            className={`rounded-2xl border border-white p-4 shadow-soft ${item.tone}`}
          >
            <p className="font-display text-2xl font-bold leading-none">
              {item.value}
            </p>
            <p className="mt-1 text-[10px] font-extrabold uppercase tracking-[0.14em] opacity-70">
              {item.label}
            </p>
          </div>
        ))}
      </section>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex w-full items-center gap-1 overflow-x-auto rounded-full border border-white bg-white p-1.5 shadow-soft sm:w-auto">
          {tabs.map((tab) => {
            const active = activeStatus === tab.key;
            const count =
              tab.key === undefined ? counts.todas : counts[tab.key];
            const href = tab.key ? `/solicitudes?estado=${tab.key}` : "/solicitudes";
            return (
              <Link
                key={tab.label}
                href={href}
                className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-extrabold transition ${
                  active
                    ? "bg-coral-500 text-white shadow-pop"
                    : "text-ink/60 hover:bg-coral-50 hover:text-coral-600"
                }`}
              >
                {tab.label}
                <span
                  className={`rounded-full px-1.5 py-0.5 text-[10px] ${
                    active ? "bg-white/25" : "bg-cream text-ink/60"
                  }`}
                >
                  {count}
                </span>
              </Link>
            );
          })}
        </div>
        <p className="flex items-center gap-1.5 text-[11px] font-bold text-muted">
          <Clock className="h-3.5 w-3.5" />
          Las más recientes aparecen primero
        </p>
      </div>

      {rows.length === 0 ? (
        <div className="card flex flex-col items-center gap-3 px-6 py-14 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-full bg-coral-50 text-coral-500">
            <ClipboardList className="h-7 w-7" />
          </span>
          <h2 className="font-display text-xl font-bold">
            No hay solicitudes en este estado
          </h2>
          <p className="max-w-sm text-sm font-medium text-muted">
            Cuando una familia envíe una petición para adoptar aparecerá aquí.
            También puedes animarles desde la ficha de cada mascota.
          </p>
          <Link href="/#mascotas" className="btn-primary mt-2">
            <PawPrint className="h-4 w-4" />
            Ver mascotas
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 xl:grid-cols-2">
          {rows.map(({ application, pet }) => (
            <article key={application.id} className="card overflow-hidden">
              <div className="flex flex-col gap-4 p-4 sm:flex-row">
                <div className="relative h-44 w-full shrink-0 overflow-hidden rounded-2xl sm:h-auto sm:w-32">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={pet.photoUrl}
                    alt={`${pet.name}, ${pet.breed}`}
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                  <span className="absolute left-2 top-2">
                    <PetStatusPill status={pet.status} />
                  </span>
                  <span className="absolute bottom-2 left-2 rounded-full bg-white/90 px-2 py-1 text-[10px] font-extrabold text-ink">
                    {speciesEmoji(pet.species)} {pet.name}
                  </span>
                </div>

                <div className="flex min-w-0 flex-1 flex-col">
                  <div className="flex items-start justify-between gap-2">
                    <ApplicationStatusPill status={application.status} />
                    <span className="text-[10px] font-extrabold uppercase tracking-wide text-muted">
                      {formatDate(application.createdAt)}
                    </span>
                  </div>

                  <h2 className="mt-2 font-display text-2xl font-bold leading-none text-ink">
                    {pet.name}
                  </h2>
                  <p className="mt-1 flex flex-wrap items-center gap-x-1.5 text-[11px] font-bold text-muted">
                    {pet.breed}
                    <span className="opacity-40">·</span>
                    {ageLabel(pet.ageMonths)}
                    <span className="opacity-40">·</span>
                    <MapPin className="h-3 w-3" />
                    {pet.city}
                  </p>

                  <p className="mt-2 line-clamp-2 text-[13px] font-medium leading-snug text-ink/70">
                    {application.message || pet.tagline}
                  </p>

                  <div className="mt-3 rounded-xl bg-cream/80 px-3 py-2 ring-1 ring-line/70">
                    <p className="text-xs font-extrabold text-ink">
                      {application.applicantName}
                    </p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-semibold text-muted">
                      <span className="inline-flex items-center gap-1">
                        <Mail className="h-3 w-3" />
                        {application.email}
                      </span>
                      <span className="inline-flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {application.phone}
                      </span>
                    </p>
                    <p className="mt-1 flex flex-wrap gap-1">
                      <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-ink/60 ring-1 ring-line">
                        {application.housing}
                      </span>
                      <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-bold text-ink/60 ring-1 ring-line">
                        {application.household}
                      </span>
                    </p>
                  </div>

                  <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-line/70 pt-3">
                    <Link
                      href={`/mascotas/${pet.id}`}
                      className="btn-primary px-4 py-2 text-xs"
                    >
                      Ver ficha
                      <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                    <ApplicationActions
                      applicationId={application.id}
                      petId={pet.id}
                      status={application.status}
                    />
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      <section className="surface flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-mint-100 text-mint-700">
            <Sparkles className="h-5 w-5" />
          </span>
          <div>
            <p className="text-sm font-extrabold">
              Aprobar una solicitud abre el resto del proceso
            </p>
            <p className="mt-0.5 max-w-xl text-xs font-medium leading-snug text-muted">
              Al aprobar, la mascota pasa a adoptada, se genera su pasaporte
              veterinario y se activa el plan de seguimiento automáticamente.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link href="/pasaporte" className="btn-outline px-4 py-2 text-xs">
            <IdCard className="h-3.5 w-3.5" />
            Pasaportes
          </Link>
          <Link href="/seguimiento" className="btn-outline px-4 py-2 text-xs">
            <Route className="h-3.5 w-3.5" />
            Seguimientos
          </Link>
        </div>
      </section>
    </div>
  );
}
