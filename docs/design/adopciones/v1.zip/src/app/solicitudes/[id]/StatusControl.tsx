"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { STATUS_META } from "@/lib/ui";

const OPTIONS = ["pendiente", "en_proceso", "aprobado", "rechazado"];

export default function StatusControl({
  applicationId,
  current,
}: {
  applicationId: number;
  current: string;
}) {
  const router = useRouter();
  const [status, setStatus] = useState(current);
  const [saving, setSaving] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  async function update(next: string) {
    if (next === status) return;
    setSaving(next);
    const res = await fetch(`/api/applications/${applicationId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: next }),
    });
    if (res.ok) {
      setStatus(next);
      startTransition(() => router.refresh());
    }
    setSaving(null);
  }

  return (
    <div className="rounded-3xl bg-white p-4 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
      <h3 className="text-sm font-extrabold">Estado de la solicitud</h3>
      <p className="text-[11px] font-semibold text-ink-500">
        Panel del refugio · actualiza el avance
      </p>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {OPTIONS.map((opt) => {
          const meta = STATUS_META[opt];
          const active = opt === status;
          return (
            <button
              key={opt}
              onClick={() => update(opt)}
              disabled={saving !== null}
              className={`flex items-center gap-2 rounded-2xl px-3 py-2.5 text-[11px] font-extrabold transition active:scale-95 ${
                active
                  ? "bg-ink-900 text-white shadow-md"
                  : "bg-cream text-ink-700 ring-1 ring-stone-200"
              }`}
            >
              <span className={`h-2.5 w-2.5 rounded-full ${meta.dot}`} />
              {saving === opt ? "Guardando…" : meta.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}
