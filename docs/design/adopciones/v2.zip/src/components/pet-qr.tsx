function hashString(value: string): number {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

const SIZE = 23;

function isFinderZone(x: number, y: number): boolean {
  const inTopLeft = x < 8 && y < 8;
  const inTopRight = x >= SIZE - 8 && y < 8;
  const inBottomLeft = x < 8 && y >= SIZE - 8;
  return inTopLeft || inTopRight || inBottomLeft;
}

export function PetQr({ value, className = "" }: { value: string; className?: string }) {
  let seed = hashString(value);
  const random = () => {
    seed = (seed * 1664525 + 1013904223) >>> 0;
    return seed / 4294967296;
  };

  const cells: { x: number; y: number }[] = [];
  for (let y = 0; y < SIZE; y += 1) {
    for (let x = 0; x < SIZE; x += 1) {
      if (isFinderZone(x, y)) continue;
      if (random() > 0.52) cells.push({ x, y });
    }
  }

  const finders = [
    { x: 0, y: 0 },
    { x: SIZE - 7, y: 0 },
    { x: 0, y: SIZE - 7 },
  ];

  return (
    <svg
      viewBox={`-1 -1 ${SIZE + 2} ${SIZE + 2}`}
      className={className}
      role="img"
      aria-label={`Código QR del pasaporte ${value}`}
      shapeRendering="crispEdges"
    >
      <rect x={-1} y={-1} width={SIZE + 2} height={SIZE + 2} fill="white" />
      {cells.map((cell) => (
        <rect
          key={`${cell.x}-${cell.y}`}
          x={cell.x}
          y={cell.y}
          width={1}
          height={1}
          fill="#33302e"
        />
      ))}
      {finders.map((finder) => (
        <g key={`${finder.x}-${finder.y}`}>
          <rect
            x={finder.x}
            y={finder.y}
            width={7}
            height={7}
            fill="#33302e"
          />
          <rect
            x={finder.x + 1}
            y={finder.y + 1}
            width={5}
            height={5}
            fill="white"
          />
          <rect
            x={finder.x + 2}
            y={finder.y + 2}
            width={3}
            height={3}
            fill="#33302e"
          />
        </g>
      ))}
    </svg>
  );
}
