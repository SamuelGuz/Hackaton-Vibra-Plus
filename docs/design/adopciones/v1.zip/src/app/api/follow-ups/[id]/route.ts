import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { followUps } from "@/db/schema";
import { bootstrap } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  await bootstrap();
  const { id } = await params;
  const body = (await request.json()) as { done?: boolean; note?: string };

  const values: { done?: boolean; note?: string } = {};
  if (typeof body.done === "boolean") values.done = body.done;
  if (typeof body.note === "string") values.note = body.note;

  if (Object.keys(values).length === 0) {
    return NextResponse.json({ error: "Nada que actualizar" }, { status: 400 });
  }

  const [updated] = await db
    .update(followUps)
    .set(values)
    .where(eq(followUps.id, Number(id)))
    .returning();

  if (!updated) {
    return NextResponse.json({ error: "No encontrado" }, { status: 404 });
  }

  return NextResponse.json({ followUp: updated });
}
