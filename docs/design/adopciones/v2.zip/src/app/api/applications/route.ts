import { createApplication, listApplications } from "@/db/queries";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status") ?? undefined;
  const rows = await listApplications(status ?? undefined);
  return Response.json({
    ok: true,
    applications: rows.map((row) => ({
      ...row.application,
      pet: row.pet,
    })),
  });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const petId = Number(body.petId);
    const applicantName = String(body.applicantName ?? "").trim();
    const email = String(body.email ?? "").trim();
    const phone = String(body.phone ?? "").trim();
    const city = String(body.city ?? "").trim();
    const housing = String(body.housing ?? "").trim();
    const household = String(body.household ?? "").trim();

    const errors: Record<string, string> = {};
    if (!Number.isInteger(petId) || petId <= 0) errors.petId = "Mascota no válida";
    if (applicantName.length < 3)
      errors.applicantName = "Escribe tu nombre completo";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))
      errors.email = "Introduce un email válido";
    if (phone.replace(/\D/g, "").length < 9)
      errors.phone = "Introduce un teléfono válido";
    if (city.length < 2) errors.city = "Indica tu ciudad";
    if (!housing) errors.housing = "Selecciona tu tipo de vivienda";
    if (!household) errors.household = "Cuéntanos con quién vives";

    if (Object.keys(errors).length > 0) {
      return Response.json({ ok: false, errors }, { status: 400 });
    }

    const application = await createApplication({
      petId,
      applicantName,
      email,
      phone,
      city,
      housing,
      household,
      experience: String(body.experience ?? "").trim(),
      message: String(body.message ?? "").trim(),
    });

    return Response.json({ ok: true, application }, { status: 201 });
  } catch (error) {
    console.error("[applications] POST", error);
    return Response.json(
      { ok: false, error: "No pudimos guardar tu solicitud. Inténtalo de nuevo." },
      { status: 500 },
    );
  }
}
