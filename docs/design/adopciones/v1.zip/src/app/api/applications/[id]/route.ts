import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { applications } from "@/db/schema";
import { bootstrap, getApplication } from "@/lib/data";

export const dynamic = "force-dynamic";

const PROGRESS: Record<string, number> = {
  pendiente: 20,
  en_proceso: 60,
  aprobado: 100,
  rechazado: 100,
};

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const application = await getApplication(Number(id));
  if (!application) {
    return NextResponse.json({ error: "No encontrada" }, { status: 404 });
  }
  return NextResponse.json({ application });
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  await bootstrap();
  const { id } = await params;
  const body = (await request.json()) as { status?: string };
  const status = body.status;

  if (!status || !(status in PROGRESS)) {
    return NextResponse.json({ error: "Estado inválido" }, { status: 400 });
  }

  const [updated] = await db
    .update(applications)
    .set({ status, progress: PROGRESS[status] })
    .where(eq(applications.id, Number(id)))
    .returning();

  if (!updated) {
    return NextResponse.json({ error: "No encontrada" }, { status: 404 });
  }

  return NextResponse.json({ application: updated });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  await bootstrap();
  const { id } = await params;
  await db.delete(applications).where(eq(applications.id, Number(id)));
  return NextResponse.json({ ok: true });
}
