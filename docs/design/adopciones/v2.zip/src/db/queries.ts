import { and, asc, desc, eq, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  applications,
  followUps,
  passports,
  pets,
  vaccines,
  type Application,
  type FollowUp,
  type Passport,
  type Pet,
  type Vaccine,
} from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { isoOffset } from "@/lib/dates";

export type PetWithApplication = {
  pet: Pet;
  application: Application | null;
};

export type ApplicationWithPet = {
  application: Application;
  pet: Pet;
};

export async function listPets(species?: string): Promise<Pet[]> {
  await ensureSeeded();
  const query = db.select().from(pets).$dynamic();
  const filtered =
    species === "perro" || species === "gato"
      ? query.where(eq(pets.species, species))
      : query;
  return filtered.orderBy(desc(pets.featured), desc(pets.createdAt));
}

export async function getPet(id: number): Promise<Pet | null> {
  await ensureSeeded();
  const rows = await db.select().from(pets).where(eq(pets.id, id)).limit(1);
  return rows[0] ?? null;
}

export type ShelterStats = {
  available: number;
  adopted: number;
  dogs: number;
  cats: number;
  shelters: number;
  activeApplications: number;
};

export async function getStats(): Promise<ShelterStats> {
  await ensureSeeded();
  const [petRow] = await db
    .select({
      available: sql<number>`(count(*) filter (where ${pets.status} = 'disponible'))::int`,
      adopted: sql<number>`(count(*) filter (where ${pets.status} = 'adoptado'))::int`,
      dogs: sql<number>`(count(*) filter (where ${pets.species} = 'perro'))::int`,
      cats: sql<number>`(count(*) filter (where ${pets.species} = 'gato'))::int`,
      shelters: sql<number>`count(distinct ${pets.shelter})::int`,
    })
    .from(pets);

  const [applicationRow] = await db
    .select({
      activeApplications: sql<number>`(count(*) filter (where ${applications.status} = 'en_proceso'))::int`,
    })
    .from(applications);

  return {
    available: petRow?.available ?? 0,
    adopted: petRow?.adopted ?? 0,
    dogs: petRow?.dogs ?? 0,
    cats: petRow?.cats ?? 0,
    shelters: petRow?.shelters ?? 0,
    activeApplications: applicationRow?.activeApplications ?? 0,
  };
}

export async function listApplications(
  status?: string,
): Promise<ApplicationWithPet[]> {
  await ensureSeeded();
  const query = db
    .select({ application: applications, pet: pets })
    .from(applications)
    .innerJoin(pets, eq(applications.petId, pets.id))
    .$dynamic();

  const filtered =
    status === "en_proceso" ||
    status === "aprobada" ||
    status === "rechazada"
      ? query.where(eq(applications.status, status))
      : query;

  return filtered.orderBy(desc(applications.createdAt));
}

export async function getApplicationCounts(): Promise<{
  todas: number;
  en_proceso: number;
  aprobada: number;
  rechazada: number;
}> {
  await ensureSeeded();
  const rows = await db
    .select({
      status: applications.status,
      count: sql<number>`count(*)::int`,
    })
    .from(applications)
    .groupBy(applications.status);

  const base = { todas: 0, en_proceso: 0, aprobada: 0, rechazada: 0 };
  for (const row of rows) {
    base.todas += row.count;
    if (row.status in base && row.status !== "todas") {
      base[row.status as "en_proceso" | "aprobada" | "rechazada"] = row.count;
    }
  }
  return base;
}

export async function getLatestApplicationForPet(
  petId: number,
): Promise<Application | null> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(applications)
    .where(eq(applications.petId, petId))
    .orderBy(desc(applications.createdAt))
    .limit(1);
  return rows[0] ?? null;
}

export type PassportWithPet = { pet: Pet; passport: Passport };

export async function listPassports(): Promise<PassportWithPet[]> {
  await ensureSeeded();
  return db
    .select({ pet: pets, passport: passports })
    .from(passports)
    .innerJoin(pets, eq(passports.petId, pets.id))
    .orderBy(desc(passports.issuedAt));
}

export type PassportBundle = {
  pet: Pet;
  passport: Passport | null;
  vaccines: Vaccine[];
  application: Application | null;
};

export async function getPassportBundle(
  petId: number,
): Promise<PassportBundle | null> {
  await ensureSeeded();
  const pet = await getPet(petId);
  if (!pet) return null;

  const [passport] = await db
    .select()
    .from(passports)
    .where(eq(passports.petId, petId))
    .limit(1);

  const vaccineRows = await db
    .select()
    .from(vaccines)
    .where(eq(vaccines.petId, petId))
    .orderBy(asc(vaccines.sortOrder));

  const application = await getLatestApplicationForPet(petId);

  return {
    pet,
    passport: passport ?? null,
    vaccines: vaccineRows,
    application,
  };
}

export type FollowUpSummary = {
  pet: Pet;
  total: number;
  completed: number;
  nextTitle: string | null;
  nextDueOn: string | null;
};

export async function listFollowUpSummaries(): Promise<FollowUpSummary[]> {
  await ensureSeeded();
  const rows = await db
    .select({
      pet: pets,
      total: sql<number>`count(${followUps.id})::int`,
      completed: sql<number>`(count(${followUps.completedAt}))::int`,
    })
    .from(pets)
    .innerJoin(followUps, eq(followUps.petId, pets.id))
    .groupBy(pets.id)
    .orderBy(desc(sql`count(${followUps.completedAt})`));

  const pending = await db
    .select({
      petId: followUps.petId,
      title: followUps.title,
      dueOn: followUps.dueOn,
    })
    .from(followUps)
    .where(sql`${followUps.completedAt} is null`)
    .orderBy(asc(followUps.dueOn));

  return rows.map((row) => {
    const next = pending.find((item) => item.petId === row.pet.id) ?? null;
    return {
      pet: row.pet,
      total: row.total,
      completed: row.completed,
      nextTitle: next?.title ?? null,
      nextDueOn: next?.dueOn ?? null,
    };
  });
}

export type FollowUpBundle = {
  pet: Pet;
  application: Application | null;
  events: FollowUp[];
  passport: Passport | null;
};

export async function getFollowUpBundle(
  petId: number,
): Promise<FollowUpBundle | null> {
  await ensureSeeded();
  const pet = await getPet(petId);
  if (!pet) return null;

  const events = await db
    .select()
    .from(followUps)
    .where(eq(followUps.petId, petId))
    .orderBy(asc(followUps.sortOrder), asc(followUps.dueOn));

  const [passport] = await db
    .select()
    .from(passports)
    .where(eq(passports.petId, petId))
    .limit(1);

  const application = await getLatestApplicationForPet(petId);

  return { pet, application, events, passport: passport ?? null };
}

export type NewApplicationInput = {
  petId: number;
  applicantName: string;
  email: string;
  phone: string;
  city: string;
  housing: string;
  household: string;
  experience: string;
  message: string;
};

export async function createApplication(
  input: NewApplicationInput,
): Promise<Application> {
  await ensureSeeded();
  const pet = await getPet(input.petId);
  if (!pet) throw new Error("La mascota no existe");

  const [application] = await db
    .insert(applications)
    .values({
      petId: input.petId,
      applicantName: input.applicantName,
      email: input.email,
      phone: input.phone,
      city: input.city,
      housing: input.housing,
      household: input.household,
      experience: input.experience,
      message: input.message,
      status: "en_proceso",
    })
    .returning();

  if (pet.status === "disponible") {
    await db
      .update(pets)
      .set({ status: "en_proceso" })
      .where(eq(pets.id, pet.id));
  }

  return application;
}

export async function ensurePassportForPet(petId: number): Promise<void> {
  const [existing] = await db
    .select({ id: passports.id })
    .from(passports)
    .where(eq(passports.petId, petId))
    .limit(1);
  if (existing) return;

  const year = new Date().getFullYear();
  await db.insert(passports).values({
    petId,
    code: `AD-${year}-${String(petId).padStart(3, "0")}`,
    vetName: "Dra. Elena Ruiz",
    clinic: "Clínica Vetmigo",
    lastCheckup: isoOffset(0),
    weightKg: "—",
    microchipId: `941 000 ${String(4000000 + petId).slice(0, 3)} ${String(petId).padStart(3, "0")} ${String(Date.now()).slice(-3)}`,
    vaccinesProgress: 50,
    dewormedProgress: 100,
    microchipProgress: 100,
    notes:
      "Pasaporte abierto al aprobar la adopción. La clínica completará el calendario en la primera visita.",
  });

  await db.insert(vaccines).values([
    {
      petId,
      name: "Polivalente",
      dose: "Dosis anual",
      appliedOn: isoOffset(-55),
      nextDueOn: isoOffset(310),
      status: "completa",
      sortOrder: 0,
    },
    {
      petId,
      name: "Rabia",
      dose: "Dosis anual",
      appliedOn: isoOffset(-55),
      nextDueOn: isoOffset(310),
      status: "completa",
      sortOrder: 1,
    },
    {
      petId,
      name: "Refuerzo pendiente",
      dose: "Según calendario",
      appliedOn: isoOffset(-5),
      nextDueOn: isoOffset(21),
      status: "pendiente",
      sortOrder: 2,
    },
  ]);
}

export async function ensureFollowUpPlan(petId: number): Promise<void> {
  const [existing] = await db
    .select({ id: followUps.id })
    .from(followUps)
    .where(eq(followUps.petId, petId))
    .limit(1);
  if (existing) return;

  await db.insert(followUps).values([
    {
      petId,
      title: "Visita de bienvenida",
      description:
        "Primera visita al nuevo hogar para revisar la adaptación del animal.",
      type: "visita",
      dueOn: isoOffset(7),
      sortOrder: 0,
    },
    {
      petId,
      title: "Vacuna de refuerzo",
      description: "Cita en la clínica veterinaria de referencia.",
      type: "vacuna",
      dueOn: isoOffset(21),
      sortOrder: 1,
    },
    {
      petId,
      title: "Foto de actualización",
      description: "Comparte una foto para el mural de adopciones felices.",
      type: "foto",
      dueOn: isoOffset(30),
      sortOrder: 2,
    },
  ]);
}

export async function decideApplication(
  id: number,
  status: "aprobada" | "rechazada",
): Promise<Application | null> {
  const [application] = await db
    .select()
    .from(applications)
    .where(eq(applications.id, id))
    .limit(1);
  if (!application) return null;

  const [updated] = await db
    .update(applications)
    .set({ status, updatedAt: new Date() })
    .where(eq(applications.id, id))
    .returning();

  if (status === "aprobada") {
    await db
      .update(pets)
      .set({ status: "adoptado" })
      .where(eq(pets.id, application.petId));
    await ensurePassportForPet(application.petId);
    await ensureFollowUpPlan(application.petId);
  } else {
    await db
      .update(pets)
      .set({ status: "disponible" })
      .where(and(eq(pets.id, application.petId), ne(pets.status, "adoptado")));
  }

  return updated;
}

export type NewFollowUpInput = {
  petId: number;
  title: string;
  description: string;
  type: "visita" | "vacuna" | "foto" | "llamada";
  dueOn: string;
};

export async function createFollowUp(
  input: NewFollowUpInput,
): Promise<FollowUp> {
  const [last] = await db
    .select({ sortOrder: followUps.sortOrder })
    .from(followUps)
    .where(eq(followUps.petId, input.petId))
    .orderBy(desc(followUps.sortOrder))
    .limit(1);

  const [created] = await db
    .insert(followUps)
    .values({
      petId: input.petId,
      title: input.title,
      description: input.description,
      type: input.type,
      dueOn: input.dueOn,
      sortOrder: (last?.sortOrder ?? 0) + 1,
    })
    .returning();

  return created;
}

export async function toggleFollowUp(id: number): Promise<FollowUp | null> {
  const [event] = await db
    .select()
    .from(followUps)
    .where(eq(followUps.id, id))
    .limit(1);
  if (!event) return null;

  const [updated] = await db
    .update(followUps)
    .set({ completedAt: event.completedAt ? null : new Date() })
    .where(eq(followUps.id, id))
    .returning();

  return updated;
}
