import Link from "next/link";
import { notFound } from "next/navigation";
import QRCode from "qrcode";
import { Screen, ScreenBody, ScreenHeader } from "@/components/Screen";
import { getPassport, getPet } from "@/lib/data";
import { CATEGORY_META, formatDate, speciesEmoji } from "@/lib/ui";

export const dynamic = "force-dynamic";

export default async function PassportPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const pet = await getPet(Number(id));
  if (!pet) notFound();

  const records = await getPassport(pet.id);
  const qr = await QRCode.toString(
    `PATITAS|${pet.name}|chip:${pet.microchip.replace(/\s/g, "")}`,
    { type: "svg", margin: 0, color: { dark: "#37302b", light: "#00000000" } },
  );

  const health = Math.round(
    records.reduce((acc, r) => acc + r.completion, 0) /
      Math.max(records.length, 1),
  );

  return (
    <Screen>
      <ScreenHeader
        title="Pasaporte"
        subtitle={`${pet.name} · ${pet.shelter}`}
        backHref={`/mascotas/${pet.id}`}
        tone="coral"
        emoji="🪪"
      />
      <ScreenBody>
        <div className="animate-pop relative overflow-hidden rounded-[30px] bg-white p-5 shadow-[0_18px_40px_-22px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <div className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full bg-mint-100" />
          <div className="relative flex flex-col items-center">
            <div className="relative">
              <span className="absolute inset-0 -z-10 translate-y-2 scale-110 rounded-full bg-sun-300 blur-sm" />
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={pet.photoUrl}
                alt={pet.name}
                className="h-28 w-28 rounded-full object-cover ring-[6px] ring-sun-300"
              />
              <span className="absolute -bottom-1 right-0 flex h-9 w-9 items-center justify-center rounded-full bg-white text-lg shadow">
                {speciesEmoji(pet.species)}
              </span>
            </div>
            <h2 className="mt-3 text-2xl font-extrabold">{pet.name}</h2>
            <p className="text-[11px] font-bold text-ink-500">
              {pet.breed} · {pet.sex} · {pet.ageLabel}
            </p>

            <div className="mt-3 grid w-full grid-cols-3 gap-2">
              {[
                { k: "Peso", v: `${pet.weightKg} kg` },
                { k: "Tamaño", v: pet.size },
                { k: "Salud", v: `${health}%` },
              ].map((c) => (
                <div
                  key={c.k}
                  className="rounded-2xl bg-cream px-2 py-2 text-center"
                >
                  <p className="text-[9px] font-extrabold uppercase tracking-wide text-ink-500">
                    {c.k}
                  </p>
                  <p className="text-xs font-extrabold">{c.v}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 space-y-3">
            {records.map((rec) => {
              const meta = CATEGORY_META[rec.category] ?? CATEGORY_META.revision;
              return (
                <div key={rec.id}>
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-xs font-extrabold">
                      {meta.icon} {rec.label}
                    </p>
                    <span
                      className={`flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-extrabold ${
                        rec.done
                          ? "bg-mint-200 text-mint-600"
                          : "bg-sun-200 text-amber-700"
                      }`}
                    >
                      {rec.done ? "✓" : "!"}
                    </span>
                  </div>
                  <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-stone-200">
                    <div
                      className={`h-full rounded-full ${meta.bar}`}
                      style={{ width: `${rec.completion}%` }}
                    />
                  </div>
                  <div className="mt-1 flex justify-between text-[10px] font-semibold text-ink-500">
                    <span className="truncate">{rec.detail || meta.label}</span>
                    <span className="shrink-0">
                      {rec.nextDueOn
                        ? `Próx. ${formatDate(rec.nextDueOn)}`
                        : formatDate(rec.appliedOn)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-5 flex items-center gap-3 rounded-2xl bg-cream p-3">
            <div
              className="h-20 w-20 shrink-0 rounded-xl bg-white p-1.5"
              dangerouslySetInnerHTML={{ __html: qr }}
            />
            <div className="min-w-0">
              <p className="text-[10px] font-extrabold uppercase tracking-wide text-ink-500">
                Microchip
              </p>
              <p className="text-xs font-extrabold">{pet.microchip}</p>
              <p className="mt-1 text-[10px] font-semibold leading-snug text-ink-500">
                Escanea para validar el registro sanitario de {pet.name}.
              </p>
            </div>
          </div>
        </div>

        <div className="flex gap-2.5">
          <Link
            href={`/mascotas/${pet.id}`}
            className="flex-1 rounded-2xl bg-white py-3.5 text-center text-sm font-extrabold text-ink-700 shadow-md ring-1 ring-black/5"
          >
            Ver ficha
          </Link>
          <Link
            href="/pasaporte"
            className="flex-1 rounded-2xl bg-mint-400 py-3.5 text-center text-sm font-extrabold text-white shadow-lg shadow-mint-200 transition active:scale-95"
          >
            Todos los pasaportes
          </Link>
        </div>
      </ScreenBody>
    </Screen>
  );
}
