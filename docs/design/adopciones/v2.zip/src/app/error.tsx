"use client";

import { useEffect } from "react";
import Link from "next/link";
import { PawPrint, RefreshCw } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="card mx-auto flex max-w-xl flex-col items-center gap-4 px-6 py-16 text-center">
      <span className="grid h-20 w-20 place-items-center rounded-full bg-coral-50 text-coral-500">
        <PawPrint className="h-10 w-10" />
      </span>
      <h1 className="font-display text-3xl font-bold leading-tight">
        Se nos escapó un gatito por el teclado
      </h1>
      <p className="max-w-sm text-sm font-medium leading-relaxed text-muted">
        Algo no cargó correctamente. Vuelve a intentarlo; si persiste, revisa la
        conexión con la base de datos.
      </p>
      <div className="mt-2 flex flex-wrap justify-center gap-2">
        <button type="button" onClick={reset} className="btn-primary">
          <RefreshCw className="h-4 w-4" />
          Reintentar
        </button>
        <Link href="/" className="btn-outline">
          Ir al inicio
        </Link>
      </div>
    </div>
  );
}
