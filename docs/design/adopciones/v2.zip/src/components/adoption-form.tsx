"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import {
  CheckCircle2,
  ChevronDown,
  ClipboardList,
  Heart,
  Loader2,
  Send,
} from "lucide-react";

type Errors = Record<string, string>;

const housingOptions = [
  "Piso interior",
  "Piso con terraza o balcón",
  "Casa con jardín",
  "Casa sin jardín",
];

const householdOptions = [
  "Vivo solo/a",
  "En pareja",
  "Familia con niños",
  "Familia con otras mascotas",
];

export function AdoptionForm({
  petId,
  petName,
  defaultCity,
  existingStatus,
  existingApplicant,
}: {
  petId: number;
  petName: string;
  defaultCity: string;
  existingStatus: string | null;
  existingApplicant: string | null;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(!existingStatus);
  const [isPending, startTransition] = useTransition();
  const [sending, setSending] = useState(false);
  const [errors, setErrors] = useState<Errors>({});
  const [globalError, setGlobalError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const [form, setForm] = useState({
    applicantName: "",
    email: "",
    phone: "",
    city: defaultCity,
    housing: "",
    household: "",
    experience: "",
    message: "",
  });

  function update(field: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSending(true);
    setErrors({});
    setGlobalError(null);
    try {
      const response = await fetch("/api/applications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, petId }),
      });
      const data = (await response.json().catch(() => null)) as {
        ok?: boolean;
        errors?: Errors;
        error?: string;
      } | null;

      if (!response.ok || !data?.ok) {
        setErrors(data?.errors ?? {});
        setGlobalError(
          data?.error ?? "Revisa los campos marcados antes de enviar.",
        );
        return;
      }

      setDone(true);
      startTransition(() => router.refresh());
    } catch {
      setGlobalError("No pudimos enviar la solicitud. Inténtalo de nuevo.");
    } finally {
      setSending(false);
    }
  }

  if (done || existingStatus) {
    const approved = existingStatus === "aprobada";
    const rejected = existingStatus === "rechazada";
    return (
      <div className="card animate-pop overflow-hidden">
        <div className={rejected ? "bg-rose-50 px-5 py-4" : "bg-mint-100 px-5 py-4"}>
          <p
            className={`flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.14em] ${
              rejected ? "text-rose-700" : "text-mint-700"
            }`}
          >
            <CheckCircle2 className="h-4 w-4" />
            {approved
              ? "¡Adopción aprobada!"
              : rejected
                ? "Solicitud no admitida"
                : "Solicitud recibida"}
          </p>
        </div>
        <div className="space-y-3 p-5">
          <h2 className="font-display text-2xl font-bold leading-tight">
            {approved
              ? `${petName} ya tiene su familia`
              : rejected
                ? `Esta solicitud por ${petName} no salió adelante`
                : `Estamos revisando tu solicitud por ${petName}`}
          </h2>
          <p className="text-sm font-medium leading-relaxed text-muted">
            {approved
              ? "El equipo del refugio se pondrá en contacto contigo para la entrega. Mientras tanto puedes revisar el pasaporte veterinario y el plan de seguimiento."
              : rejected
                ? `Gracias${existingApplicant ? `, ${existingApplicant}` : ""} por tu interés. El refugio no pudo continuar con esta adopción, pero hay muchos otros animales esperando. Te animamos a conocerlos.`
                : `Gracias${existingApplicant ? `, ${existingApplicant}` : ""}. El refugio revisará tu perfil y te escribirá en las próximas 48 horas. Te avisaremos con cada cambio de estado.`}
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <Link href="/solicitudes" className="btn-primary px-4 py-2.5 text-xs">
              <ClipboardList className="h-4 w-4" />
              Ver mis solicitudes
            </Link>
            <Link
              href={`/pasaporte/${petId}`}
              className="btn-outline px-4 py-2.5 text-xs"
            >
              Pasaporte
            </Link>
            <Link
              href={`/seguimiento/${petId}`}
              className="btn-outline px-4 py-2.5 text-xs"
            >
              Seguimiento
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="card overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="flex w-full items-center justify-between gap-3 bg-coral-50 px-5 py-4 text-left"
      >
        <span>
          <span className="flex items-center gap-2 text-xs font-extrabold uppercase tracking-[0.14em] text-coral-600">
            <Heart className="h-4 w-4 fill-coral-500 text-coral-500" />
            Solicitud de adopción
          </span>
          <span className="mt-1 block font-display text-xl font-bold leading-tight text-ink">
            Quiero adoptar a {petName}
          </span>
        </span>
        <ChevronDown
          className={`h-5 w-5 shrink-0 text-coral-500 transition ${open ? "rotate-180" : ""}`}
        />
      </button>

      {open ? (
        <form onSubmit={submit} className="space-y-3 p-5">
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Nombre y apellidos" error={errors.applicantName}>
              <input
                className="input"
                value={form.applicantName}
                onChange={(event) => update("applicantName", event.target.value)}
                placeholder="Marta Ruiz"
                required
              />
            </Field>
            <Field label="Email" error={errors.email}>
              <input
                className="input"
                type="email"
                value={form.email}
                onChange={(event) => update("email", event.target.value)}
                placeholder="marta@email.com"
                required
              />
            </Field>
            <Field label="Teléfono" error={errors.phone}>
              <input
                className="input"
                value={form.phone}
                onChange={(event) => update("phone", event.target.value)}
                placeholder="+34 600 000 000"
                required
              />
            </Field>
            <Field label="Ciudad" error={errors.city}>
              <input
                className="input"
                value={form.city}
                onChange={(event) => update("city", event.target.value)}
                placeholder="Madrid"
                required
              />
            </Field>
            <Field label="Tipo de vivienda" error={errors.housing}>
              <select
                className="input"
                value={form.housing}
                onChange={(event) => update("housing", event.target.value)}
                required
              >
                <option value="">Selecciona una opción</option>
                {housingOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Con quién vives" error={errors.household}>
              <select
                className="input"
                value={form.household}
                onChange={(event) => update("household", event.target.value)}
                required
              >
                <option value="">Selecciona una opción</option>
                {householdOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </Field>
          </div>

          <Field label="Experiencia con animales (opcional)">
            <input
              className="input"
              value={form.experience}
              onChange={(event) => update("experience", event.target.value)}
              placeholder="He tenido gatos durante 10 años"
            />
          </Field>

          <Field label="¿Por qué quieres adoptarlo? (opcional)">
            <textarea
              className="input min-h-24 resize-y"
              value={form.message}
              onChange={(event) => update("message", event.target.value)}
              placeholder={`Cuéntanos cómo sería la vida de ${petName} contigo`}
            />
          </Field>

          {globalError ? (
            <p className="rounded-xl bg-rose-50 px-3 py-2 text-xs font-bold text-rose-700">
              {globalError}
            </p>
          ) : null}

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="submit"
              disabled={sending || isPending}
              className="btn-primary flex-1 px-5 py-3.5"
            >
              {sending || isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
              Enviar solicitud
            </button>
            <p className="max-w-[15rem] text-[11px] font-medium leading-snug text-muted">
              Al enviar aceptas que el refugio contacte contigo para valorar la
              adopción.
            </p>
          </div>
        </form>
      ) : null}
    </div>
  );
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="label">{label}</span>
      {children}
      {error ? (
        <span className="mt-1 block text-[11px] font-bold text-rose-600">
          {error}
        </span>
      ) : null}
    </label>
  );
}
