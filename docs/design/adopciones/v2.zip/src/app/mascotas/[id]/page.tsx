import Link from "next/link";
import { notFound } from "next/navigation";
import {
  ArrowLeft,
  Building2,
  CalendarCheck,
  Check,
  ChevronRight,
  Clock,
  Heart,
  IdCard,
  MapPin,
  Mars,
  Phone,
  Route,
  Ruler,
  ShieldCheck,
  Sparkles,
  Syringe,
  Venus,
} from "lucide-react";
import { AdoptionForm } from "@/components/adoption-form";
import { FavoriteButton } from "@/components/favorite-button";
import { PetStatusPill } from "@/components/status-pill";
import {
  getLatestApplicationForPet,
  getPassportBundle,
  getPet,
  getFollowUpBundle,
} from "@/db/queries";
import { ageLabel, shortDate, speciesLabel } from "@/lib/format";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const pet = await getPet(Number(id));
  return {
    title: pet ? `${pet.name} busca familia — Huellitas` : "Detalle — Huellitas",
    description: pet?.tagline,
  };
}

export default async function DetallePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const petId = Number(id);
  if (!Number.isInteger(petId)) notFound();

  const [pet, passportBundle, followUpBundle, application] = await Promise.all([
    getPet(petId),
    getPassportBundle(petId),
    getFollowUpBundle(petId),
    getLatestApplicationForPet(petId),
  ]);

  if (!pet) notFound();

  const passport = passportBundle?.passport ?? null;
  const followUps = followUpBundle?.events ?? [];
  const completed = followUps.filter((event) => event.completedAt).length;
  const progress =
    followUps.length > 0 ? Math.round((completed / followUps.length) * 100) : 0;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <Link
          href="/#mascotas"
          className="inline-flex items-center gap-2 rounded-full border border-white bg-white/80 px-3.5 py-2 text-xs font-extrabold text-ink shadow-soft transition hover:bg-white"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Volver a mascotas
        </Link>
        <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-muted">
          Módulo Detalle
          <span className="h-1 w-1 rounded-full bg-coral-300" />
          {pet.shelter}
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[0.92fr_1.08fr]">
        {/* Foto */}
        <div className="relative">
          <div className="absolute inset-y-6 -left-2 w-6 rounded-full bg-mint-300/70 sm:-left-3 sm:w-8" />
          <div className="absolute inset-y-10 -left-4 w-3 rounded-full bg-sun-300/70 sm:-left-5" />
          <div className="relative aspect-[4/5] overflow-hidden rounded-[32px] bg-shell shadow-soft ring-4 ring-white">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={pet.photoUrl}
              alt={`${pet.name}, ${pet.breed} en adopción`}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-x-0 top-0 flex items-start justify-between bg-gradient-to-b from-black/35 to-transparent p-4 pb-10">
              <PetStatusPill status={pet.status} className="bg-white/95 text-ink ring-white/60" />
              <FavoriteButton petId={pet.id} petName={pet.name} />
            </div>
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 via-black/25 to-transparent p-5 pt-14 text-white">
              <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-[0.14em] text-white/80">
                <MapPin className="h-3.5 w-3.5" />
                {pet.city} · {pet.shelter}
              </p>
              <p className="mt-1 font-display text-4xl font-bold leading-none">
                {pet.name}
              </p>
              <p className="mt-1.5 text-sm font-semibold text-white/85">
                {pet.breed} · {ageLabel(pet.ageMonths)}
              </p>
            </div>
          </div>
          <div className="absolute -right-2 top-1/2 hidden -translate-y-1/2 sm:block">
            <div className="animate-floaty rounded-2xl bg-white px-3 py-2 text-center shadow-soft">
              <p className="text-lg font-extrabold text-coral-500">
                {pet.species === "gato" ? "🐱" : "🐶"}
              </p>
              <p className="text-[9px] font-extrabold uppercase tracking-wide text-muted">
                {speciesLabel(pet.species)}
              </p>
            </div>
          </div>
        </div>

        {/* Información */}
        <div className="space-y-4">
          <div className="card p-5 sm:p-6">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="text-[11px] font-extrabold uppercase tracking-[0.18em] text-coral-500">
                  {speciesLabel(pet.species)} en adopción
                </p>
                <h1 className="font-display text-4xl font-bold leading-none text-ink">
                  {pet.name}
                </h1>
                <p className="mt-2 max-w-md text-sm font-semibold leading-relaxed text-muted">
                  {pet.tagline}
                </p>
              </div>
              <span className="flex items-center gap-1.5 rounded-full bg-coral-50 px-3 py-1.5 text-[11px] font-extrabold text-coral-600">
                <Heart className="h-3.5 w-3.5 fill-coral-400 text-coral-400" />
                #{pet.id.toString().padStart(3, "0")}
              </span>
            </div>

            <dl className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
              {[
                {
                  icon: Clock,
                  label: "Edad",
                  value: ageLabel(pet.ageMonths),
                  tone: "bg-coral-50 text-coral-600",
                },
                {
                  icon: pet.sex === "hembra" ? Venus : Mars,
                  label: "Sexo",
                  value: pet.sex === "hembra" ? "Hembra" : "Macho",
                  tone: "bg-mint-100 text-mint-700",
                },
                {
                  icon: Ruler,
                  label: "Tamaño",
                  value: pet.size,
                  tone: "bg-sun-100 text-amber-700",
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.label}
                    className="rounded-2xl border border-line/70 bg-cream/60 p-3"
                  >
                    <span
                      className={`grid h-8 w-8 place-items-center rounded-xl ${item.tone}`}
                    >
                      <Icon className="h-4 w-4" />
                    </span>
                    <dt className="mt-2 text-[10px] font-extrabold uppercase tracking-wide text-muted">
                      {item.label}
                    </dt>
                    <dd className="text-sm font-extrabold capitalize text-ink">
                      {item.value}
                    </dd>
                  </div>
                );
              })}
            </dl>

            <div className="mt-5">
              <h2 className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-muted">
                Su historia
              </h2>
              <p className="mt-2 text-sm font-medium leading-relaxed text-ink/75">
                {pet.story}
              </p>
            </div>

            <div className="mt-4">
              <h2 className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-muted">
                Personalidad
              </h2>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {pet.personality.map((trait) => (
                  <span key={trait} className="chip">
                    <Heart className="h-3 w-3 text-coral-400" />
                    {trait}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-2">
              <Link href="#solicitud" className="btn-primary flex-1 px-5 py-3.5">
                <Heart className="h-4 w-4" />
                Adoptar a {pet.name}
              </Link>
              <Link
                href={`/pasaporte/${pet.id}`}
                className="btn-mint px-4 py-3.5"
              >
                <IdCard className="h-4 w-4" />
                Pasaporte
              </Link>
              <Link
                href={`/seguimiento/${pet.id}`}
                className="btn-outline px-4 py-3.5"
              >
                <Route className="h-4 w-4" />
              </Link>
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="surface p-4">
              <p className="flex items-center gap-2 text-[11px] font-extrabold uppercase tracking-[0.14em] text-mint-700">
                <ShieldCheck className="h-4 w-4" />
                La adopción incluye
              </p>
              <ul className="mt-2 space-y-1.5 text-xs font-bold text-ink/70">
                {[
                  "Vacunación completa",
                  "Desparasitación interna y externa",
                  "Microchip identificativo",
                  "Seguimiento durante 3 meses",
                ].map((item) => (
                  <li key={item} className="flex items-center gap-2">
                    <span className="grid h-4 w-4 place-items-center rounded-full bg-mint-100 text-mint-700">
                      <Check className="h-2.5 w-2.5" strokeWidth={3.5} />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            <div className="card overflow-hidden">
              <div className="flex items-center gap-2 bg-sun-100 px-4 py-2.5 text-[11px] font-extrabold uppercase tracking-[0.12em] text-amber-900">
                <Building2 className="h-4 w-4" />
                Refugio responsable
              </div>
              <div className="space-y-1.5 p-4 text-xs font-semibold text-muted">
                <p className="font-display text-lg font-bold leading-none text-ink">
                  {pet.shelter}
                </p>
                <p className="flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-coral-400" />
                  {pet.city}
                </p>
                <p className="flex items-center gap-1.5">
                  <Phone className="h-3.5 w-3.5 text-coral-400" />
                  +34 600 123 456
                </p>
                <p className="flex items-center gap-1.5">
                  <CalendarCheck className="h-3.5 w-3.5 text-coral-400" />
                  Visitas de lunes a sábado
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div id="solicitud" className="grid scroll-mt-24 gap-4 lg:grid-cols-[1.15fr_0.85fr]">
        <AdoptionForm
          petId={pet.id}
          petName={pet.name}
          defaultCity={pet.city}
          existingStatus={application?.status ?? null}
          existingApplicant={application?.applicantName ?? null}
        />

        <div className="space-y-3">
          <Link
            href={`/pasaporte/${pet.id}`}
            className="card group flex items-center gap-3 p-4 transition hover:-translate-y-0.5"
          >
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-mint-100 text-mint-700">
              <Syringe className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-base font-bold leading-tight">
                {passport ? "Pasaporte veterinario" : "Pasaporte al aprobar"}
              </p>
              <p className="truncate text-[11px] font-bold text-muted">
                {passport
                  ? `Vacunas ${passport.vaccinesProgress}% · Microchip ${passport.microchipProgress}%`
                  : "Se genera automáticamente con la adopción"}
              </p>
            </div>
            <ChevronRight className="h-4 w-4 text-muted group-hover:text-mint-600" />
          </Link>

          <Link
            href={`/seguimiento/${pet.id}`}
            className="card group flex items-center gap-3 p-4 transition hover:-translate-y-0.5"
          >
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-sky-100 text-sky-700">
              <Route className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="font-display text-base font-bold leading-tight">
                Plan de seguimiento
              </p>
              <p className="text-[11px] font-bold text-muted">
                {followUps.length > 0
                  ? `${completed}/${followUps.length} hitos completados`
                  : "Se activa al aprobar la adopción"}
              </p>
              <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-cream">
                <div
                  className="h-full rounded-full bg-mint-400"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
            <ChevronRight className="h-4 w-4 text-muted group-hover:text-sky-600" />
          </Link>

          <div className="surface flex items-start gap-3 p-4">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-coral-50 text-coral-500">
              <Sparkles className="h-4 w-4" />
            </span>
            <div>
              <p className="text-xs font-extrabold">
                {application ? "Ya hay una solicitud abierta" : "Consejo Huellitas"}
              </p>
              <p className="mt-1 text-[11px] font-medium leading-snug text-muted">
                {application
                  ? `Estado actual: ${application.status.replace("_", " ")}. Puedes verla en el módulo de solicitudes.`
                  : "Visita al refugio antes de adoptar. Conoceréis el carácter real del animal y podréis resolver dudas."}
              </p>
              {followUps[0]?.dueOn ? (
                <p className="mt-1 text-[11px] font-bold text-sky-700">
                  Próximo hito: {shortDate(followUps.find((event) => !event.completedAt)?.dueOn ?? followUps[0].dueOn)}
                </p>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
