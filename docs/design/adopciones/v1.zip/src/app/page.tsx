import Link from "next/link";
import PetCard from "@/components/PetCard";
import { getPets, getStats } from "@/lib/data";

export const dynamic = "force-dynamic";

const FILTERS = [
  { key: "todos", label: "Todos", icon: "🐾" },
  { key: "perro", label: "Perros", icon: "🐶" },
  { key: "gato", label: "Gatos", icon: "🐱" },
];

const MODULES = [
  {
    href: "/solicitudes",
    title: "Solicitudes",
    desc: "Estado de tus postulaciones",
    icon: "📋",
    tint: "bg-coral-100 text-coral-700",
  },
  {
    href: "/pasaporte",
    title: "Pasaporte",
    desc: "Vacunas y microchip",
    icon: "🪪",
    tint: "bg-mint-100 text-mint-600",
  },
  {
    href: "/seguimiento",
    title: "Seguimiento",
    desc: "Visitas y recordatorios",
    icon: "💗",
    tint: "bg-sun-100 text-amber-700",
  },
];

export default async function HomePage({
  searchParams,
}: {
  searchParams: Promise<{ especie?: string; q?: string }>;
}) {
  const params = await searchParams;
  const species = params.especie ?? "todos";
  const q = params.q ?? "";
  const [petList, stats] = await Promise.all([
    getPets(species, q),
    getStats(),
  ]);

  return (
    <div className="flex min-h-full flex-col">
      <header className="relative overflow-hidden rounded-b-[34px] bg-gradient-to-br from-coral-500 to-coral-400 px-5 pb-12 pt-6 text-white">
        <div className="pointer-events-none absolute -right-10 -top-12 h-36 w-36 rounded-full bg-white/15" />
        <div className="relative flex items-start justify-between">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.18em] text-white/80">
              Hola, Mariana 👋
            </p>
            <h1 className="mt-1 text-[28px] font-extrabold leading-tight">
              Encuentra a tu
              <br />
              nuevo mejor amigo
            </h1>
          </div>
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/25 text-2xl backdrop-blur">
            🐾
          </span>
        </div>

        <form action="/" className="relative mt-5 flex items-center gap-2">
          <div className="flex flex-1 items-center gap-2 rounded-2xl bg-white px-3 py-2.5 shadow-lg shadow-coral-700/20">
            <span className="text-base">🔍</span>
            <input
              name="q"
              defaultValue={q}
              placeholder="Busca por nombre, raza o ciudad"
              className="w-full bg-transparent text-sm font-semibold text-ink-900 outline-none placeholder:text-ink-500/70"
            />
          </div>
          <input type="hidden" name="especie" value={species} />
          <button
            type="submit"
            className="rounded-2xl bg-ink-900/85 px-4 py-3 text-sm font-extrabold shadow-lg transition active:scale-95"
          >
            Ir
          </button>
        </form>
      </header>

      <div className="-mt-7 flex-1 space-y-5 px-4 pb-6">
        <section className="grid grid-cols-3 gap-2.5">
          {[
            { label: "Peluditos", value: stats.pets, tint: "text-coral-600" },
            {
              label: "Solicitudes",
              value: stats.applications,
              tint: "text-mint-600",
            },
            { label: "Adopciones", value: stats.approved, tint: "text-amber-600" },
          ].map((s) => (
            <div
              key={s.label}
              className="rounded-2xl bg-white px-3 py-3 text-center shadow-[0_10px_24px_-18px_rgba(92,83,76,0.8)] ring-1 ring-black/5"
            >
              <p className={`text-xl font-extrabold ${s.tint}`}>{s.value}</p>
              <p className="text-[10px] font-bold uppercase tracking-wide text-ink-500">
                {s.label}
              </p>
            </div>
          ))}
        </section>

        <section className="space-y-2.5">
          <h2 className="px-1 text-sm font-extrabold text-ink-900">Módulos</h2>
          <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-1">
            {MODULES.map((m) => (
              <Link
                key={m.href}
                href={m.href}
                className="flex min-w-[148px] flex-1 items-center gap-2.5 rounded-2xl bg-white p-3 shadow-[0_10px_24px_-18px_rgba(92,83,76,0.8)] ring-1 ring-black/5 transition active:scale-[0.97]"
              >
                <span
                  className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-lg ${m.tint}`}
                >
                  {m.icon}
                </span>
                <span className="min-w-0">
                  <span className="block truncate text-sm font-extrabold">
                    {m.title}
                  </span>
                  <span className="block truncate text-[10px] font-semibold text-ink-500">
                    {m.desc}
                  </span>
                </span>
              </Link>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-sm font-extrabold text-ink-900">
              Listos para adopción
            </h2>
            <span className="text-[11px] font-bold text-ink-500">
              {petList.length} resultados
            </span>
          </div>

          <div className="flex gap-2">
            {FILTERS.map((f) => {
              const active = f.key === species;
              const href = `/?especie=${f.key}${q ? `&q=${encodeURIComponent(q)}` : ""}`;
              return (
                <Link
                  key={f.key}
                  href={href}
                  className={`flex items-center gap-1.5 rounded-full px-3.5 py-2 text-xs font-extrabold transition ${
                    active
                      ? "bg-ink-900 text-white shadow-md"
                      : "bg-white text-ink-700 ring-1 ring-black/5"
                  }`}
                >
                  <span>{f.icon}</span>
                  {f.label}
                </Link>
              );
            })}
          </div>

          {petList.length === 0 ? (
            <div className="rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-black/5">
              <p className="text-4xl">🐾</p>
              <p className="mt-2 text-sm font-bold">Sin coincidencias</p>
              <p className="text-xs text-ink-500">
                Intenta con otro nombre o cambia el filtro.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {petList.map((pet, i) => (
                <div
                  key={pet.id}
                  className="animate-rise"
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  <PetCard pet={pet} />
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
