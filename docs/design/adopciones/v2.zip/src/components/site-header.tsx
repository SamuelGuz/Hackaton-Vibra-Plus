"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Heart, PawPrint, Sparkles } from "lucide-react";
import { navItems } from "@/components/nav-items";

export function SiteHeader() {
  const pathname = usePathname();

  return (
    <header className="sticky top-0 z-40 border-b border-white/60 bg-cream/80 backdrop-blur-xl no-print">
      <div className="mx-auto flex h-[74px] w-full max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" className="group flex items-center gap-3">
          <span className="relative grid h-11 w-11 place-items-center rounded-2xl bg-coral-500 text-white shadow-pop transition group-hover:-rotate-6">
            <PawPrint className="h-6 w-6" strokeWidth={2.4} />
            <span className="absolute -right-1.5 -top-1.5 grid h-5 w-5 place-items-center rounded-full bg-mint-400 text-[10px] ring-2 ring-cream">
              <Heart className="h-3 w-3 fill-white text-white" />
            </span>
          </span>
          <span className="leading-none">
            <span className="block font-display text-xl font-bold tracking-tight text-ink">
              Huellitas
            </span>
            <span className="mt-1 block text-[10px] font-extrabold uppercase tracking-[0.22em] text-coral-500">
              Adopciones
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 rounded-full border border-white bg-white/70 p-1.5 shadow-soft md:flex">
          {navItems.map((item) => {
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-2 rounded-full px-3.5 py-2 text-sm font-bold transition ${
                  active
                    ? "bg-coral-500 text-white shadow-pop"
                    : "text-ink/70 hover:bg-coral-50 hover:text-coral-600"
                }`}
              >
                <Icon className="h-4 w-4" strokeWidth={2.3} />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <Link href="/#mascotas" className="btn-primary hidden lg:inline-flex">
          <Sparkles className="h-4 w-4" />
          Adoptar ahora
        </Link>

        <Link
          href="/solicitudes"
          className="btn-primary px-4 py-2.5 text-xs md:hidden"
        >
          <Heart className="h-4 w-4" />
          Solicitudes
        </Link>
      </div>
    </header>
  );
}
