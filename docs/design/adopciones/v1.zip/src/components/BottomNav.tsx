"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const items = [
  { href: "/", label: "Inicio", icon: "🏠" },
  { href: "/solicitudes", label: "Solicitudes", icon: "📋" },
  { href: "/pasaporte", label: "Pasaporte", icon: "🪪" },
  { href: "/seguimiento", label: "Seguimiento", icon: "💗" },
];

export default function BottomNav() {
  const pathname = usePathname();

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname.startsWith(href);

  return (
    <nav className="pointer-events-none sticky bottom-0 z-30 px-4 pb-4">
      <div className="pointer-events-auto mx-auto flex max-w-md items-center justify-between rounded-[28px] border border-white/70 bg-white/90 px-3 py-2 shadow-[0_18px_40px_-18px_rgba(92,83,76,0.55)] backdrop-blur-xl">
        {items.map((item) => {
          const active = isActive(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`group relative flex flex-1 flex-col items-center gap-0.5 rounded-3xl px-2 py-2 transition-all ${
                active ? "text-coral-600" : "text-ink-500 hover:text-coral-500"
              }`}
            >
              <span
                className={`flex h-9 w-9 items-center justify-center rounded-2xl text-lg transition-all ${
                  active
                    ? "-translate-y-1 bg-coral-500 text-white shadow-lg shadow-coral-300/60"
                    : "bg-transparent"
                }`}
              >
                {item.icon}
              </span>
              <span
                className={`text-[10px] font-bold tracking-wide ${active ? "opacity-100" : "opacity-70"}`}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
