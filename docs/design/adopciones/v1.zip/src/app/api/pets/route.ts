import { NextResponse } from "next/server";
import { getPets } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const species = searchParams.get("especie") ?? undefined;
  const q = searchParams.get("q") ?? undefined;
  const pets = await getPets(species, q);
  return NextResponse.json({ pets });
}
