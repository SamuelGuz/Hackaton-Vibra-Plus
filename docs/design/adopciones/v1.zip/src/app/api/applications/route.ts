import { NextResponse } from "next/server";
import { db } from "@/db";
import { applications, followUps } from "@/db/schema";
import { bootstrap, getApplications, getPet } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status") ?? undefined;
  const rows = await getApplications(status);
  return NextResponse.json({ applications: rows });
}

function addDays(days: number) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export async function POST(request: Request) {
  await bootstrap();
  const body = (await request.json()) as Record<string, unknown>;

  const petId = Number(body.petId);
  const applicantName = String(body.applicantName ?? "").trim();
  const email = String(body.email ?? "").trim();
  const phone = String(body.phone ?? "").trim();
  const city = String(body.city ?? "").trim();
  const housing = String(body.housing ?? "").trim();
  const motivation = String(body.motivation ?? "").trim();
  const hasOtherPets = Boolean(body.hasOtherPets);

  if (!petId || !applicantName || !email || !phone || !housing) {
    return NextResponse.json(
      { error: "Faltan campos obligatorios." },
      { status: 400 },
    );
  }

  const pet = await getPet(petId);
  if (!pet) {
    return NextResponse.json({ error: "Mascota no encontrada." }, { status: 404 });
  }

  const [created] = await db
    .insert(applications)
    .values({
      petId,
      applicantName,
      email,
      phone,
      city: city || pet.city,
      housing,
      hasOtherPets,
      motivation,
      status: "pendiente",
      progress: 20,
    })
    .returning();

  await db.insert(followUps).values([
    {
      applicationId: created.id,
      title: "Revisión de solicitud",
      kind: "llamada",
      scheduledFor: addDays(2),
      note: "El refugio revisará tu perfil.",
      done: false,
      position: 1,
    },
    {
      applicationId: created.id,
      title: "Entrevista telefónica",
      kind: "llamada",
      scheduledFor: addDays(5),
      note: "",
      done: false,
      position: 2,
    },
    {
      applicationId: created.id,
      title: "Visita domiciliaria 1",
      kind: "visita",
      scheduledFor: addDays(12),
      note: "",
      done: false,
      position: 3,
    },
    {
      applicationId: created.id,
      title: `Entrega de ${pet.name}`,
      kind: "visita",
      scheduledFor: addDays(20),
      note: "",
      done: false,
      position: 4,
    },
  ]);

  return NextResponse.json({ application: created }, { status: 201 });
}
