"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Check, Loader2, RotateCcw } from "lucide-react";

export function FollowUpToggle({
  followUpId,
  completed,
}: {
  followUpId: number;
  completed: boolean;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [isPending, startTransition] = useTransition();

  async function toggle() {
    setBusy(true);
    try {
      await fetch(`/api/follow-ups/${followUpId}`, { method: "PATCH" });
      startTransition(() => router.refresh());
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={busy || isPending}
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-extrabold transition disabled:opacity-60 ${
        completed
          ? "bg-white text-ink/60 ring-1 ring-line hover:bg-cream"
          : "bg-mint-500 text-white shadow-[0_8px_18px_-8px_rgba(76,185,171,0.9)] hover:bg-mint-600"
      }`}
    >
      {busy || isPending ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      ) : completed ? (
        <RotateCcw className="h-3.5 w-3.5" />
      ) : (
        <Check className="h-3.5 w-3.5" strokeWidth={3} />
      )}
      {completed ? "Reabrir" : "Marcar hecho"}
    </button>
  );
}
