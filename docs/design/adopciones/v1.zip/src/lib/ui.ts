export const STATUS_META: Record<
  string,
  { label: string; chip: string; dot: string; bar: string }
> = {
  pendiente: {
    label: "Pendiente",
    chip: "bg-sun-200 text-amber-800",
    dot: "bg-sun-400",
    bar: "bg-sun-400",
  },
  en_proceso: {
    label: "En proceso",
    chip: "bg-coral-100 text-coral-700",
    dot: "bg-coral-500",
    bar: "bg-coral-500",
  },
  aprobado: {
    label: "Aprobado",
    chip: "bg-mint-200 text-mint-600",
    dot: "bg-mint-400",
    bar: "bg-mint-400",
  },
  rechazado: {
    label: "No aprobado",
    chip: "bg-stone-200 text-stone-600",
    dot: "bg-stone-400",
    bar: "bg-stone-400",
  },
};

export const PET_STATUS_META: Record<string, { label: string; chip: string }> =
  {
    disponible: { label: "En adopción", chip: "bg-mint-200 text-mint-600" },
    en_proceso: { label: "En proceso", chip: "bg-sun-200 text-amber-800" },
    adoptado: { label: "Adoptado", chip: "bg-coral-100 text-coral-700" },
  };

export const KIND_META: Record<string, { icon: string; tint: string }> = {
  visita: { icon: "🏠", tint: "bg-coral-100 text-coral-700" },
  vacuna: { icon: "💉", tint: "bg-mint-100 text-mint-600" },
  foto: { icon: "📸", tint: "bg-sun-100 text-amber-700" },
  llamada: { icon: "📞", tint: "bg-stone-100 text-ink-700" },
};

export const CATEGORY_META: Record<
  string,
  { label: string; icon: string; bar: string }
> = {
  vacuna: { label: "Vacunas", icon: "💉", bar: "bg-coral-500" },
  desparasitacion: {
    label: "Desparasitación",
    icon: "🛡️",
    bar: "bg-mint-400",
  },
  microchip: { label: "Microchip", icon: "📡", bar: "bg-sun-400" },
  revision: { label: "Revisión", icon: "🩺", bar: "bg-coral-300" },
};

export function speciesEmoji(species: string) {
  return species === "gato" ? "🐱" : "🐶";
}

export function formatDate(value: string) {
  if (!value) return "—";
  const d = new Date(`${value}T12:00:00`);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString("es-MX", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function initials(name: string) {
  return name
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}
