import type { Metadata } from "next";
import type { ReactNode } from "react";
import BottomNav from "@/components/BottomNav";
import "./globals.css";

export const metadata: Metadata = {
  title: "Patitas · Adopciones de perros y gatos",
  description:
    "App modular de adopción: solicitudes, detalle de mascota, pasaporte sanitario y seguimiento post-adopción.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="es">
      <body className="bg-stone-200 text-ink-900 antialiased">
        <div className="paw-bg min-h-screen bg-cream">
          <div className="mx-auto flex min-h-screen w-full max-w-md flex-col bg-cream shadow-[0_0_60px_-12px_rgba(92,83,76,0.35)] sm:my-0 sm:min-h-screen">
            <main className="flex-1">{children}</main>
            <BottomNav />
          </div>
        </div>
      </body>
    </html>
  );
}
