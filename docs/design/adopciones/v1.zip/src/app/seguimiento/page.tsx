import Link from "next/link";
import { Screen, ScreenBody, ScreenHeader } from "@/components/Screen";
import { getTrackedApplications } from "@/lib/data";
import { KIND_META, STATUS_META, formatDate } from "@/lib/ui";

export const dynamic = "force-dynamic";

export default async function SeguimientoIndexPage() {
  const tracked = await getTrackedApplications();

  return (
    <Screen>
      <ScreenHeader
        title="Seguimiento"
        subtitle="Visitas, vacunas y actualizaciones"
        backHref="/"
        tone="coral"
        emoji="💗"
      />
      <ScreenBody>
        {tracked.length === 0 ? (
          <div className="rounded-3xl bg-white p-8 text-center shadow-sm ring-1 ring-black/5">
            <p className="text-4xl">🐕</p>
            <p className="mt-2 text-sm font-bold">Aún no hay seguimientos</p>
          </div>
        ) : null}

        {tracked.map((app, i) => {
          const meta = STATUS_META[app.status] ?? STATUS_META.pendiente;
          const done = app.steps.filter((s) => s.done).length;
          const next = app.steps.find((s) => !s.done);
          const pct = Math.round((done / Math.max(app.steps.length, 1)) * 100);
          return (
            <Link
              key={app.id}
              href={`/seguimiento/${app.id}`}
              className="animate-rise block rounded-[26px] bg-white p-3.5 shadow-[0_12px_28px_-20px_rgba(92,83,76,0.9)] ring-1 ring-black/5 transition active:scale-[0.98]"
              style={{ animationDelay: `${i * 55}ms` }}
            >
              <div className="flex items-center gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={app.pet.photoUrl}
                  alt={app.pet.name}
                  className="h-14 w-14 rounded-2xl object-cover"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <p className="truncate text-base font-extrabold">
                      {app.pet.name}
                    </p>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-extrabold ${meta.chip}`}
                    >
                      {meta.label}
                    </span>
                  </div>
                  <p className="truncate text-[11px] font-semibold text-ink-500">
                    Adoptante: {app.applicantName}
                  </p>
                </div>
              </div>

              <div className="mt-3 flex items-center gap-2">
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-stone-200">
                  <div
                    className="h-full rounded-full bg-mint-400 transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="text-[10px] font-extrabold text-ink-500">
                  {done}/{app.steps.length}
                </span>
              </div>

              {next ? (
                <div className="mt-2.5 flex items-center gap-2 rounded-2xl bg-cream px-3 py-2">
                  <span
                    className={`flex h-7 w-7 items-center justify-center rounded-lg text-xs ${
                      (KIND_META[next.kind] ?? KIND_META.visita).tint
                    }`}
                  >
                    {(KIND_META[next.kind] ?? KIND_META.visita).icon}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-[11px] font-extrabold">
                      Siguiente: {next.title}
                    </p>
                    <p className="text-[10px] font-semibold text-ink-500">
                      {formatDate(next.scheduledFor)}
                    </p>
                  </div>
                </div>
              ) : (
                <p className="mt-2.5 rounded-2xl bg-mint-50 px-3 py-2 text-[11px] font-extrabold text-mint-600">
                  ¡Seguimiento completo! 🎉
                </p>
              )}
            </Link>
          );
        })}
      </ScreenBody>
    </Screen>
  );
}
