import Link from "next/link";
import { notFound } from "next/navigation";
import { Screen, ScreenBody, ScreenHeader } from "@/components/Screen";
import { getApplication, getFollowUps } from "@/lib/data";
import { STATUS_META, formatDate } from "@/lib/ui";
import Timeline from "./Timeline";

export const dynamic = "force-dynamic";

export default async function SeguimientoDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ nueva?: string }>;
}) {
  const { id } = await params;
  const { nueva } = await searchParams;
  const app = await getApplication(Number(id));
  if (!app) notFound();

  const steps = await getFollowUps(app.id);
  const meta = STATUS_META[app.status] ?? STATUS_META.pendiente;
  const next = steps.find((s) => !s.done);

  return (
    <Screen>
      <ScreenHeader
        title="Seguimiento"
        subtitle={`${app.pet.name} · ${app.applicantName}`}
        backHref="/seguimiento"
        tone="coral"
        emoji="💗"
      />
      <ScreenBody>
        {nueva ? (
          <div className="animate-pop rounded-3xl bg-mint-100 p-4 text-center ring-1 ring-mint-200">
            <p className="text-3xl">🎉</p>
            <p className="mt-1 text-sm font-extrabold text-mint-600">
              ¡Solicitud enviada!
            </p>
            <p className="text-[11px] font-semibold text-mint-600/80">
              El refugio te contactará en menos de 48 horas.
            </p>
          </div>
        ) : null}

        <div className="animate-pop rounded-[28px] bg-white p-3.5 shadow-[0_14px_32px_-22px_rgba(92,83,76,0.9)] ring-1 ring-black/5">
          <div className="flex items-center gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={app.pet.photoUrl}
              alt={app.pet.name}
              className="h-16 w-16 rounded-2xl object-cover"
            />
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-lg font-extrabold leading-tight">
                  {app.pet.name}
                </p>
                <span
                  className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-extrabold ${meta.chip}`}
                >
                  {meta.label}
                </span>
              </div>
              <p className="truncate text-[11px] font-semibold text-ink-500">
                Solicitud #{app.id} · {app.pet.shelter}
              </p>
            </div>
          </div>

          {next ? (
            <div className="mt-3 flex items-center gap-3 rounded-2xl bg-coral-50 px-3 py-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-coral-500 text-lg text-white shadow-md shadow-coral-200">
                ⏰
              </span>
              <div className="min-w-0">
                <p className="text-[10px] font-extrabold uppercase tracking-wide text-coral-700">
                  Próximo paso
                </p>
                <p className="truncate text-xs font-extrabold">{next.title}</p>
                <p className="text-[10px] font-semibold text-ink-500">
                  {formatDate(next.scheduledFor)}
                </p>
              </div>
            </div>
          ) : (
            <p className="mt-3 rounded-2xl bg-mint-100 px-3 py-3 text-center text-xs font-extrabold text-mint-600">
              Seguimiento finalizado con éxito 🐾
            </p>
          )}
        </div>

        <Timeline steps={steps} />

        <div className="flex gap-2.5">
          <Link
            href={`/solicitudes/${app.id}`}
            className="flex-1 rounded-2xl bg-white py-3.5 text-center text-sm font-extrabold text-ink-700 shadow-md ring-1 ring-black/5"
          >
            Ver solicitud
          </Link>
          <Link
            href={`/pasaporte/${app.pet.id}`}
            className="flex-1 rounded-2xl bg-coral-500 py-3.5 text-center text-sm font-extrabold text-white shadow-lg shadow-coral-200 transition active:scale-95"
          >
            Pasaporte 🪪
          </Link>
        </div>
      </ScreenBody>
    </Screen>
  );
}
