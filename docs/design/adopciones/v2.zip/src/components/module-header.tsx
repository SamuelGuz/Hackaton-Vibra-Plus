import type { LucideIcon } from "lucide-react";
import type { ReactNode } from "react";
import { PawPrint } from "lucide-react";

export function ModuleHeader({
  icon: Icon,
  eyebrow,
  title,
  description,
  children,
  tone = "coral",
}: {
  icon: LucideIcon;
  eyebrow: string;
  title: string;
  description: string;
  children?: ReactNode;
  tone?: "coral" | "mint";
}) {
  const tones = {
    coral: {
      bg: "bg-coral-500",
      icon: "bg-white/15 text-white ring-white/25",
      eyebrow: "text-white/80",
      accent: "text-sun-200",
    },
    mint: {
      bg: "bg-mint-600",
      icon: "bg-white/15 text-white ring-white/25",
      eyebrow: "text-white/80",
      accent: "text-mint-200",
    },
  } as const;
  const theme = tones[tone];

  return (
    <section
      className={`relative overflow-hidden rounded-[30px] ${theme.bg} px-5 py-6 text-white shadow-soft sm:px-8 sm:py-8`}
    >
      <div className="paw-pattern absolute inset-0 opacity-25" />
      <div
        aria-hidden
        className="absolute -right-12 -top-16 h-48 w-48 rounded-full bg-white/10"
      />
      <PawPrint
        aria-hidden
        className="absolute -bottom-6 right-28 h-24 w-24 rotate-12 text-white/15"
      />
      <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-4">
          <span
            className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl ${theme.icon} ring-1`}
          >
            <Icon className="h-6 w-6" strokeWidth={2.3} />
          </span>
          <div>
            <p
              className={`text-[11px] font-extrabold uppercase tracking-[0.2em] ${theme.eyebrow}`}
            >
              {eyebrow}
            </p>
            <h1 className="mt-1 font-display text-3xl font-bold leading-none sm:text-4xl">
              {title}
            </h1>
            <p className="mt-2 max-w-xl text-sm font-semibold leading-snug text-white/85">
              {description}
            </p>
          </div>
        </div>
        {children ? <div className="shrink-0">{children}</div> : null}
      </div>
    </section>
  );
}
