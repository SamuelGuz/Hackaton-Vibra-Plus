import { decideApplication } from "@/db/queries";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await context.params;
    const applicationId = Number(id);
    if (!Number.isInteger(applicationId)) {
      return Response.json(
        { ok: false, error: "Solicitud no válida" },
        { status: 400 },
      );
    }

    const body = (await request.json()) as { status?: string };
    if (body.status !== "aprobada" && body.status !== "rechazada") {
      return Response.json(
        { ok: false, error: "Estado no permitido" },
        { status: 400 },
      );
    }

    const updated = await decideApplication(applicationId, body.status);
    if (!updated) {
      return Response.json(
        { ok: false, error: "La solicitud no existe" },
        { status: 404 },
      );
    }

    return Response.json({ ok: true, application: updated });
  } catch (error) {
    console.error("[applications] PATCH", error);
    return Response.json(
      { ok: false, error: "No pudimos actualizar la solicitud" },
      { status: 500 },
    );
  }
}
