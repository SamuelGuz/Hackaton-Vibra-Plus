import { createFollowUp } from "@/db/queries";

export const dynamic = "force-dynamic";

const allowedTypes = ["visita", "vacuna", "foto", "llamada"] as const;

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const petId = Number(body.petId);
    const title = String(body.title ?? "").trim();
    const description = String(body.description ?? "").trim();
    const type = String(body.type ?? "visita");
    const dueOn = String(body.dueOn ?? "");

    const errors: Record<string, string> = {};
    if (!Number.isInteger(petId) || petId <= 0) errors.petId = "Mascota no válida";
    if (title.length < 3) errors.title = "Escribe un título para el hito";
    if (!allowedTypes.includes(type as (typeof allowedTypes)[number]))
      errors.type = "Tipo no válido";
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dueOn)) errors.dueOn = "Selecciona una fecha";

    if (Object.keys(errors).length > 0) {
      return Response.json({ ok: false, errors }, { status: 400 });
    }

    const created = await createFollowUp({
      petId,
      title,
      description,
      type: type as (typeof allowedTypes)[number],
      dueOn,
    });

    return Response.json({ ok: true, followUp: created }, { status: 201 });
  } catch (error) {
    console.error("[follow-ups] POST", error);
    return Response.json(
      { ok: false, error: "No pudimos crear el hito de seguimiento" },
      { status: 500 },
    );
  }
}
