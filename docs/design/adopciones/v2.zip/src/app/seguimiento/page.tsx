import Link from "next/link";
import {
  ArrowUpRight,
  CalendarDays,
  Check,
  Clock,
  Heart,
  IdCard,
  PawPrint,
  Route,
  Sparkles,
} from "lucide-react";
import { ModuleHeader } from "@/components/module-header";
import { PetStatusPill } from "@/components/status-pill";
import { listFollowUpSummaries } from "@/db/queries";
import { followUpTypeMeta, shortDate, speciesLabel } from "@/lib/format";
import { daysUntil } from "@/lib/dates";

export const dynamic = "force-dynamic";

export default async function SeguimientoPage() {
  const summaries = await listFollowUpSummaries();
  const active = summaries.filter((item) => item.completed < item.total);
  const next = active
    .filter((item) => item.nextDueOn)
    .sort((a, b) => (a.nextDueOn ?? "").localeCompare(b.nextDueOn ?? ""))[0];
  const totalHitos = summaries.reduce((sum, item) => sum + item.total, 0);
  const totalCompleted = summaries.reduce((sum, item) => sum + item.completed, 0);

  return (
    <div className="space-y-6">
      <ModuleHeader
        icon={Route}
        eyebrow="Módulo · Seguimiento"
        title="Seguimiento"
        description="El acompañamiento después de la adopción: visitas al hogar, refuerzos de vacunas y fotos de evolución."
      >
        <div className="flex gap-2">
          <div className="rounded-2xl bg-white/15 px-4 py-3 text-center ring-1 ring-white/25 backdrop-blur-sm">
            <p className="font-display text-2xl font-bold leading-none">
              {totalCompleted}
            </p>
            <p className="mt-1 text-[9px] font-extrabold uppercase tracking-[0.14em] text-white/80">
              hitos hechos
            </p>
          </div>
          <div className="rounded-2xl bg-white/15 px-4 py-3 text-center ring-1 ring-white/25 backdrop-blur-sm">
            <p className="font-display text-2xl font-bold leading-none">
              {totalHitos}
            </p>
            <p className="mt-1 text-[9px] font-extrabold uppercase tracking-[0.14em] text-white/80">
              planificados
            </p>
          </div>
        </div>
      </ModuleHeader>

      {next ? (
        <Link
          href={`/seguimiento/${next.pet.id}`}
          className="card group relative flex flex-col gap-4 overflow-hidden p-5 transition hover:-translate-y-0.5 sm:flex-row sm:items-center"
        >
          <span className="absolute inset-y-0 left-0 w-2 bg-sun-400" />
          <div className="relative ml-1 h-16 w-16 shrink-0">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={next.pet.photoUrl}
              alt={next.pet.name}
              className="h-full w-full rounded-full object-cover ring-4 ring-sun-200"
            />
            <span className="absolute -bottom-1 -right-1 grid h-7 w-7 place-items-center rounded-full bg-coral-500 text-white ring-2 ring-white">
              <CalendarDays className="h-3.5 w-3.5" />
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[10px] font-extrabold uppercase tracking-[0.18em] text-coral-500">
              Próximo hito
            </p>
            <p className="font-display text-xl font-bold leading-tight">
              {next.pet.name} · {next.nextTitle}
            </p>
            <p className="mt-0.5 flex flex-wrap items-center gap-2 text-[11px] font-bold text-muted">
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                {shortDate(next.nextDueOn)}
              </span>
              <span className="rounded-full bg-sun-100 px-2 py-0.5 text-amber-800">
                {(() => {
                  const days = daysUntil(next.nextDueOn ?? "");
                  if (days === null) return "Fecha por confirmar";
                  if (days === 0) return "Hoy";
                  if (days > 0) return `En ${days} días`;
                  return `Hace ${Math.abs(days)} días`;
                })()}
              </span>
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 self-start rounded-full bg-coral-500 px-4 py-2.5 text-xs font-extrabold text-white shadow-pop transition group-hover:bg-coral-600 sm:self-auto">
            Abrir
            <ArrowUpRight className="h-3.5 w-3.5" strokeWidth={2.8} />
          </span>
        </Link>
      ) : null}

      {summaries.length === 0 ? (
        <div className="card flex flex-col items-center gap-3 px-6 py-14 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-full bg-sky-100 text-sky-700">
            <Route className="h-7 w-7" />
          </span>
          <h2 className="font-display text-xl font-bold">
            Aún no hay seguimientos activos
          </h2>
          <p className="max-w-sm text-sm font-medium text-muted">
            Cuando se aprueba una adopción se activa un plan de visitas y
            refuerzos. Puedes empezar aprobando una solicitud.
          </p>
          <Link href="/solicitudes" className="btn-primary mt-2">
            Ir a solicitudes
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {summaries.map(({ pet, total, completed, nextTitle, nextDueOn }) => {
            const progress = Math.round((completed / Math.max(total, 1)) * 100);
            return (
              <article key={pet.id} className="card overflow-hidden p-5">
                <div className="flex items-start gap-3">
                  <div className="h-16 w-16 shrink-0 overflow-hidden rounded-2xl ring-2 ring-cream">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={pet.photoUrl}
                      alt={pet.name}
                      className="h-full w-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <h2 className="font-display text-xl font-bold leading-none">
                          {pet.name}
                        </h2>
                        <p className="mt-1 text-[11px] font-bold text-muted">
                          {speciesLabel(pet.species)} · {pet.city}
                        </p>
                      </div>
                      <PetStatusPill status={pet.status} />
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="flex items-center justify-between text-[10px] font-extrabold uppercase tracking-wide text-ink/60">
                    <span>Progreso del plan</span>
                    <span className="flex items-center gap-1">
                      {completed}/{total} hitos
                    </span>
                  </div>
                  <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-cream">
                    <div
                      className={`h-full rounded-full ${progress >= 100 ? "bg-mint-500" : "bg-mint-400"}`}
                      style={{ width: `${Math.min(Math.max(progress, 3), 100)}%` }}
                    />
                  </div>
                </div>

                <div className="mt-3 rounded-xl bg-cream/80 px-3 py-2 ring-1 ring-line/70">
                  <p className="text-[10px] font-extrabold uppercase tracking-[0.14em] text-muted">
                    {nextTitle ? "Siguiente" : "Plan completado"}
                  </p>
                  <p className="flex items-center gap-1.5 text-xs font-extrabold text-ink">
                    {nextTitle ? (
                      <>
                        <span>{nextTitle}</span>
                        <span className="ml-auto flex items-center gap-1 text-[10px] font-bold text-muted">
                          <CalendarDays className="h-3 w-3" />
                          {shortDate(nextDueOn)}
                        </span>
                      </>
                    ) : (
                      <>
                        <Check className="h-3.5 w-3.5 text-mint-600" strokeWidth={3} />
                        Todos los hitos completados
                      </>
                    )}
                  </p>
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-line/70 pt-3">
                  <Link
                    href={`/seguimiento/${pet.id}`}
                    className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-full bg-coral-500 px-3.5 py-2 text-xs font-extrabold text-white shadow-pop transition hover:bg-coral-600"
                  >
                    <Route className="h-3.5 w-3.5" />
                    Ver seguimiento
                  </Link>
                  <Link
                    href={`/pasaporte/${pet.id}`}
                    className="inline-flex items-center gap-1.5 rounded-full bg-mint-50 px-3 py-2 text-xs font-extrabold text-mint-700 ring-1 ring-mint-100 transition hover:bg-mint-100"
                  >
                    <IdCard className="h-3.5 w-3.5" />
                    Pasaporte
                  </Link>
                  <Link
                    href={`/mascotas/${pet.id}`}
                    className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-2 text-xs font-extrabold text-ink/60 ring-1 ring-line transition hover:bg-cream"
                  >
                    <PawPrint className="h-3.5 w-3.5" />
                    Ficha
                  </Link>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-3">
        {[
          {
            icon: Heart,
            title: "Visitas de acompañamiento",
            text: "El refugio visita el hogar en las primeras semanas.",
            tone: "bg-coral-50 text-coral-600",
          },
          {
            icon: Check,
            title: "Vacunas de refuerzo",
            text: "Recordatorios del calendario veterinario.",
            tone: "bg-mint-100 text-mint-700",
          },
          {
            icon: Sparkles,
            title: "Álbum de evolución",
            text: "Fotos y notas que documentan su nueva vida.",
            tone: "bg-sun-100 text-amber-700",
          },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.title} className="surface flex items-start gap-3 p-4">
              <span className={`grid h-9 w-9 shrink-0 place-items-center rounded-xl ${item.tone}`}>
                <Icon className="h-4 w-4" />
              </span>
              <div>
                <p className="text-xs font-extrabold">{item.title}</p>
                <p className="mt-0.5 text-[11px] font-medium leading-snug text-muted">
                  {item.text}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
